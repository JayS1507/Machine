#!/usr/bin/env bash
# Run this on the SERVER, in the folder where overshare-image.tar.gz was copied.
# Usage: ./deploy_server.sh [HOST_SSH_PORT]
# HOST_SSH_PORT defaults to 22. Use 2222 if the server already uses 22.
set -e

SSH_PORT="${1:-22}"

gunzip -c overshare-image.tar.gz | docker load
docker rm -f overshare 2>/dev/null || true

docker run -d \
  --name overshare \
  --restart unless-stopped \
  -p 21:21 \
  -p "${SSH_PORT}:22" \
  -p 21100-21110:21100-21110 \
  overshare:latest

echo
docker ps --filter name=overshare
echo "Players connect: ftp SERVER_IP  |  ssh developer@SERVER_IP -p ${SSH_PORT}"
