#!/usr/bin/env bash
# Run this on your LOCAL machine (needs docker).
# Usage: ./build_export.sh <SERVER_PUBLIC_IP>
set -e

SERVER_IP="${1:?usage: ./build_export.sh <SERVER_PUBLIC_IP>}"

# Bake the server IP into vsftpd so passive FTP works from outside
sed -i "s/^pasv_address=.*/pasv_address=${SERVER_IP}/" vsftpd.conf

docker build -t overshare:latest .
docker save overshare:latest | gzip > overshare-image.tar.gz

echo
echo "Built and exported: overshare-image.tar.gz"
echo "Next: scp overshare-image.tar.gz USER@${SERVER_IP}:~/"
