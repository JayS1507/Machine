-- Create vulnerable table for SQL injection
CREATE TABLE IF NOT EXISTS users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50),
  password VARCHAR(100),
  email VARCHAR(100),
  role VARCHAR(20)
);

-- Insert test data
INSERT INTO users (username, password, email, role) VALUES
  ('admin', 'admin123456', 'admin@hackctf.local', 'admin'),
  ('guest', 'guest123', 'guest@hackctf.local', 'user'),
  ('developer', 'dev@sensitive123', 'dev@hackctf.local', 'developer');

-- Create products table to show SQL injection impact
CREATE TABLE IF NOT EXISTS products (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100),
  description TEXT,
  price DECIMAL(10, 2),
  secret VARCHAR(200)
);

INSERT INTO products (name, description, price, secret) VALUES
  ('Laptop', 'High performance laptop', 999.99, 'flag_fragment_1: a7b9c2'),
  ('Mouse', 'Wireless mouse', 29.99, 'flag_fragment_2: d4e1f6'),
  ('Keyboard', 'Mechanical keyboard', 79.99, 'Database credentials exposed: ctf_user:ctf_pass123');
