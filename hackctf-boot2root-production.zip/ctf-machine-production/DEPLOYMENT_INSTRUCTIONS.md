# 🚀 Production Deployment Instructions

## Quick Start (All Platforms)

### Option 1: Automated Deployment (Linux/Mac)

```bash
cd ctf-machine
chmod +x DEPLOY.sh
./DEPLOY.sh
```

### Option 2: Automated Deployment (Windows)

```cmd
cd ctf-machine
DEPLOY.bat
```

### Option 3: Manual Deployment (All Platforms)

```bash
# Build the image
docker build -t hackctf-boot2root .

# Run the container
docker run -d \
  --name hackctf-boot2root \
  -p 2222:22 \
  -p 8080:80 \
  -p 3306:3306 \
  -p 21:21 \
  --restart unless-stopped \
  hackctf-boot2root:latest

# Verify
docker ps | grep hackctf-boot2root
```

---

## Access Information

Once deployed, access the machine:

### Web Application
- **URL:** http://localhost:8080
- **Purpose:** Vulnerable web app with SQL injection

### SSH Access
```bash
ssh -p 2222 user@localhost
# Password: user123
```

### Database Access
```bash
mysql -h localhost -u ctf_user -pctf_pass123 ctf_db
```

---

## Available Flags

All 4 flags are ready to capture:

1. **User Flag** (200 pts)
   - `HackCTF{user_pwned_the_app}`
   - Location: `/home/user/user.txt`

2. **Developer Flag** (300 pts)
   - `HackCTF{lateral_movement_success}`
   - Location: `/home/developer/flag1.txt`

3. **SUID Flag** (300 pts)
   - `HackCTF{exploited_suid_binary}`
   - Location: `/opt/sensitive/flag.txt`

4. **Root Flag** (400 pts)
   - `HackCTF{root_of_all_evil}`
   - Location: `/root/root.txt`

**Total: 1200 Points**

---

## Management Commands

### View Container Logs
```bash
docker logs hackctf-boot2root
```

### Access Container Shell
```bash
docker exec -it hackctf-boot2root bash
```

### Stop Container
```bash
docker stop hackctf-boot2root
```

### Start Container
```bash
docker start hackctf-boot2root
```

### Remove Container
```bash
docker stop hackctf-boot2root
docker rm hackctf-boot2root
```

### Remove Image
```bash
docker rmi hackctf-boot2root
```

---

## Verify Deployment

```bash
# Check if container is running
docker ps | grep hackctf-boot2root

# Test web access
curl http://localhost:8080/

# Test SSH access
ssh -p 2222 user@localhost -c "whoami"

# Test database access
mysql -h localhost -u ctf_user -pctf_pass123 ctf_db -e "SELECT COUNT(*) FROM users;"
```

---

## Troubleshooting

### Port Already in Use
If you get "port is already allocated":
```bash
# Change port mapping (e.g., use 8081 instead of 8080)
docker run -d --name hackctf-boot2root \
  -p 2222:22 -p 8081:80 -p 3306:3306 -p 21:21 \
  --restart unless-stopped \
  hackctf-boot2root:latest
```

### Container Won't Start
```bash
# Check logs
docker logs hackctf-boot2root

# Try rebuilding image
docker build -t hackctf-boot2root .
```

### Docker Not Found
- **Linux:** Install Docker from https://docs.docker.com/install/
- **Mac:** Install Docker Desktop
- **Windows:** Install Docker Desktop

---

## Documentation Files

- **README.md** - Complete technical documentation
- **SOLUTIONS-v2.md** - Step-by-step exploitation guide
- **QUICKSTART.md** - Quick reference guide
- **INDEX.md** - File navigation
- **Dockerfile** - Container configuration

---

## Security Note

This is an **intentionally vulnerable machine** for educational purposes only.

- Use in authorized training environments only
- Do not deploy in production without proper security review
- All credentials are test-only credentials
- Designed for authorized security practitioners

---

## Support

For issues or questions:
1. Check the documentation files
2. Review the Dockerfile for configuration
3. Check container logs: `docker logs hackctf-boot2root`
4. Verify Docker installation: `docker --version`

