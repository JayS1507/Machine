# 📑 HackCTF Boot2Root - File Index & Navigation

## 📚 Documentation Files

### 📋 README.md (7.4 KB)
**Complete technical documentation**
- Challenge overview and objectives
- Vulnerability descriptions with CWE references
- CVSS severity scores
- Detailed solution walkthrough
- Tools required and learning resources
- Architecture overview
- Customization options

**When to read:** First - comprehensive reference guide

---

### ⚡ QUICKSTART.md (3.1 KB)
**Fast deployment and exploitation guide**
- 30-second deployment instructions
- Quick solution (45-minute walkthrough)
- Verification checklist
- Exploit summary table
- Troubleshooting quick fixes

**When to read:** For rapid deployment and testing

---

### 🎯 SOLUTIONS.md (7.1 KB)
**Complete step-by-step exploitation walkthrough**
- Part 1: User flag (reconnaissance → user access)
- Part 2: Root flag (privilege escalation)
- SQL injection examples with payloads
- Command injection techniques
- Exploitation timeline
- CVSS vulnerability scores
- Advanced techniques

**When to read:** For detailed exploitation examples

---

### 📦 DEPLOYMENT.md (6.0 KB)
**Operations and maintenance guide**
- System requirements
- Production deployment options
- Container access methods
- Service management
- Monitoring and troubleshooting
- Backup and recovery procedures
- Customization techniques
- Performance tuning
- Security hardening

**When to read:** For production deployment and management

---

### ✅ PROJECT_SUMMARY.txt (14 KB)
**High-level project completion summary**
- Executive overview
- Challenge objectives
- Technology stack
- Attack chain visualization
- Exploitation timeline
- Test results
- Deliverables checklist
- Status and next steps

**When to read:** For project overview and status

---

## 🐳 Docker Files

### Dockerfile (2.1 KB)
**Container definition and configuration**
- Debian Bookworm Slim base image
- Service installation (Apache, PHP, MariaDB, SSH)
- User creation and SSH configuration
- Vulnerable web app setup
- SUID binary compilation
- Flag placement
- Port exposure (22, 80, 3306)

**Usage:** `docker build -t hackctf-boot2root Dockerfile`

---

### docker-compose.yml (551 B)
**Service orchestration configuration**
- Container service definition
- Port mapping (2222→22, 8080→80, 3306→3306)
- Environment variables
- Volume configuration
- Network setup
- Restart policy

**Usage:** `docker compose up -d` (requires docker-compose)

---

## 🌐 Application Files

### app/index.php (7.4 KB)
**Vulnerable PHP web application**
- Login form with SQL injection
- Product search with SQL injection
- Database connection handling
- Vulnerable query construction
- HTML interface with hints
- System information display

**Vulnerabilities:**
- Direct string concatenation in SQL queries
- No input sanitization
- Unauthenticated access

**Exploitation:** SQL injection, authentication bypass

---

## 🗄️ Database Files

### mysql/setup.sql (1.0 KB)
**Database schema and test data**
- Users table with test accounts
- Products table with secrets
- Credentials embedded in data
- Test data for SQL injection practice

**Contains:**
- admin:admin123456
- guest:guest123
- developer:dev@sensitive123
- Hidden secrets in product descriptions

---

## 🔧 Script Files

### scripts/init.sh (471 B)
**Container startup and initialization**
- MariaDB service start
- Database creation
- User setup
- Table import from setup.sql
- SSH service start
- Apache startup in foreground mode

**Executed:** Automatically on container start via CMD

---

### scripts/vuln_cat.c (471 B)
**Vulnerable SUID binary source code**
- C program with command injection vulnerability
- Uses system() with unsanitized user input
- Compiled with SUID bit set
- Runs with root privileges

**Vulnerability:** CWE-78 - Command Injection

**Exploitation:** 
```bash
vuln_cat "/root/root.txt"
vuln_cat "$(whoami)"
```

---

### scripts/privesc_hints.sh (485 B)
**Privilege escalation hints and methods**
- SUID binary exploitation path
- Sudo NOPASSWD exploitation
- File permission misconfiguration path
- Quick reference for privesc techniques

---

## 📊 File Organization

```
ctf-machine/
├── 📄 Documentation (all .md and .txt files)
│   ├── README.md              → Technical reference
│   ├── QUICKSTART.md          → Rapid deployment
│   ├── SOLUTIONS.md           → Exploitation guide
│   ├── DEPLOYMENT.md          → Operations guide
│   └── PROJECT_SUMMARY.txt    → Executive summary
│
├── 🐳 Docker Configuration
│   ├── Dockerfile             → Container definition
│   ├── docker-compose.yml     → Orchestration
│   
├── 💻 Application Code
│   └── app/
│       └── index.php          → Vulnerable web app
│
├── 🗄️ Database
│   └── mysql/
│       └── setup.sql          → Schema & test data
│
└── 🔧 Scripts & Tools
    └── scripts/
        ├── init.sh            → Container startup
        ├── vuln_cat.c         → SUID binary source
        └── privesc_hints.sh   → Hints & techniques
```

---

## 🚀 Usage Flow

### For Challenge Participants:
1. Read **QUICKSTART.md** (2 min)
2. Deploy machine using quick start
3. Read **README.md** for context (5 min)
4. Begin exploitation
5. Refer to **SOLUTIONS.md** if stuck

### For CTF Administrators:
1. Read **PROJECT_SUMMARY.txt** for overview
2. Follow **DEPLOYMENT.md** for setup
3. Review **SOLUTIONS.md** to understand challenges
4. Use **QUICKSTART.md** for quick testing

### For Security Researchers:
1. Start with **README.md** for technical details
2. Study **SOLUTIONS.md** for exploitation techniques
3. Review source code: app/index.php, vuln_cat.c
4. Examine database schema: mysql/setup.sql
5. Reference **DEPLOYMENT.md** for customization

---

## 📌 Key Information by Topic

### SQL Injection
- **Location:** README.md (Vulnerabilities section)
- **Details:** SOLUTIONS.md (Part 1, Step 2-3)
- **Code:** app/index.php (lines with $query =)
- **Payloads:** SOLUTIONS.md (Attack 1-2)

### Privilege Escalation
- **Methods:** SOLUTIONS.md (Part 2, Vector 1-3)
- **SUID Binary:** scripts/vuln_cat.c
- **Sudo Config:** Dockerfile (sudoers line)
- **File Perms:** Dockerfile (/opt/sensitive)

### Flags
- **User Flag:** HackCTF{user_pwned_the_app}
- **Location:** /home/user/user.txt
- **Root Flag:** HackCTF{root_of_all_evil}
- **Location:** /root/root.txt

### Services & Ports
- **SSH:** Port 2222 (user/user123, root/root123)
- **HTTP:** Port 8080 (http://localhost:8080)
- **MySQL:** Port 3306 (ctf_user:ctf_pass123)

---

## 💡 File Selection Guide

| Need | Primary File | Secondary File |
|------|---|---|
| Understand challenge | README.md | PROJECT_SUMMARY.txt |
| Deploy quickly | QUICKSTART.md | Dockerfile |
| See exploits | SOLUTIONS.md | README.md |
| Operate machine | DEPLOYMENT.md | scripts/init.sh |
| Web vulnerabilities | app/index.php | README.md |
| Binary exploitation | scripts/vuln_cat.c | SOLUTIONS.md |
| Database schema | mysql/setup.sql | SOLUTIONS.md |
| System startup | scripts/init.sh | Dockerfile |
| Hints for players | QUICKSTART.md | README.md |

---

## 🔍 Search Tips

**Find SQL injection details:**
```bash
grep -r "SQL Injection" *.md
```

**Find exploit payloads:**
```bash
grep -A 2 "Payload:" SOLUTIONS.md
```

**Find flag locations:**
```bash
grep -r "HackCTF{" *.md *.txt
```

**Find vulnerabilities:**
```bash
grep -r "CWE-" README.md SOLUTIONS.md
```

---

**Total Documentation Size:** ~92 KB
**Files:** 12 total (5 docs, 2 docker, 1 app, 1 db, 3 scripts)
**Last Updated:** May 4, 2026
**Status:** Production Ready ✅
