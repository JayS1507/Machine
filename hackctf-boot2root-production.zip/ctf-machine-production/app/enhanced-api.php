<?php
// Enhanced HackCTF - Advanced Security Challenge
// This version features blind SQL injection, JWT authentication, and complex exploits

error_reporting(0);
ini_set('display_errors', 0);

// Database connection
$mysqli = new mysqli("localhost", "ctf_user", "ctf_pass123", "ctf_db");

if ($mysqli->connect_error) {
    http_response_code(500);
    exit('Database error');
}

// JWT Secret (weak but deliberate)
define('JWT_SECRET', 'super_secret_key_12345');

class JWT {
    public static function encode($data) {
        $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
        $payload = json_encode($data);
        
        $base64Header = rtrim(strtr(base64_encode($header), '+/', '-_'), '=');
        $base64Payload = rtrim(strtr(base64_encode($payload), '+/', '-_'), '=');
        
        $signature = hash_hmac(
            'sha256',
            $base64Header . '.' . $base64Payload,
            JWT_SECRET,
            true
        );
        $base64Signature = rtrim(strtr(base64_encode($signature), '+/', '-_'), '=');
        
        return $base64Header . '.' . $base64Payload . '.' . $base64Signature;
    }
    
    public static function decode($token) {
        $parts = explode('.', $token);
        if (count($parts) !== 3) return null;
        
        $payload = json_decode(
            base64_decode(str_pad(strtr($parts[1], '-_', '+/'), strlen($parts[1]) % 4, '=')),
            true
        );
        return $payload;
    }
}

// Blind SQL Injection - Time-based detection
function checkBlindSQLi($input) {
    global $mysqli;
    
    // Check if query takes longer (time-based blind SQLi)
    $start = microtime(true);
    
    // VULNERABLE: No prepared statements, direct SQL concatenation
    $query = "SELECT COUNT(*) FROM users WHERE username = '" . $input . "' LIMIT 1";
    
    $result = $mysqli->query($query);
    
    $elapsed = microtime(true) - $start;
    
    return $elapsed;
}

// Get user data (Blind SQLi endpoint)
function getUserByUsername($username) {
    global $mysqli;
    
    // VULNERABLE: Direct concatenation allows blind SQL injection
    $query = "SELECT id, username, role FROM users WHERE username = '" . $username . "' LIMIT 1";
    
    $result = $mysqli->query($query);
    
    if (!$result) {
        return ['error' => 'Query error', 'success' => false];
    }
    
    if ($result->num_rows > 0) {
        return ['data' => $result->fetch_assoc(), 'success' => true];
    }
    
    return ['error' => 'User not found', 'success' => false];
}

// Advanced product search with multiple injection points
function searchProductsAdvanced($search, $category = null, $price_range = null) {
    global $mysqli;
    
    // VULNERABLE: Multiple injection points
    $query = "SELECT * FROM products WHERE (name LIKE '%" . $search . "%' OR description LIKE '%" . $search . "%')";
    
    if ($category) {
        $query .= " AND category = '" . $category . "'";
    }
    
    if ($price_range) {
        $query .= " AND price <= " . $price_range;
    }
    
    $result = $mysqli->query($query);
    
    if (!$result) {
        return ['error' => 'Query failed', 'results' => []];
    }
    
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    
    return ['results' => $products, 'count' => count($products)];
}

// Handle API requests
$action = $_GET['action'] ?? $_POST['action'] ?? null;
$method = $_SERVER['REQUEST_METHOD'];

header('Content-Type: application/json');

switch ($action) {
    // Blind SQLi detection endpoint
    case 'check_user':
        $username = $_GET['username'] ?? '';
        $response = getUserByUsername($username);
        echo json_encode($response);
        break;
    
    // Advanced search with multiple injections
    case 'search_advanced':
        $search = $_GET['search'] ?? '';
        $category = $_GET['category'] ?? null;
        $price = $_GET['price'] ?? null;
        
        $response = searchProductsAdvanced($search, $category, $price);
        echo json_encode($response);
        break;
    
    // Time-based blind SQLi endpoint
    case 'timing_attack':
        $payload = $_GET['payload'] ?? '';
        $time = checkBlindSQLi($payload);
        echo json_encode(['timing' => $time, 'payload' => $payload]);
        break;
    
    // Get all users (Admin only)
    case 'admin_dump':
        $auth = $_GET['auth'] ?? $_POST['auth'] ?? null;
        
        if ($auth) {
            $jwt = JWT::decode($auth);
            if ($jwt && $jwt['role'] === 'admin') {
                $query = "SELECT id, username, role FROM users";
                $result = $mysqli->query($query);
                $users = [];
                while ($row = $result->fetch_assoc()) {
                    $users[] = $row;
                }
                echo json_encode(['users' => $users]);
            } else {
                echo json_encode(['error' => 'Unauthorized']);
            }
        } else {
            echo json_encode(['error' => 'No auth token']);
        }
        break;
    
    // Get database information
    case 'db_info':
        $query = "SELECT table_name FROM information_schema.tables WHERE table_schema = 'ctf_db'";
        $result = $mysqli->query($query);
        $tables = [];
        while ($row = $result->fetch_assoc()) {
            $tables[] = $row['table_name'];
        }
        echo json_encode(['tables' => $tables]);
        break;
    
    // Default - system info
    default:
        echo json_encode(['version' => '2.0', 'status' => 'online']);
        break;
}
?>
