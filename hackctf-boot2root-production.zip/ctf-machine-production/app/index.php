<?php
// Database connection
$mysqli = new mysqli("localhost", "ctf_user", "ctf_pass123", "ctf_db");

if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}

// Vulnerable function - SQL Injection vulnerability
function login($username, $password) {
    global $mysqli;
    
    // VULNERABLE: Direct string concatenation - SQL Injection!
    $query = "SELECT * FROM users WHERE username='" . $username . "' AND password='" . $password . "'";
    
    $result = $mysqli->query($query);
    
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        return $user;
    }
    return null;
}

// Vulnerable search function
function searchProducts($search) {
    global $mysqli;
    
    // VULNERABLE: Another SQL Injection point
    $query = "SELECT * FROM products WHERE name LIKE '%" . $search . "%' OR description LIKE '%" . $search . "%'";
    
    $result = $mysqli->query($query);
    $products = [];
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
    }
    return $products;
}

// Handle login
$login_result = null;
$login_error = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'login') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $login_result = login($username, $password);
    
    if ($login_result) {
        $login_error = "Welcome, " . htmlspecialchars($login_result['username']) . "! You have role: " . htmlspecialchars($login_result['role']);
    } else {
        $login_error = "Login failed!";
    }
}

// Handle search
$search_results = [];
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['search'])) {
    $search = $_GET['search'] ?? '';
    $search_results = searchProducts($search);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>HackCTF Shop - Boot2Root Challenge</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 10px;
        }
        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
        }
        .login-section, .search-section {
            background: #f8f9fa;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
            border-left: 4px solid #667eea;
        }
        input, button {
            padding: 10px;
            margin: 5px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        button {
            background: #667eea;
            color: white;
            cursor: pointer;
            border: none;
        }
        button:hover {
            background: #764ba2;
        }
        .result {
            margin: 15px 0;
            padding: 10px;
            background: #e8f4f8;
            border-left: 3px solid #0066cc;
            border-radius: 3px;
        }
        .error {
            background: #ffe8e8;
            border-left-color: #cc0000;
            color: #cc0000;
        }
        .success {
            background: #e8f8e8;
            border-left-color: #00cc00;
            color: #00cc00;
        }
        .products {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        .product-card {
            background: #f9f9f9;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .product-card h3 {
            margin-top: 0;
        }
        .hint {
            background: #ffffcc;
            border-left: 3px solid #ffaa00;
            padding: 10px;
            margin: 10px 0;
            border-radius: 3px;
            color: #666;
        }
        code {
            background: #f0f0f0;
            padding: 2px 5px;
            border-radius: 3px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🛒 HackCTF Shop</h1>
        <p class="subtitle">Boot2Root Challenge - Insane Level</p>

        <!-- Login Section -->
        <div class="login-section">
            <h2>Login</h2>
            <form method="POST">
                <input type="hidden" name="action" value="login">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
            <?php if ($login_error): ?>
                <div class="result <?php echo ($login_result ? 'success' : 'error'); ?>">
                    <?php echo htmlspecialchars($login_error); ?>
                </div>
            <?php endif; ?>
            <div class="hint">
                <strong>Hint:</strong> Try <code>admin' OR '1'='1</code> as username...
            </div>
        </div>

        <!-- Product Search Section -->
        <div class="search-section">
            <h2>Search Products</h2>
            <form method="GET">
                <input type="text" name="search" placeholder="Search products..." value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
                <button type="submit">Search</button>
            </form>

            <?php if (!empty($search_results)): ?>
                <h3>Search Results (<?php echo count($search_results); ?> found)</h3>
                <div class="products">
                    <?php foreach ($search_results as $product): ?>
                        <div class="product-card">
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p><?php echo htmlspecialchars($product['description']); ?></p>
                            <p><strong>Price:</strong> $<?php echo htmlspecialchars($product['price']); ?></p>
                            <?php if (!empty($product['secret'])): ?>
                                <p style="color: #ff6600;"><code><?php echo htmlspecialchars($product['secret']); ?></code></p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="hint">
                <strong>Research Hint:</strong> Try SQL injection techniques here to extract database information!
            </div>
        </div>

        <!-- Information Section -->
        <div style="background: #f0f7ff; padding: 15px; border-radius: 5px; margin-top: 20px;">
            <h3>System Information</h3>
            <p>PHP Version: <?php echo phpversion(); ?></p>
            <p>Server: <?php echo $_SERVER['SERVER_SOFTWARE']; ?></p>
            <p>Hostname: <?php echo gethostname(); ?></p>
        </div>
    </div>
</body>
</html>
