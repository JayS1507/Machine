@echo off
echo.
echo ════════════════════════════════════════════════════════════════
echo     HackCTF Boot2Root - Production Deployment (Windows)
echo ════════════════════════════════════════════════════════════════
echo.

docker --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Docker is not installed!
    echo Please install Docker Desktop: https://www.docker.com/products/docker-desktop
    pause
    exit /b 1
)

echo ✓ Docker found
echo.

echo Building Docker image...
docker build -t hackctf-boot2root .
if errorlevel 1 (
    echo ERROR: Failed to build image
    pause
    exit /b 1
)
echo ✅ Image built successfully!
echo.

echo Starting CTF machine...
docker run -d --name hackctf-boot2root -p 2222:22 -p 8080:80 -p 3306:3306 -p 21:21 --restart unless-stopped hackctf-boot2root:latest

timeout /t 3 /nobreak

docker ps | findstr hackctf-boot2root >nul
if errorlevel 1 (
    echo ERROR: Failed to start container
    pause
    exit /b 1
)

echo.
echo ════════════════════════════════════════════════════════════════
echo MACHINE IS READY!
echo ════════════════════════════════════════════════════════════════
echo.
echo Access Information:
echo   • Web App:    http://localhost:8080
echo   • SSH:        localhost:2222 (user: user, pass: user123)
echo   • MySQL:      localhost:3306 (user: ctf_user, pass: ctf_pass123)
echo.
echo To stop: docker stop hackctf-boot2root
echo.
pause
