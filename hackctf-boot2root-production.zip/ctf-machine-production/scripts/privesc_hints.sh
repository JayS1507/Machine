#!/bin/bash
# Privilege escalation vectors available:

echo "=== Privilege Escalation Paths ==="
echo ""
echo "Path 1: SUID Binary Exploitation"
echo "  Command: vuln_cat /root/root.txt"
echo "  This SUID binary has command injection vulnerability"
echo ""
echo "Path 2: Sudo NOPASSWD"
echo "  Check: sudo -l"
echo "  Command: sudo cat /root/root.txt"
echo ""
echo "Path 3: Weak file permissions"
echo "  Check: ls -la /opt/sensitive/"
echo "  The flag file is world-readable"
echo ""
