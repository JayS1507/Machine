#!/bin/bash
# Enhanced initialization script for HackCTF Boot2Root v2.0

echo "[*] Starting HackCTF Boot2Root - Enhanced Edition..."

# Start MariaDB service
echo "[+] Starting MariaDB..."
service mariadb start

sleep 2

# Initialize MySQL database if needed
echo "[+] Initializing database..."
mysql -u root << EOF
CREATE DATABASE IF NOT EXISTS ctf_db;
CREATE USER IF NOT EXISTS 'ctf_user'@'localhost' IDENTIFIED BY 'ctf_pass123';
GRANT ALL PRIVILEGES ON ctf_db.* TO 'ctf_user'@'localhost';
FLUSH PRIVILEGES;
EOF

# Import SQL setup
echo "[+] Loading database schema..."
mysql -u ctf_user -pctf_pass123 ctf_db < /setup.sql

# Start SSH
echo "[+] Starting SSH..."
service ssh start

# Start FTP
echo "[+] Starting FTP service..."
service vsftpd start 2>/dev/null || true

# Create API server in background (hidden service)
echo "[+] Starting hidden API server..."
python3 << 'PYTHON_SCRIPT' &
#!/usr/bin/env python3
import http.server
import socketserver
import json
import sys

class APIHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/api/status':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            response = json.dumps({'status': 'running', 'version': '2.0'})
            self.wfile.write(response.encode())
        else:
            self.send_response(404)
            self.end_headers()

try:
    PORT = 8888
    with socketserver.TCPServer(("127.0.0.1", PORT), APIHandler) as httpd:
        pass
except Exception as e:
    sys.exit(1)
PYTHON_SCRIPT

# Start Apache in foreground
echo "[+] Starting Apache..."
apache2ctl -D FOREGROUND &
APACHE_PID=$!

# Create hint files in home directories
echo "[+] Setting up hint files..."
mkdir -p /home/user/hints
echo "Blind SQL injection hints: /enhanced-api.php?action=check_user" > /home/user/hints/exploitation.txt
chmod 644 /home/user/hints/exploitation.txt

echo "[*] System initialization complete!"
echo "[*] Services running:"
echo "    - SSH: ports 22, 2121"
echo "    - Apache: port 80"  
echo "    - MySQL: port 3306"
echo "    - FTP: port 21"
echo "    - API: port 8888 (localhost only)"

# Wait for Apache
wait $APACHE_PID
