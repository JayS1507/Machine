#!/bin/bash

# Start MariaDB service
service mariadb start

# Initialize MySQL database if needed
mysql -u root << EOF
CREATE DATABASE IF NOT EXISTS ctf_db;
CREATE USER IF NOT EXISTS 'ctf_user'@'localhost' IDENTIFIED BY 'ctf_pass123';
GRANT ALL PRIVILEGES ON ctf_db.* TO 'ctf_user'@'localhost';
FLUSH PRIVILEGES;
EOF

# Import SQL setup
mysql -u ctf_user -pctf_pass123 ctf_db < /setup.sql

# Start SSH
service ssh start

# Start Apache in foreground
apache2ctl -D FOREGROUND
