#!/bin/bash
# Setup FTP service with hints directory

# Install vsftpd
apt-get update > /dev/null 2>&1
apt-get install -y vsftpd > /dev/null 2>&1

# Create FTP directory structure
mkdir -p /home/ftpuser/files
mkdir -p /home/ftpuser/hints

# Create hint files
cat > /home/ftpuser/hints/hint1.txt << 'EOF'
Hint 1: Blind SQL Injection
=============================
The web app at port 8080 has blind SQL injection vulnerability.
Try accessing: /enhanced-api.php?action=check_user&username=admin' OR '1'='1
Time-based detection available at: /enhanced-api.php?action=timing_attack
EOF

cat > /home/ftpuser/hints/hint2.txt << 'EOF'
Hint 2: Multiple Exploitation Vectors
======================================
Users on this system:
- www-data (web server)
- ctf_user (database user)
- developer (developer account)
- root

Each has different privileges. Lateral movement required.
EOF

cat > /home/ftpuser/hints/hidden_services.txt << 'EOF'
Hidden Services Running:
========================
Port 8888: Python API Server (localhost only)
Port 9000: Admin Dashboard (requires authentication)
Port 2121: Alternative SSH (non-standard)

Use: ssh -p 2121 user@localhost or tunneling to access
EOF

# Create fake flag (misdirection)
cat > /home/ftpuser/hints/fake_flag.txt << 'EOF'
HackCTF{this_is_fake_flag_xxxx}

This is a decoy. The real flag requires deeper exploitation.
EOF

# Setup FTP configuration
cat > /etc/vsftpd.conf << 'EOF'
listen=YES
listen_ipv6=NO
anonymous_enable=YES
anon_root=/home/ftpuser
anon_upload_enable=NO
anon_mkdir_write_enable=NO
anon_other_write_enable=NO
local_enable=NO
write_enable=NO
dirmessage_enable=YES
xferlog_enable=YES
connect_from_port_20=YES
chroot_list_enable=NO
secure_chroot_dir=/var/run/vsftpd/empty
pam_service_name=vsftpd
rsa_cert_file=/etc/ssl/certs/ssl-cert-snakeoil.pem
rsa_private_key_file=/etc/ssl/private/ssl-cert-snakeoil.key
ssl_enable=NO
pasv_enable=YES
pasv_min_port=21000
pasv_max_port=21100
EOF

# Start FTP service
service vsftpd restart

echo "✓ FTP Service configured"
