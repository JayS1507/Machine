#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <command>\n", argv[0]);
        return 1;
    }

    // VULNERABLE: Using user input directly in system() call
    // This allows arbitrary command execution
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "cat %s", argv[1]);
    
    // SUID allows this to run as root
    system(cmd);
    
    return 0;
}
