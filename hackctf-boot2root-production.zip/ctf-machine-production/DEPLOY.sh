#!/bin/bash

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║     HackCTF Boot2Root - Production Deployment Script           ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ ERROR: Docker is not installed!"
    echo "Please install Docker first: https://docs.docker.com/install/"
    exit 1
fi

echo "✓ Docker found"
echo ""

# Build the image
echo "📦 Building Docker image..."
docker build -t hackctf-boot2root . || exit 1
echo "✅ Image built successfully!"
echo ""

# Run the container
echo "🚀 Starting CTF machine..."
docker run -d \
  --name hackctf-boot2root \
  -p 2222:22 \
  -p 8080:80 \
  -p 3306:3306 \
  -p 21:21 \
  --restart unless-stopped \
  hackctf-boot2root:latest

sleep 3

# Verify
if docker ps | grep -q hackctf-boot2root; then
    echo "✅ Container started successfully!"
    echo ""
    echo "════════════════════════════════════════════════════════════════"
    echo "🎉 MACHINE IS READY!"
    echo "════════════════════════════════════════════════════════════════"
    echo ""
    echo "📝 Access Information:"
    echo "  • Web App:    http://localhost:8080"
    echo "  • SSH:        ssh -p 2222 localhost (user: user, pass: user123)"
    echo "  • MySQL:      localhost:3306 (user: ctf_user, pass: ctf_pass123)"
    echo "  • Database:   ctf_db"
    echo ""
    echo "🚩 Flags:"
    echo "  • Flag 1: HackCTF{user_pwned_the_app} (200 pts)"
    echo "  • Flag 2: HackCTF{lateral_movement_success} (300 pts)"
    echo "  • Flag 3: HackCTF{exploited_suid_binary} (300 pts)"
    echo "  • Flag 4: HackCTF{root_of_all_evil} (400 pts)"
    echo ""
    echo "📚 Documentation:"
    echo "  • README.md - Technical documentation"
    echo "  • SOLUTIONS-v2.md - Exploitation guide"
    echo "  • QUICKSTART.md - Quick reference"
    echo ""
    echo "🛑 To stop the machine:"
    echo "  docker stop hackctf-boot2root"
    echo ""
    echo "🗑️  To remove the machine:"
    echo "  docker stop hackctf-boot2root && docker rm hackctf-boot2root"
    echo ""
else
    echo "❌ Failed to start container!"
    exit 1
fi
