#!/bin/bash
# =============================================================================
#  DrupalGate-2 CTF Machine — Entrypoint / Setup Script
#  Runs once on first start to install WordPress, create users, plant flags.
#  On subsequent starts it skips already-done steps and just restarts services.
# =============================================================================

# Do NOT use set -e — service/wp-cli warnings must not crash the container

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()    { echo -e "${CYAN}[*]${NC} $1"; }
success() { echo -e "${GREEN}[✓]${NC} $1"; }
warn()    { echo -e "${YELLOW}[!]${NC} $1"; }

echo -e "${RED}"
cat << 'BANNER'
  ____   ____      ____   ____ _____ _____   __  __            _     _
 |  _ \ / ___|    / ___| |  _ \_   _|  ___| |  \/  | __ _  ___| |__ (_)_ __   ___
 | | | | |   _____| |     | |_) || | | |_    | |\/| |/ _` |/ __| '_ \| | '_ \ / _ \
 | |_| | |__|_____| |___  |  __/ | | |  _|   | |  | | (_| | (__| | | | | | | |  __/
 |____/ \____|     \____| |_|    |_| |_|     |_|  |_|\__,_|\___|_| |_|_|_| |_|\___|

                      Beginner CTF — WordPress + SSH + Git privesc
BANNER
echo -e "${NC}"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 1 — MySQL / MariaDB
# ─────────────────────────────────────────────────────────────────────────────
info "Starting MariaDB..."
mkdir -p /var/run/mysqld
chown -R mysql:mysql /var/lib/mysql /var/run/mysqld 2>/dev/null || true

# Initialise data directory if missing (first-ever run on a fresh volume)
if [ ! -d /var/lib/mysql/mysql ]; then
    info "Initialising MariaDB data directory..."
    mysql_install_db --user=mysql --datadir=/var/lib/mysql 2>/dev/null || true
fi

# On Debian Bullseye the service is called 'mariadb', not 'mysql'
service mariadb start || service mysql start || mysqld_safe --user=mysql &
sleep 6

# Create WordPress DB and user
info "Provisioning WordPress database..."
mysql -u root 2>/dev/null <<'SQL'
CREATE DATABASE IF NOT EXISTS wordpress CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'wpuser'@'localhost' IDENTIFIED BY 'wppassword123';
GRANT ALL PRIVILEGES ON wordpress.* TO 'wpuser'@'localhost';
FLUSH PRIVILEGES;
SQL
success "Database ready"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 2 — WordPress
# ─────────────────────────────────────────────────────────────────────────────
WP="/var/www/html"

# wp-config.php lives in the container filesystem (not a volume) so it is
# lost every time the image is rebuilt. Always recreate it if missing.
if [ ! -f "$WP/wp-config.php" ]; then
    info "Creating wp-config.php..."
    wp config create \
        --dbname=wordpress \
        --dbuser=wpuser \
        --dbpass=wppassword123 \
        --dbhost=localhost \
        --path="$WP" \
        --allow-root --quiet
    chown www-data:www-data "$WP/wp-config.php"
fi

# Gate the FULL install on the DATABASE — the MariaDB volume persists across
# container rebuilds, so WordPress may already be installed even when
# wp-config.php had to be recreated above.
if ! wp core is-installed --path="$WP" --allow-root 2>/dev/null; then

    info "Running WordPress core install..."
    wp core install \
        --url="http://drupalgate-2" \
        --title="DrupalGate-2" \
        --admin_user="admin" \
        --admin_password="SecureAdm1n!" \
        --admin_email="admin@drupalgate-2.local" \
        --skip-email \
        --path="$WP" \
        --allow-root --quiet

    # Force siteurl / home to drupalgate-2 hostname  ← makes nmap show the redirect
    wp option update siteurl 'http://drupalgate-2'  --path="$WP" --allow-root --quiet
    wp option update home    'http://drupalgate-2'  --path="$WP" --allow-root --quiet

    info "Creating WordPress users (tom / jerry)..."
    wp user create tom   tom@drupalgate-2.local   --role=author --user_pass="parturient" --path="$WP" --allow-root --quiet
    wp user create jerry jerry@drupalgate-2.local --role=editor --user_pass="adipiscing"  --path="$WP" --allow-root --quiet

    info "Setting pretty-permalink structure..."
    wp rewrite structure '/%postname%/' --hard --path="$WP" --allow-root --quiet

    # ── Create pages ───────────────────────────────────────────────────────
    info "Creating WordPress pages..."

    WELCOME_ID=$(wp post create \
        --post_title="Welcome" \
        --post_content="<p>Welcome to DrupalGate-2.</p>
<p>This is a purposely built vulnerable website for gaining experience in the world of penetration testing.</p>
<p>Unlike the original, you cannot SSH in as root. DrupalGate-2 requires a more methodical approach — enumerate, brute-force, escape, and escalate.</p>
<p>The important thing is to enjoy the journey.</p>
<p>Good luck!</p>" \
        --post_status="publish" \
        --post_type="page" \
        --path="$WP" --allow-root --porcelain 2>/dev/null)

    # ── "What We Do" page ─────────────────────────────────────────────────
    # IMPORTANT: Must contain 'adipiscing' and 'parturient' so cewl can
    # harvest them and build a valid password wordlist.
    wp post create \
        --post_title="What We Do" \
        --post_content="<p>Lorem ipsum dolor sit amet, consectetur <strong>adipiscing</strong> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p>
<p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, <em>adipiscing</em> elit, sed quia non numquam eius modi tempora incidunt.</p>" \
        --post_status="publish" \
        --post_type="page" \
        --path="$WP" --allow-root --quiet

    # ── "Our People" page ─────────────────────────────────────────────────
    # Also includes 'parturient' for the cewl wordlist
    wp post create \
        --post_title="Our People" \
        --post_content="<p>At DrupalGate-2, our people are our greatest asset. We have a dedicated team of professionals working together towards our common goals.</p>
<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. <strong>Parturient</strong> montes, nascetur ridiculus mus. Vivamus magna. Fusce sed sem sed magna suscipit egestas.</p>
<p>Curabitur aliquet quam id dui posuere blandit. Lorem ipsum dolor sit amet, consectetur <em>adipiscing</em> elit. Vivamus lacinia odio vitae vestibulum vestibulum. Donec in efficitur leo, in commodo orci. Donec in interdum ligula.</p>
<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. <em>Parturient</em> montes nascetur ridiculus mus donec adipiscing tristique.</p>" \
        --post_status="publish" \
        --post_type="page" \
        --path="$WP" --allow-root --quiet

    # ── "Our Products" page ───────────────────────────────────────────────
    wp post create \
        --post_title="Our Products" \
        --post_content="<p>Our products are designed with quality and performance in mind. We offer a wide range of solutions tailored to meet your specific needs.</p>
<p>Quisque velit nisi, pretium ut lacinia in, elementum id enim. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, <strong>parturient</strong> at eros. Proin eget tortor risus.</p>
<p>Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Nulla porttitor accumsan tincidunt. Cras ultricies ligula sed magna dictum porta. Donec rutrum congue leo eget malesuada. Pellentesque in ipsum id orci porta dapibus.</p>
<p>Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Curabitur aliquet quam id dui posuere blandit. Consectetur <em>adipiscing</em> elit proin eget tortor risus pellentesque.</p>" \
        --post_status="publish" \
        --post_type="page" \
        --path="$WP" --allow-root --quiet

    # ── Flag page (public) — Flag 1 ───────────────────────────────────────
    FLAG_PAGE_ID=$(wp post create \
        --post_title="Flag" \
        --post_content="<h2>FLAG</h2>
<p><strong>Flag 1: <code>HackCTF{W0rdl1sts_Ar3_S0_L4st_Y34r_B3_C3wl}</code></strong></p>
<p>Your usual wordlists probably won't work, so instead, maybe you just need to be cewl.</p>
<p>More passwords is always better, but sometimes you just can't win them all.</p>
<p>Log in as one to see the next flag.</p>
<p>If you can't find it, log in as another.</p>" \
        --post_status="publish" \
        --post_type="page" \
        --path="$WP" --allow-root --porcelain 2>/dev/null)

    # ── Flag 2 private post (visible to jerry after WordPress login) ───────
    JERRY_ID=$(wp user get jerry --field=ID --path="$WP" --allow-root 2>/dev/null || echo "3")
    wp post create \
        --post_title="Flag 2" \
        --post_content="<h2>Flag 2</h2>
<p><strong>HackCTF{Kn0ck_Kn0ck_SSH_0n_P0rt_7744_Is_0p3n}</strong></p>
<p>If you can't exploit WordPress and take a shortcut, you'll need to find another way in.</p>
<p>Hint: What if there's another entry point? Not every service runs on its default port.</p>
<p>Good luck!</p>" \
        --post_status="private" \
        --post_author="${JERRY_ID}" \
        --post_type="post" \
        --path="$WP" --allow-root --quiet

    # ── Navigation menu matching original DC-2 ────────────────────────────
    info "Building navigation menu..."
    wp menu create "Primary Menu" --path="$WP" --allow-root --quiet

    wp menu item add-custom primary-menu "Welcome"      "http://drupalgate-2/welcome/"      --path="$WP" --allow-root --quiet
    wp menu item add-custom primary-menu "What We Do"   "http://drupalgate-2/what-we-do/"   --path="$WP" --allow-root --quiet
    wp menu item add-custom primary-menu "Our People"   "http://drupalgate-2/our-people/"   --path="$WP" --allow-root --quiet
    wp menu item add-custom primary-menu "Our Products" "http://drupalgate-2/our-products/" --path="$WP" --allow-root --quiet
    wp menu item add-custom primary-menu "Flag"         "http://drupalgate-2/flag/"         --path="$WP" --allow-root --quiet

    wp menu location assign primary-menu primary    --path="$WP" --allow-root --quiet 2>/dev/null || true
    wp menu location assign primary-menu header-menu --path="$WP" --allow-root --quiet 2>/dev/null || true

    # ── Set Welcome as static front page ─────────────────────────────────
    wp option update show_on_front  'page'          --path="$WP" --allow-root --quiet
    wp option update page_on_front  "${WELCOME_ID}" --path="$WP" --allow-root --quiet

    # ── Remove sample Hello World post and sample page ────────────────────
    wp post delete 1 --force --path="$WP" --allow-root --quiet 2>/dev/null || true
    wp post delete 2 --force --path="$WP" --allow-root --quiet 2>/dev/null || true

    # ── Fix file ownership ────────────────────────────────────────────────
    chown -R www-data:www-data "$WP"
    chmod -R 755 "$WP"

    # ── Activate Drupal 7 Bartik theme ───────────────────────────────────
    info "Activating Drupal 7 Bartik theme..."
    wp theme activate drupal7-bartik --path="$WP" --allow-root --quiet

    success "WordPress fully configured!"
else
    # WordPress DB already populated (persistent volume) — just sync URLs
    info "WordPress already installed — syncing site URL..."
    wp option update siteurl 'http://drupalgate-2' --path="$WP" --allow-root --quiet
    wp option update home    'http://drupalgate-2' --path="$WP" --allow-root --quiet
    warn "WordPress DB already configured — skipping full install."
fi

# /var/www/html is rebuilt with the image while the database persists in a
# Docker volume. Recreate filesystem-backed WordPress state on every start.
info "Refreshing WordPress theme and permalink rules..."
CANONICAL_WELCOME_ID=$(wp post list \
    --post_type=page \
    --post_status=publish \
    --name=welcome \
    --field=ID \
    --path="$WP" --allow-root 2>/dev/null | head -n 1)

if [ -n "$CANONICAL_WELCOME_ID" ]; then
    wp option update show_on_front 'page' --path="$WP" --allow-root --quiet
    wp option update page_on_front "$CANONICAL_WELCOME_ID" --path="$WP" --allow-root --quiet
fi

wp theme activate drupal7-bartik --path="$WP" --allow-root --quiet 2>/dev/null || true
wp rewrite structure '/%postname%/' --hard --path="$WP" --allow-root --quiet
wp rewrite flush --hard --path="$WP" --allow-root --quiet
cat > "$WP/.htaccess" <<'HTACCESS'
# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
RewriteBase /
RewriteRule ^index\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]
</IfModule>
# END WordPress
HTACCESS
chown www-data:www-data "$WP/.htaccess"
chmod 644 "$WP/.htaccess"
success "WordPress theme and permalinks ready"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 3 — System Users
# ─────────────────────────────────────────────────────────────────────────────
info "Setting up system users..."

# ── tom — restricted bash (rbash) ─────────────────────────────────────────
if ! id -u tom &>/dev/null; then
    useradd -m -d /home/tom -s /bin/rbash tom
    echo "tom:parturient" | chpasswd

    # Restricted bin: only ls, vi, less, echo  (NO cat — forces vi escape)
    mkdir -p /home/tom/usr/bin
    ln -sf /bin/ls       /home/tom/usr/bin/ls
    ln -sf /usr/bin/vi   /home/tom/usr/bin/vi
    ln -sf /bin/less     /home/tom/usr/bin/less
    ln -sf /bin/echo     /home/tom/usr/bin/echo

    # Locked-down .bashrc sets a restricted PATH
    cat > /home/tom/.bashrc << 'BASHRC'
# Restricted environment for tom
export PATH=/home/tom/usr/bin
export HOME=/home/tom
BASHRC

    cat > /home/tom/.bash_profile << 'BASHPROF'
[ -f ~/.bashrc ] && source ~/.bashrc
BASHPROF

    # Make .bashrc immutable so rbash can't be bypassed by editing it
    chmod 444 /home/tom/.bashrc

    # ── Flag 3 ─────────────────────────────────────────────────────────
    cat > /home/tom/flag3.txt << 'FLAG3'
HackCTF{Fr33d0m_Fr0m_Th3_C4g3_V1_3sc4p3d_rB4sh}

Flag 3:

Poor old Tom always goes after Jerry, but this time Jerry might actually hold the key.

Hint: sudo can be a bit of a git... I'll leave this for you to discover.
FLAG3

    chown -R tom:tom /home/tom
    chmod 700 /home/tom
    chmod 644 /home/tom/flag3.txt

    success "User 'tom' created with rbash restricted shell"
fi

# ── jerry — normal bash ────────────────────────────────────────────────────
if ! id -u jerry &>/dev/null; then
    useradd -m -d /home/jerry -s /bin/bash jerry
    echo "jerry:adipiscing" | chpasswd

    # ── Flag 4 ─────────────────────────────────────────────────────────
    cat > /home/jerry/flag4.txt << 'FLAG4'
HackCTF{G1t_Y0ur_W4y_T0_Th3_T0p_Supr3m3}

Flag 4:

Good to see that you've made it this far — what an interesting path it's been!

Now, you need to find a way to get root access. Remember, sudo is your friend (or git is...).

Hint: Check what tom can run as root without a password. Can you take advantage of that?
FLAG4

    chown -R jerry:jerry /home/jerry
    chmod 644 /home/jerry/flag4.txt

    success "User 'jerry' created"
fi

# ─────────────────────────────────────────────────────────────────────────────
# STEP 4 — Sudo Configuration
# ─────────────────────────────────────────────────────────────────────────────
info "Configuring sudoers..."
cat > /etc/sudoers.d/tom-git << 'SUDOERS'
# tom can run git as root without a password — GTFOBins exploit path
tom ALL=(root) NOPASSWD: /usr/bin/git
SUDOERS
chmod 440 /etc/sudoers.d/tom-git
success "sudo: tom → git (NOPASSWD) configured"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 5 — Root / Final Flag
# ─────────────────────────────────────────────────────────────────────────────
cat > /root/final-flag.txt << 'FINALFLAG'

██╗  ██╗ █████╗  ██████╗██╗  ██╗ ██████╗████████╗███████╗    ██████╗ 
██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝╚══██╔══╝██╔════╝    ╚════██╗
███████║███████║██║     █████╔╝ ██║        ██║   █████╗       █████╔╝
██╔══██║██╔══██║██║     ██╔═██╗ ██║        ██║   ██╔══╝      ██╔═══╝ 
██║  ██║██║  ██║╚██████╗██║  ██╗╚██████╗   ██║   ██║         ███████╗
╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝ ╚═════╝   ╚═╝   ╚═╝         ╚══════╝

  DrupalGate-2 — PWNED!

  HackCTF{Y0u_Pwn3d_DrupalGate-2_GG_W3ll_Pl4y3d!}

Congratulations!!!

You've successfully completed DrupalGate-2. Hope you enjoyed it.

Just like a kid in a candy store... keep learning, keep hacking, keep having fun!

        — HackCTF Series —
FINALFLAG

chmod 600 /root/final-flag.txt
success "Final flag planted at /root/final-flag.txt"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 6 — Start Services
# ─────────────────────────────────────────────────────────────────────────────
info "Starting Apache2 (port 80)..."
service apache2 restart || service apache2 start
success "Apache running"

info "Starting OpenSSH (port 7744)..."
service ssh start
success "SSH running"

# Ensure MariaDB stays up (it may have been stopped by restart logic)
service mariadb status >/dev/null 2>&1 || service mariadb start 2>/dev/null || true

# ─────────────────────────────────────────────────────────────────────────────
# Ready banner
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║        DrupalGate-2 CTF Machine is READY!               ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║${NC}  Web  → http://drupalgate-2/       (port 80)             ${GREEN}║${NC}"
echo -e "${GREEN}║${NC}  SSH  → port 7744                                        ${GREEN}║${NC}"
echo -e "${GREEN}║${NC}                                                           ${GREEN}║${NC}"
echo -e "${GREEN}║${NC}  On your attacker machine add to /etc/hosts:              ${GREEN}║${NC}"
echo -e "${GREEN}║${NC}    <CONTAINER_IP>   drupalgate-2                          ${GREEN}║${NC}"
echo -e "${GREEN}║${NC}                                                           ${GREEN}║${NC}"
echo -e "${GREEN}║${NC}  Then scan:  nmap -p- -A <CONTAINER_IP>                   ${GREEN}║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Keep the container alive — never exit so Docker doesn't restart us
exec tail -f /var/log/apache2/access.log /var/log/auth.log /var/log/mysql/error.log 2>/dev/null || exec sleep infinity
