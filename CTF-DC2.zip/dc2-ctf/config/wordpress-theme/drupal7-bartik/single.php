<?php
/**
 * single.php — Drupal 7-style single post
 */
get_header(); ?>

  <div id="main-wrapper" class="clearfix">
    <div id="main" class="clearfix">

      <div id="content" class="column">
        <div class="section">

          <?php while ( have_posts() ) : the_post(); ?>

            <h1 class="page-title"><?php the_title(); ?></h1>

            <article id="node-<?php the_ID(); ?>" class="node node-article clearfix">
              <div class="submitted">
                Submitted by
                <span class="username"><?php the_author(); ?></span>
                on <?php echo get_the_date(); ?>
              </div>
              <div class="node-body">
                <?php the_content(); ?>
                <?php wp_link_pages(); ?>
              </div>
              <div class="node-links">
                <?php
                  $cats = get_the_category_list( ', ' );
                  if ( $cats ) echo '<span class="field-label">Tags:</span> ' . $cats;
                ?>
              </div>
            </article>

            <nav class="pager clearfix" aria-label="Post navigation">
              <div style="float:left">
                <?php previous_post_link( '%link', '‹ %title' ); ?>
              </div>
              <div style="float:right">
                <?php next_post_link( '%link', '%title ›' ); ?>
              </div>
            </nav>

          <?php endwhile; ?>

        </div><!-- /.section -->
      </div><!-- /#content -->

      <?php get_sidebar(); ?>

    </div><!-- /#main -->
  </div><!-- /#main-wrapper -->

<?php get_footer(); ?>
