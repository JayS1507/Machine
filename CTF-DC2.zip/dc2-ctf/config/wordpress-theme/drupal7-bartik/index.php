<?php get_header(); ?>

<div id="main-wrapper">
  <div id="main" class="clearfix">

    <div id="content">
      <?php bartik_page_title(); ?>

      <?php if ( have_posts() ) : ?>
        <?php while ( have_posts() ) : the_post(); ?>
          <div class="node <?php echo is_sticky() ? 'node-sticky node-promoted' : ''; ?> clearfix">
            <h2 class="node-title">
              <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h2>
            <div class="submitted">
              Submitted by <strong><?php the_author(); ?></strong>
              on <?php echo get_the_date('D, m/d/Y - G:i'); ?>
            </div>
            <div class="field node-body">
              <?php the_excerpt(); ?>
            </div>
            <ul class="links inline">
              <li class="node-readmore">
                <a href="<?php the_permalink(); ?>">Read more<span class="element-invisible"> about <?php the_title(); ?></span></a>
              </li>
            </ul>
          </div>
        <?php endwhile; ?>

        <div class="pager-wrapper">
          <?php the_posts_pagination( array( 'prev_text' => '‹ previous', 'next_text' => 'next ›' ) ); ?>
        </div>

      <?php else : ?>
        <div class="messages status"><p>No content available.</p></div>
      <?php endif; ?>
    </div><!-- /#content -->

    <?php get_sidebar(); ?>

  </div><!-- /#main -->
</div><!-- /#main-wrapper -->

<?php get_footer(); ?>
