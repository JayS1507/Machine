<?php
/**
 * sidebar.php - Drupal 7 Bartik style sidebar
 * Three blocks: User login, Public resources, Search
 */
?>
<div id="sidebar-second">

  <!-- Block: User login (realistic Drupal sidebar login form) -->
  <div class="block block-user-login">
    <h2 class="block-title">User login</h2>
    <div class="block-content">
      <form method="post" action="<?php echo wp_login_url(); ?>">
        <div class="form-item">
          <label for="sidebar-username">Username</label>
          <input type="text" id="sidebar-username" name="log" autocomplete="username">
        </div>
        <div class="form-item">
          <label for="sidebar-password">Password</label>
          <input type="password" id="sidebar-password" name="pwd" autocomplete="current-password">
        </div>
        <?php wp_nonce_field('wplogin'); ?>
        <input type="hidden" name="redirect_to" value="<?php echo esc_attr( admin_url() ); ?>">
        <input type="submit" value="Log in">
        <a class="request-password" href="<?php echo wp_lostpassword_url(); ?>">Request new password</a>
      </form>
    </div>
  </div>

  <!-- Block: Navigation -->
  <div class="block block-public-resources">
    <h2 class="block-title">Navigation</h2>
    <div class="block-content">
      <ul>
        <?php
          foreach ( bartik_primary_links( false ) as $link ) {
            echo '<li><a href="' . esc_url( $link['url'] ) . '">' . esc_html( $link['label'] ) . '</a></li>';
          }
        ?>
      </ul>
    </div>
  </div>

  <!-- Block: Search -->
  <div class="block block-search">
    <h2 class="block-title">Search</h2>
    <div class="block-content">
      <form method="get" action="<?php echo home_url('/'); ?>" role="search">
        <input type="text" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="">
        <input type="submit" value="Search">
      </form>
    </div>
  </div>

</div><!-- /#sidebar-second -->
