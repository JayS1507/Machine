  <div id="footer-wrapper">
    <div class="section">
      <div class="powered-by">
        Powered by <a href="https://www.drupal.org" target="_blank">Drupal</a>
      </div>
      <div class="copyright">
        &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?> &mdash;
        <a href="<?php echo home_url('/'); ?>">Home</a>
      </div>
    </div>
  </div><!-- /#footer-wrapper -->

</div><!-- /#page -->
</div><!-- /#page-wrapper -->

<?php wp_footer(); ?>
</body>
</html>
