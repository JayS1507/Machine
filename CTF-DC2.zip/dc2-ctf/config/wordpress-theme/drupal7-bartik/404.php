<?php
/**
 * 404.php - Drupal 7-style 404 page
 */
get_header(); ?>

  <div id="main-wrapper" class="clearfix">
    <div id="main" class="clearfix">

      <div id="content" class="column">
        <div class="section">

          <h1 class="page-title">Page not found</h1>

          <div class="messages status">
            <p>The requested page could not be found. Check the URL for errors, or try going back to <a href="<?php echo home_url('/'); ?>">the home page</a>.</p>
          </div>

          <div class="search-form-wrapper">
            <?php get_search_form(); ?>
          </div>

        </div>
      </div>

      <?php get_sidebar(); ?>
    </div>
  </div>

<?php get_footer(); ?>
