<?php get_header(); ?>

<div id="main-wrapper">
  <div id="main" class="clearfix">

    <!-- Content -->
    <div id="content">

      <?php while ( have_posts() ) : the_post(); ?>
        <div class="node node-page view-mode-full">
          <h1 id="page-title" class="page-title"><?php the_title(); ?></h1>
          <div class="field node-body">
            <?php the_content(); ?>
            <?php wp_link_pages(); ?>
          </div>
        </div>
      <?php endwhile; ?>

    </div><!-- /#content -->

    <?php get_sidebar(); ?>

  </div><!-- /#main -->
</div><!-- /#main-wrapper -->

<?php get_footer(); ?>
