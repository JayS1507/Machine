<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="Generator" content="Drupal 7 (https://www.drupal.org)">
<meta name="MobileOptimized" content="width">
<meta name="HandheldFriendly" content="true">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div id="page-wrapper">
<div id="page" class="clearfix">

  <div id="header">
    <div class="section">
      <a id="logo" href="<?php echo esc_url( home_url('/') ); ?>" title="Home" rel="home">
        <img src="<?php echo esc_url( get_template_directory_uri() . '/images/logo.svg' ); ?>" alt="<?php echo esc_attr( get_bloginfo('name') ); ?>">
      </a>
      <div id="name-and-slogan">
        <div id="site-name">
          <a href="<?php echo esc_url( home_url('/') ); ?>" title="Home" rel="home"><?php bloginfo('name'); ?></a>
        </div>
        <?php if ( get_bloginfo('description') ) : ?>
          <div id="site-slogan"><?php bloginfo('description'); ?></div>
        <?php endif; ?>
      </div>
    </div>
  </div><!-- /#header -->

  <div id="navigation">
    <div class="section">
      <?php
        if ( has_nav_menu('primary') ) {
          wp_nav_menu( array(
            'theme_location' => 'primary',
            'menu_class'     => 'menu nav-menu clearfix',
            'container'      => false,
            'walker'         => new Bartik_Nav_Walker(),
            'fallback_cb'    => false,   // no fallback — prevents triple nav
          ) );
        } else {
          echo '<ul class="menu nav-menu clearfix">';
          foreach ( bartik_primary_links() as $link ) {
            $is_current = ( $link['id'] && is_page( $link['id'] ) ) || ( 'Home' === $link['label'] && is_front_page() );
            echo '<li' . ( $is_current ? ' class="current_page_item"' : '' ) . '>';
            echo '<a href="' . esc_url( $link['url'] ) . '">' . esc_html( $link['label'] ) . '</a>';
            echo '</li>';
          }
          echo '</ul>';
        }
      ?>
    </div>
  </div><!-- /#navigation -->

  <?php bartik_breadcrumb_wrapper(); ?>
