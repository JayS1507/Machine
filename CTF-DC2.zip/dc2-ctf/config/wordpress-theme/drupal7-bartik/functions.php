<?php
/**
 * Drupal 7 Bartik Style - WordPress Theme Functions
 * Version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ─── Theme Setup ─── */
function bartik_setup() {
    load_theme_textdomain( 'drupal7-bartik', get_template_directory() . '/languages' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
    add_theme_support( 'automatic-feed-links' );
    register_nav_menus( array(
        'primary' => __( 'Primary Navigation', 'drupal7-bartik' ),
    ) );
}
add_action( 'after_setup_theme', 'bartik_setup' );

/* Stylesheet only. */
function bartik_scripts() {
    wp_enqueue_style( 'bartik-style', get_stylesheet_uri(), array(), '4.0' );
}
add_action( 'wp_enqueue_scripts', 'bartik_scripts' );

/* ─── Disable unneeded WordPress extras ─── */
add_filter( 'use_default_gallery_style', '__return_false' );
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );

/* ─── No sidebar registration (we hardcode Drupal blocks in sidebar.php) ─── */

function bartik_page_link_for( $path, $title ) {
    $page = get_page_by_path( $path, OBJECT, 'page' );

    if ( ! $page ) {
        $pages = get_pages( array(
            'post_status' => 'publish',
            'sort_column' => 'ID',
            'sort_order' => 'ASC',
        ) );

        foreach ( $pages as $candidate ) {
            if ( 0 === strcasecmp( $candidate->post_title, $title ) ) {
                $page = $candidate;
                break;
            }
        }
    }

    return array(
        'id'    => $page ? (int) $page->ID : 0,
        'label' => $title,
        'url'   => $page ? get_permalink( $page->ID ) : home_url( '/' . trim( $path, '/' ) . '/' ),
    );
}

function bartik_primary_links( $include_home = true ) {
    $links = array();

    if ( $include_home ) {
        $links[] = array(
            'id'    => (int) get_option( 'page_on_front' ),
            'label' => 'Home',
            'url'   => home_url( '/' ),
        );
    }

    $targets = array(
        array( 'welcome', 'Welcome' ),
        array( 'what-we-do', 'What We Do' ),
        array( 'our-people', 'Our People' ),
        array( 'our-products', 'Our Products' ),
        array( 'flag', 'Flag' ),
    );

    foreach ( $targets as $target ) {
        $links[] = bartik_page_link_for( $target[0], $target[1] );
    }

    return $links;
}

/* ─── Custom nav walker — clean li/a output ─── */
class Bartik_Nav_Walker extends Walker_Nav_Menu {
    function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
        $classes     = empty( $item->classes ) ? array() : (array) $item->classes;
        $class_str   = trim( implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) ) );
        $class_attr  = $class_str ? ' class="' . esc_attr( $class_str ) . '"' : '';
        $output .= '<li' . $class_attr . '>';

        $atts = array(
            'href'  => ! empty( $item->url )        ? $item->url        : '',
            'title' => ! empty( $item->attr_title ) ? $item->attr_title : '',
        );
        $atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );
        $attr_str = '';
        foreach ( $atts as $attr => $val ) {
            if ( $val ) $attr_str .= ' ' . $attr . '="' . esc_attr( $val ) . '"';
        }
        $output .= '<a' . $attr_str . '>' . apply_filters( 'the_title', $item->title, $item->ID ) . '</a>';
    }
    function end_el( &$output, $item, $depth = 0, $args = null ) {
        $output .= "</li>\n";
    }
}

/* ─── Breadcrumb wrapper (called in header.php, renders full-width strip) ─── */
function bartik_breadcrumb_wrapper() {
    echo '<div id="breadcrumb-wrapper">';
    if ( is_front_page() ) {
        echo '<a href="' . home_url('/') . '">Home</a><span class="sep"> / </span>Home';
    } else {
        echo '<a href="' . home_url('/') . '">Home</a>';
        if ( is_page() || is_single() ) {
            $ancestors = array_reverse( get_post_ancestors( get_the_ID() ) );
            foreach ( $ancestors as $anc ) {
                echo '<span class="sep"> / </span><a href="' . get_permalink($anc) . '">' . get_the_title($anc) . '</a>';
            }
            echo '<span class="sep"> / </span>' . get_the_title();
        } elseif ( is_category() ) {
            echo '<span class="sep"> / </span>' . single_cat_title('',false);
        } elseif ( is_archive() ) {
            echo '<span class="sep"> / </span>';
            the_archive_title();
        } elseif ( is_search() ) {
            echo '<span class="sep"> / </span>Search';
        } elseif ( is_404() ) {
            echo '<span class="sep"> / </span>Page not found';
        }
    }
    echo '</div>';
}

/* ─── Archive / search title ─── */
function bartik_page_title() {
    if ( is_home() ) {
        echo '<h1 id="page-title" class="page-title">Recent posts</h1>';
    } elseif ( is_category() ) {
        echo '<h1 id="page-title" class="page-title">' . single_cat_title('',false) . '</h1>';
    } elseif ( is_archive() ) {
        the_archive_title( '<h1 id="page-title" class="page-title">', '</h1>' );
    } elseif ( is_search() ) {
        echo '<h1 id="page-title" class="page-title">Search results for: <em>' . esc_html(get_search_query()) . '</em></h1>';
    } elseif ( is_404() ) {
        echo '<h1 id="page-title" class="page-title">Page not found</h1>';
    }
}

add_filter( 'excerpt_length', function() { return 45; } );
add_filter( 'excerpt_more',   function() { return '&hellip;'; } );
