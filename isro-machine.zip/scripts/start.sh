#!/bin/bash
set -euo pipefail

service mariadb start

for _ in $(seq 1 30); do
  if mariadb-admin ping >/dev/null 2>&1; then
    break
  fi
  sleep 1
done

if [ ! -f /var/lib/mysql/.isro_init_done ]; then
  /setup/create_assets.sh
  mariadb -u root < /setup/init-db.sql
  touch /var/lib/mysql/.isro_init_done
fi

service ssh start
exec apache2ctl -D FOREGROUND
