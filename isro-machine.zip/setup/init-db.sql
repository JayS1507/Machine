CREATE DATABASE IF NOT EXISTS flag;
USE flag;

CREATE TABLE IF NOT EXISTS flag (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mission VARCHAR(64) NOT NULL,
    flag_value VARCHAR(128) NOT NULL
);

DELETE FROM flag;
INSERT INTO flag (mission, flag_value)
VALUES ('Mangalyaan', 'HackCTF{mangalyaan_mysql_internal_pivot}');

ALTER USER 'root'@'localhost'
    IDENTIFIED VIA mysql_native_password
    USING PASSWORD('');

FLUSH PRIVILEGES;

