#!/bin/bash
set -euo pipefail

tmp_dir="/tmp/isro-assets"
mkdir -p "$tmp_dir"

# Bhaskara artifact (password-protected archive with first flag)
cat > "$tmp_dir/flag.txt" << 'EOF'
Bhaskara Flag: HackCTF{bhaskara_archive_signal_found}
EOF
zip -j -P xavier "$tmp_dir/bhaskara.zip" "$tmp_dir/flag.txt" >/dev/null
cp "$tmp_dir/bhaskara.zip" /var/www/html/bhaskara

# Aryabhata image with steghide-embedded flag
cp /setup/aryabhata-source.jpg "$tmp_dir/aryabhata.jpg"

cat > "$tmp_dir/aryabhata_flag.txt" << 'EOF'
Aryabhata Flag: HackCTF{aryabhata_stego_orbit_trace}
EOF

steghide embed \
  -cf "$tmp_dir/aryabhata.jpg" \
  -ef "$tmp_dir/aryabhata_flag.txt" \
  -sf /var/www/html/img/aryabhata.jpg \
  -p '' \
  -f >/dev/null

rm -rf "$tmp_dir"
