<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ISRO Orbital Control Grid</title>
  <link rel="stylesheet" href="/style.css">
</head>
<body class="space-bg station-theme">
  <canvas id="starfield"></canvas>

  <header class="topbar glass">
    <div class="brand-wrap">
      <div class="badge">ISRO</div>
      <div class="brand">Orbital Control Grid</div>
    </div>
    <nav class="nav-links">
      <a href="/">Command Deck</a>
      <a href="/bhaskara.html">Bhaskara Node</a>
      <a href="/connect.php">Relay Connector</a>
    </nav>
    <div class="status">UPLINK: <span id="status-led">STABLE</span></div>
  </header>

  <main class="container">
    <section class="hero glass">
      <div>
        <p class="kicker">SPACE STATION CORE</p>
        <h1>Mission Archive & Relay Interface</h1>
        <p>Access historical mission records, telemetry snapshots, and legacy integration points inside a simulated orbital operations dashboard.</p>
      </div>
      <div class="hero-side">
        <div class="telemetry-row">
          <span>UTC</span>
          <strong id="clock-utc">--:--:--</strong>
        </div>
        <div class="telemetry-row">
          <span>CORE TEMP</span>
          <strong id="core-temp">72.4C</strong>
        </div>
        <div class="telemetry-row">
          <span>ORBIT PHASE</span>
          <strong id="orbit-phase">GEO-SYNC</strong>
        </div>
      </div>
    </section>

    <section class="cards three-col">
      <a class="card glass" href="/bhaskara.html">
        <h2>Bhaskara Program</h2>
        <p>Legacy orbital research payload dossier and encoded launch references from archival payloads.</p>
      </a>
      <a class="card glass" href="/img/aryabhata.jpg">
        <h2>Aryabhata Media</h2>
        <p>Historic satellite imagery from early experimental mission cycles.</p>
      </a>
      <a class="card glass" href="/connect.php">
        <h2>Mission Connector</h2>
        <p>Legacy relay bridge for document integration and stream preview routines.</p>
      </a>
    </section>

    <section class="panel-grid">
      <article class="panel glass">
        <h3>Station Feed</h3>
        <p>Automated monitor confirms all external interfaces remain online for mission operators and deep-space analysts.</p>
      </article>
      <article class="panel glass">
        <h3>Security Directive</h3>
        <p>Only verified personnel should decode hidden launch metadata and recover synchronized storage modules.</p>
      </article>
    </section>
  </main>

  <script src="/script.js"></script>
</body>
</html>
