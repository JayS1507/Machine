<?php
if (isset($_GET['file'])) {
    $file = $_GET['file'];
    include($file);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Relay Connector Console</title>
  <link rel="stylesheet" href="/style.css">
</head>
<body class="space-bg station-theme">
  <canvas id="starfield"></canvas>

  <header class="topbar glass">
    <div class="brand-wrap">
      <div class="badge">ISRO</div>
      <div class="brand">Relay Connector Console</div>
    </div>
    <a class="back-link" href="/">Return to Command Deck</a>
  </header>

  <main class="container single">
    <section class="panel glass">
      <p class="kicker">LEGACY RELAY SERVICE</p>
      <h1>Connector Endpoint</h1>
      <p>Used by legacy services to integrate mission snippets into this relay panel in real time.</p>
      <form class="connect-form" method="get" action="/connect.php">
        <label for="file">Document Source</label>
        <input type="text" id="file" name="file">
        <button type="submit">Load</button>
      </form>
    </section>
  </main>

  <script src="/script.js"></script>
</body>
</html>
