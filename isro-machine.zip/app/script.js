(function () {
  const canvas = document.getElementById("starfield");
  if (canvas) {
    const ctx = canvas.getContext("2d");
    let width = 0;
    let height = 0;
    let stars = [];
    let pointerX = 0;
    let pointerY = 0;

    const resize = function () {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
      const count = Math.min(220, Math.floor((width * height) / 9000));
      stars = Array.from({ length: count }, function () {
        return {
          x: Math.random() * width,
          y: Math.random() * height,
          z: Math.random() * 0.8 + 0.2,
          s: Math.random() * 1.6 + 0.4
        };
      });
    };

    const draw = function () {
      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = "rgba(123,96,66,0.45)";

      for (let i = 0; i < stars.length; i += 1) {
        const star = stars[i];
        star.y += 0.15 * star.z;
        if (star.y > height) {
          star.y = -5;
          star.x = Math.random() * width;
        }

        const parallaxX = (pointerX - width / 2) * 0.0008 * star.z * width;
        const parallaxY = (pointerY - height / 2) * 0.0006 * star.z * height;
        const x = star.x + parallaxX;
        const y = star.y + parallaxY;

        ctx.globalAlpha = 0.45 + star.z * 0.55;
        ctx.beginPath();
        ctx.arc(x, y, star.s * star.z, 0, Math.PI * 2);
        ctx.fill();
      }

      requestAnimationFrame(draw);
    };

    window.addEventListener("resize", resize);
    window.addEventListener("pointermove", function (event) {
      pointerX = event.clientX;
      pointerY = event.clientY;
    });

    resize();
    draw();
  }

  const clock = document.getElementById("clock-utc");
  if (clock) {
    const updateClock = function () {
      const now = new Date();
      clock.textContent = now.toISOString().slice(11, 19);
    };
    updateClock();
    setInterval(updateClock, 1000);
  }

  const statusLed = document.getElementById("status-led");
  if (statusLed) {
    let state = true;
    setInterval(function () {
      state = !state;
      statusLed.style.opacity = state ? "1" : "0.55";
    }, 700);
  }

  const coreTemp = document.getElementById("core-temp");
  if (coreTemp) {
    let temp = 72.4;
    setInterval(function () {
      temp += (Math.random() - 0.5) * 0.18;
      coreTemp.textContent = temp.toFixed(1) + "C";
    }, 1200);
  }

  const phase = document.getElementById("orbit-phase");
  if (phase) {
    const phases = ["GEO-SYNC", "SOLAR ALIGN", "DEEP SCAN", "RELAY WINDOW"];
    let idx = 0;
    setInterval(function () {
      idx = (idx + 1) % phases.length;
      phase.textContent = phases[idx];
    }, 2800);
  }
})();
