# wp2shell CTF Lab

This repository builds a local, Dockerized WordPress CTF machine that closely models the public wp2shell advisory chain:

- `CVE-2026-63030`: WordPress REST API batch-route confusion via malformed URL parsing.
- `CVE-2026-60137`: `WP_Query` `author__not_in` SQL injection.

The lab does not ship a real wp2shell exploit. It uses a CTF-only plugin at `/wp-json/wp2shell-lab/v1/batch` that replicates the exact two-bug vulnerability pattern from the real CVE:

1. **Bug 1 (array desync)**: A malformed URL (`http://:`) causes `wp_parse_url()` to fail, pushing a `WP_Error` to `$validation[]` without a corresponding `$matches[]` entry.
2. **Bug 2 (index confusion)**: The dispatch loop reads `$matches[$i]` by original request index on a sequential array, so the attacker's sub-request is dispatched using a shifted handler — bypassing schema validation and reaching the SQL injection sink.

Both `/public/ping` and `/admin/report` share the same handler function (mirroring how WordPress routes share `WP_REST_Posts_Controller`), but have different schema validation. The confusion shifts to the permissive route, letting a scalar `author__not_in` bypass the array requirement and hit the SQL injection sink.

## Quick Start

```bash
cp .env.example .env
docker compose up -d
docker compose logs -f setup
```

Open the target at:

```text
http://127.0.0.1:8080
```

Facilitator admin account from `.env.example`:

```text
ctf-owner / ctf-owner-pass-change-me
```

Give players only [docs/player-brief.md](docs/player-brief.md).

## Reset

```bash
docker compose down -v
docker compose up -d
```

## Smoke Test

The smoke-test solver only talks to `localhost` or `127.0.0.1` and only targets the lab-specific endpoint.

```bash
python3 attacker/solve.py http://127.0.0.1:8080
```

## Source Notes

Research notes and safe advisory-search dorks are in [docs/research-notes.md](docs/research-notes.md).

Primary references used:

- https://wordpress.org/news/2026/07/wordpress-7-0-2-release/
- https://nvd.nist.gov/vuln/detail/CVE-2026-63030
- https://wordpress.org/plugins/compromise-scanner-for-wp2shell/
- https://cert-agid.gov.it/news/wp2shell-vulnerabilita-critiche-nel-core-di-wordpress-necessario-aggiornare-i-sistemi/
- https://fullhunt.io/blog/2026/07/17/wp2shell-wordpress-core-pre-auth-rce-cve-2026-63030.html
- https://blog.zsec.uk/wp2shell-code-trace-deep-dive/

## Safety Boundary

This lab binds WordPress to `127.0.0.1` by default and uses a deliberately renamed endpoint. Do not expose it to the public internet. Do not use the research dorks to discover or test third-party WordPress sites.
