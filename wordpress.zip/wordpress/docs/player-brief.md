# Player Brief

Target:

```text
http://127.0.0.1:8080
```

Rules:

- Attack only the local Docker lab.
- Do not scan or test any third-party WordPress sites.
- Collect `user.txt` and `root.txt`.

Story:

The site owner received an alert about a WordPress core issue involving REST batch requests and a query parameter named `author__not_in`. The public checker says this is not plugin-specific, and the incident notes mention unusual REST batch traffic with malformed URLs.

Objectives:

1. Identify the lab REST batch surface.
2. Send a batch with a malformed URL to trigger route confusion in the batch handler.
3. Use the confused batch to bypass schema validation and reach the SQL injection sink.
4. Extract the first flag and the stage token from the database.
5. Use the token to create an administrator account.
6. Use the admin dashboard to inspect compromise indicators and retrieve the final flag from the bounded diagnostic console.

Starting hints:

- Check the WordPress REST API index.
- Try sending a batch with a URL that cannot be parsed (e.g., `http://:`) alongside a valid route.
- Observe how the batch response changes when a malformed URL is included.
- The interesting query parameter keeps its public advisory name: `author__not_in`.
- The batch requires 3 sub-requests: the malformed URL, your target, and a padding route.
