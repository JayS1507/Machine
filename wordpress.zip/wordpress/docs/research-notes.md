# Research Notes

## Public Facts Used

The lab is based on advisory-level details from public sources, not a weaponized reproduction of the real WordPress core issue.

- WordPress published 7.0.2 on July 17, 2026 and described the release as fixing one critical and one high severity security issue. The release notes credit a REST API batch-route confusion plus SQL injection issue leading to RCE, and list `CVE-2026-63030` and `CVE-2026-60137`.
- WordPress backports listed in the release notes: 6.9.5 fixes both issues on the 6.9 branch, 6.8.6 fixes the SQL injection issue on the 6.8 branch, and 7.1 beta2 fixes both issues for the beta branch.
- NVD describes `CVE-2026-63030` as affecting WordPress 6.9.x before 6.9.5 and 7.0.x before 7.0.2, where REST batch endpoint route confusion can combine with the `author__not_in` SQL injection to reach RCE.
- Public compromise-scanner notes call out artifacts such as loopback `oembed_cache` entries, `customize_changeset` objects, `wp2_` administrator logins, `@wp2shell.invalid` emails, deleted-admin traces, and `wp2shell_*` plugin artifacts.
- CERT-AGID recommends checking for anomalous `/wp-json/batch/v1` and `?rest_route=/batch/v1` requests, unexpected admin accounts, changed site files, unknown plugins or themes, PHP web shells, database anomalies, and credential/configuration changes.

## Advisory Search Dorks

These dorks are for finding writeups and advisories only. They intentionally avoid target-discovery patterns such as `inurl:/wp-json/batch/v1`.

```text
"CVE-2026-63030" "WordPress 7.0.2"
"CVE-2026-63030" "GHSA-ff9f-jf42-662q"
"CVE-2026-60137" "author__not_in"
"wp2shell" "oembed_cache" "wp2shell_*"
site:wordpress.org "CVE-2026-63030"
site:nvd.nist.gov "CVE-2026-63030"
site:wordpress.org/plugins "wp2shell"
```

## Lab Mapping

| Real CVE-2026-63030 concept | Lab implementation |
| --- | --- |
| **Malformed URL trigger**: `wp_parse_url()` fails on `http://:` → `WP_Error` pushed to `$validation[]` but not `$matches[]` | Lab batch handler uses the same `wp_parse_url()` call and identical code path: `http://:` causes failure → same array desync |
| **Array index desync**: `$matches[$i]` and `$validation[$i]` no longer describe `$requests[$i]` | Lab handler reads `$matches[$i]` by original index on a sequential array — identical vulnerable pattern (Bug 2) |
| **Schema bypass**: Posts controller's `author_exclude` integer-array validation is bypassed | Lab's `/admin/report` route requires `author__not_in` to be array; `/public/ping` has no such requirement. Desync shifts to ping's permissive schema → scalar passes |
| **Shared handler across routes**: Multiple WP REST routes use `WP_REST_Posts_Controller` with different schemas | Lab's `/public/ping` and `/admin/report` both call `wp2shell_lab_handle_posts_query()` — same handler, different `args` schemas |
| **SQL injection**: `author__not_in` scalar concatenated into `post_author NOT IN ()` | Lab handler copies the exact vulnerable code: `(string) $raw` placed in SQL without normalization |
| **Pre-auth entry**: Batch endpoint is public (`/wp-json/batch/v1`) | Lab batch endpoint has `permission_callback => __return_true` |
| **RCE chain**: SQLi → extract admin creds → login → upload malicious plugin → `system()` | Lab: SQLi → extract stage2_token → create admin via token-authenticated endpoint → bounded diagnostic console |
| **Compromise indicators**: `oembed_cache`, `customize_changeset`, `wp2_` users, `wp2shell_*` plugin dir | All four artifact types created by `wp2shell_lab_record_artifacts()` |

## Two-Bug Mechanism (CVE-2026-63030)

The vulnerability requires two bugs working together:

### Bug 1: Malformed URL triggers array desync

In `serve_batch_request_v1()`, Pass 1 iterates all sub-requests:
- If `wp_parse_url()` fails → `WP_Error` pushed to `$validation[$i]` (keyed by original index)
- But NO entry is added to `$matches[]` (sequential array)
- This desynchronizes the two arrays: `$matches` becomes shorter than `$validation`

### Bug 2: Dispatch reads `$matches[$i]` by original index

Pass 2 iterates all requests by original index `$i` and reads `$matches[$i]`.
Because `$matches` is sequential and shorter (due to Bug 1), `$matches[$i]`
resolves to the match for a **different** request — shifting the handler,
permission result, AND schema validation.

The attacker's body (never validated against the original route's schema) is
dispatched to the shifted route's handler with permissive schema → SQL injection.

### Why the CTF requires 3 sub-requests

With 1 malformed URL (index 0) and 1 target (index 1), `$matches` has only 1
entry (index 0). The target at index 1 tries `$matches[1]` which doesn't exist.
Adding a padding route at index 2 populates `$matches[1]`, so the target at
index 1 successfully reads the shifted match.

## Key Differences from Real CVE

| Aspect | Real CVE-2026-63030 | CTF Lab |
| --- | --- | --- |
| Batch endpoint | WordPress core `/wp-json/batch/v1` | Lab plugin `/wp-json/wp2shell-lab/v1/batch` |
| SQLi target | `/wp/v2/posts` → `author_exclude` → `WP_Query::author__not_in` | `/admin/report` → `author__not_in` directly |
| Extraction | Blind time-based (`SLEEP` + `CHAR_LENGTH` + `ASCII SUBSTRING`) | UNION-based (data visible in response) |
| RCE | Upload malicious PHP plugin → `system($_GET['c'])` | Bounded diagnostic console with allowlisted commands |
| Re-entrancy (Bug 2) | Nested `rest_api_loaded()` dispatch bypasses batch context | Not modeled (alternative exploitation path) |
| Admin creation | Stolen credentials from SQLi → wp-login.php | Stage2 token from SQLi → token-authenticated REST endpoint |

## References

- https://wordpress.org/news/2026/07/wordpress-7-0-2-release/
- https://nvd.nist.gov/vuln/detail/CVE-2026-63030
- https://wordpress.org/plugins/compromise-scanner-for-wp2shell/
- https://cert-agid.gov.it/news/wp2shell-vulnerabilita-critiche-nel-core-di-wordpress-necessario-aggiornare-i-sistemi/
- https://fullhunt.io/blog/2026/07/17/wp2shell-wordpress-core-pre-auth-rce-cve-2026-63030.html
- https://blog.zsec.uk/wp2shell-code-trace-deep-dive/
