#!/bin/sh
set -eu

cd /var/www/html

echo "[setup] waiting for WordPress files"
until [ -f wp-includes/version.php ]; do
  sleep 2
done

if [ ! -f wp-config.php ]; then
  echo "[setup] creating wp-config.php"
  wp config create \
    --dbname="${WORDPRESS_DB_NAME}" \
    --dbuser="${WORDPRESS_DB_USER}" \
    --dbpass="${WORDPRESS_DB_PASSWORD}" \
    --dbhost="${WORDPRESS_DB_HOST}" \
    --dbprefix="${WORDPRESS_TABLE_PREFIX}" \
    --skip-check \
    --allow-root
fi

echo "[setup] waiting for database"
until wp db check --allow-root >/dev/null 2>&1; do
  sleep 2
done

if ! wp core is-installed --allow-root >/dev/null 2>&1; then
  echo "[setup] installing WordPress"
  wp core install \
    --url="${WORDPRESS_URL}" \
    --title="${WORDPRESS_TITLE}" \
    --admin_user="${WORDPRESS_ADMIN_USER}" \
    --admin_password="${WORDPRESS_ADMIN_PASSWORD}" \
    --admin_email="${WORDPRESS_ADMIN_EMAIL}" \
    --skip-email \
    --allow-root
fi

echo "[setup] activating lab plugin"
wp plugin activate wp2shell-lab --allow-root
wp option update blog_public 0 --allow-root >/dev/null
wp option update permalink_structure '/%postname%/' --allow-root >/dev/null
wp rewrite flush --allow-root >/dev/null

if ! wp post list --post_type=page --name=incident-notes --field=ID --allow-root | grep -q '[0-9]'; then
  echo "[setup] creating player-facing incident page"
  wp post create \
    --post_type=page \
    --post_status=publish \
    --post_name=incident-notes \
    --post_title='Incident notes' \
    --post_content='Ops noticed unusual REST batch traffic and a query parameter named author__not_in in the same time window. The public checker says the issue is not plugin-specific. Your job is to prove impact inside this isolated lab and collect both flags.' \
    --allow-root >/dev/null
fi

echo "[setup] complete"
