#!/bin/sh
set -eu

cd /var/www/html

echo "[setup] waiting for WordPress files"
until [ -f wp-includes/version.php ]; do
  sleep 2
done

if [ ! -f wp-config.php ]; then
  echo "[setup] creating wp-config.php"
  wp config create \
    --dbname="${WORDPRESS_DB_NAME}" \
    --dbuser="${WORDPRESS_DB_USER}" \
    --dbpass="${WORDPRESS_DB_PASSWORD}" \
    --dbhost="${WORDPRESS_DB_HOST}" \
    --dbprefix="${WORDPRESS_TABLE_PREFIX}" \
    --skip-check \
    --allow-root
fi

echo "[setup] waiting for database"
until wp db check --allow-root >/dev/null 2>&1; do
  sleep 2
done

if ! wp core is-installed --allow-root >/dev/null 2>&1; then
  echo "[setup] installing WordPress"
  wp core install \
    --url="${WORDPRESS_URL}" \
    --title="${WORDPRESS_TITLE}" \
    --admin_user="${WORDPRESS_ADMIN_USER}" \
    --admin_password="${WORDPRESS_ADMIN_PASSWORD}" \
    --admin_email="${WORDPRESS_ADMIN_EMAIL}" \
    --skip-email \
    --allow-root
fi

# Always update site URL to match current WORDPRESS_URL env var
echo "[setup] ensuring site URL matches WORDPRESS_URL=${WORDPRESS_URL}"
wp option update siteurl "${WORDPRESS_URL}" --allow-root >/dev/null 2>&1 || true
wp option update home "${WORDPRESS_URL}" --allow-root >/dev/null 2>&1 || true

echo "[setup] configuring theme and site appearance"
wp theme activate twentytwentythree --allow-root >/dev/null 2>&1 || true
wp option update blogdescription 'Secure WordPress Deployment — Monitoring Active' --allow-root >/dev/null
wp option update show_on_front 'page' --allow-root >/dev/null

echo "[setup] activating lab plugin"
wp plugin activate wp2shell-lab --allow-root
wp option update blog_public 0 --allow-root >/dev/null
wp option update permalink_structure '/%postname%/' --allow-root >/dev/null
wp rewrite flush --allow-root >/dev/null

# Create a realistic "Home" page
if ! wp post list --post_type=page --name=home --field=ID --allow-root | grep -q '[0-9]'; then
  echo "[setup] creating home page"
  wp post create \
    --post_type=page \
    --post_status=publish \
    --post_name=home \
    --post_title='Home' \
    --post_content='<!-- wp:paragraph -->
<p>Welcome to the corporate WordPress portal. This site is monitored 24/7 by the security operations team.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2>System Status</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>All services are operating normally. Last infrastructure review: July 2026.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p class="has-small-font-size"><em>If you have received this URL in error, please contact the site administrator.</em></p>
<!-- /wp:paragraph -->' \
    --allow-root >/dev/null
fi

# Create a realistic "About" page
if ! wp post list --post_type=page --name=about --field=ID --allow-root | grep -q '[0-9]'; then
  echo "[setup] creating about page"
  wp post create \
    --post_type=page \
    --post_status=publish \
    --post_name=about \
    --post_title='About' \
    --post_content='<!-- wp:paragraph -->
<p>This WordPress installation serves as the internal documentation and collaboration portal for the engineering division.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2>Infrastructure</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul>
<li>WordPress 7.0.x (managed hosting)</li>
<li>PHP 8.2 with OPcache</li>
<li>MariaDB 11.4</li>
<li>Automated daily backups</li>
</ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>For access requests or infrastructure questions, please open a ticket with the platform team.</p>
<!-- /wp:paragraph -->' \
    --allow-root >/dev/null
fi

# Create a realistic "Privacy Policy" page
if ! wp post list --post_type=page --name=privacy-policy --field=ID --allow-root | grep -q '[0-9]'; then
  echo "[setup] creating privacy policy page"
  wp post create \
    --post_type=page \
    --post_status=publish \
    --post_name=privacy-policy \
    --post_title='Privacy Policy' \
    --post_content='<!-- wp:paragraph -->
<p>Last updated: January 2026</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>This portal is used internally by authorized personnel only. Access logs are retained for 90 days. All data transmitted through this system is encrypted in transit. Unauthorized access is prohibited and monitored.</p>
<!-- /wp:paragraph -->' \
    --allow-root >/dev/null
fi

# Create the incident notes page (player-facing hint)
if ! wp post list --post_type=page --name=incident-notes --field=ID --allow-root | grep -q '[0-9]'; then
  echo "[setup] creating player-facing incident page"
  wp post create \
    --post_type=page \
    --post_status=publish \
    --post_name=incident-notes \
    --post_title='Incident notes' \
    --post_content='<!-- wp:paragraph -->
<p><strong>SECURITY INCIDENT — INTERNAL USE ONLY</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Ops noticed unusual REST batch traffic and a query parameter named <code>author__not_in</code> in the same time window. The public checker says the issue is not plugin-specific.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3>Timeline</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul>
<li>Initial alert: REST batch endpoint received malformed URL patterns</li>
<li>Follow-up: SQL error signatures detected in access logs</li>
<li>Scope: WordPress core REST API batch processing</li>
</ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Your job is to prove impact inside this isolated lab and collect both flags.</p>
<!-- /wp:paragraph -->' \
    --allow-root >/dev/null
fi

# Create a realistic blog post
if ! wp post list --post_type=post --name=quarterly-security-review --field=ID --allow-root | grep -q '[0-9]'; then
  echo "[setup] creating blog post"
  wp post create \
    --post_type=post \
    --post_status=publish \
    --post_name=quarterly-security-review \
    --post_title='Q3 2026 Security Review Complete' \
    --post_content='<!-- wp:paragraph -->
<p>The quarterly security review for Q3 2026 has been completed. All systems passed the assessment with no critical findings.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Key highlights:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
<li>WordPress core updated to latest stable release</li>
<li>All plugins reviewed for known vulnerabilities</li>
<li>REST API access controls verified</li>
<li>Database backups tested and validated</li>
</ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>The next scheduled review is planned for Q4 2026. Department leads should submit any security concerns through the internal ticketing system before October 15th.</p>
<!-- /wp:paragraph -->' \
    --allow-root >/dev/null
fi

# Set a realistic site icon (uses a simple default)
wp option update site_icon '' --allow-root >/dev/null 2>&1 || true

# Create a basic menu with realistic pages
if ! wp menu location list --allow-root | grep -q 'primary'; then
  wp menu create "Primary Menu" --allow-root >/dev/null 2>&1 || true
  wp menu item add-post "Primary Menu" $(wp post list --post_type=page --name=home --field=ID --allow-root) --allow-root >/dev/null 2>&1 || true
  wp menu item add-post "Primary Menu" $(wp post list --post_type=page --name=about --field=ID --allow-root) --allow-root >/dev/null 2>&1 || true
  wp menu item add-post "Primary Menu" $(wp post list --post_type=page --name=incident-notes --field=ID --allow-root) --allow-root >/dev/null 2>&1 || true
  wp menu item add-post "Primary Menu" $(wp post list --post_type=page --name=privacy-policy --field=ID --allow-root) --allow-root >/dev/null 2>&1 || true
  wp menu location assign "Primary Menu" primary --allow-root >/dev/null 2>&1 || true
fi

echo "[setup] complete"
