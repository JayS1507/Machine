<?php
/**
 * Plugin Name: wp2shell Lab
 * Description: CTF-only lab that models CVE-2026-63030 (REST batch route confusion + author__not_in SQLi). Not a real exploit.
 * Version: 3.0.0
 * Author: CTF Lab
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WP2SHELL_LAB_ROOT_FLAG', '/opt/wp2shell-lab/root.txt');

register_activation_hook(__FILE__, 'wp2shell_lab_install');
add_action('plugins_loaded', 'wp2shell_lab_install');
add_action('rest_api_init', 'wp2shell_lab_register_rest_routes');
add_action('admin_menu', 'wp2shell_lab_register_admin_page');
add_action('wp_head', 'wp2shell_lab_inject_theme_css');

function wp2shell_lab_inject_theme_css()
{
    ?>
    <style>
    :root {
        --wp--preset--color--primary: #D4A574;
        --wp--preset--color--secondary: #8B7355;
        --wp--preset--color--background: #FFFDF5;
        --wp--preset--color--text: #2C2C2C;
        --wp--preset--color--foreground: #F5F0E8;
    }
    body {
        background-color: #FFFDF5 !important;
        color: #2C2C2C !important;
        font-family: Georgia, 'Times New Roman', serif;
    }
    .site-header, header, .wp-block-navigation, nav {
        background-color: #FFFFFF !important;
        border-bottom: 1px solid #E8E0D0 !important;
    }
    .site-title, .wp-block-site-title a, header .wp-block-site-title a {
        color: #2C2C2C !important;
        font-family: Georgia, 'Times New Roman', serif;
        font-weight: 700;
    }
    .wp-block-navigation-item a, nav a {
        color: #5A4A3A !important;
        transition: color 0.2s ease;
    }
    .wp-block-navigation-item a:hover, nav a:hover {
        color: #D4A574 !important;
    }
    .site-footer, footer {
        background-color: #F5F0E8 !important;
        color: #5A4A3A !important;
        border-top: 1px solid #E8E0D0 !important;
    }
    a {
        color: #8B7355 !important;
    }
    a:hover {
        color: #D4A574 !important;
    }
    .wp-block-post-title, h1, h2, h3, h4, h5, h6 {
        color: #2C2C2C !important;
    }
    .wp-block-quote {
        border-left-color: #D4A574 !important;
        background-color: #FDFBF7 !important;
    }
    .wp-block-code, code, pre {
        background-color: #F5F0E8 !important;
        color: #5A4A3A !important;
        border-radius: 4px;
    }
    .entry-content p, .wp-block-post-content p, p {
        line-height: 1.8;
        color: #3A3A3A !important;
    }
    .wp-block-post-content {
        max-width: 720px;
        margin: 0 auto;
    }
    .site-content, main {
        background-color: #FFFDF5 !important;
    }
    .wp-block-group {
        background-color: #FFFFFF !important;
        border-radius: 4px;
    }
    .has-background, [class*="has-background"] {
        background-color: #FFFDF5 !important;
    }
    .wp-block-separator {
        border-color: #E8E0D0 !important;
    }
    .wp-block-buttons .wp-block-button__link {
        background-color: #8B7355 !important;
        color: #FFFFFF !important;
        border-radius: 4px;
    }
    .wp-block-buttons .wp-block-button__link:hover {
        background-color: #D4A574 !important;
    }
    .comments-area, .wp-block-comments {
        background-color: #FFFFFF !important;
    }
    .page-numbers, .nav-links a {
        color: #8B7355 !important;
        background-color: #F5F0E8 !important;
        padding: 6px 12px;
        border-radius: 4px;
    }
    .page-numbers.current, .nav-links a:hover {
        background-color: #8B7355 !important;
        color: #FFFFFF !important;
    }
    </style>
    <?php
}

function wp2shell_lab_table_name()
{
    global $wpdb;
    return $wpdb->prefix . 'wp2shell_lab_secrets';
}

function wp2shell_lab_install()
{
    global $wpdb;

    $table = wp2shell_lab_table_name();
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE {$table} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        secret_name varchar(64) NOT NULL,
        secret_value text NOT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY secret_name (secret_name)
    ) {$charset_collate};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);

    wp2shell_lab_seed_secret('user_flag', 'HackCTF{batch_route_confusion_reaches_hidden_sqli}');
    wp2shell_lab_seed_secret('stage2_token', wp_generate_password(24, false, false));
    add_option('wp2shell_lab_compromised_user', '');
}

function wp2shell_lab_seed_secret($name, $value)
{
    global $wpdb;

    $table = wp2shell_lab_table_name();
    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT secret_value FROM {$table} WHERE secret_name = %s",
        $name
    ));

    if ($existing !== null) {
        return;
    }

    $wpdb->insert(
        $table,
        [
            'secret_name' => $name,
            'secret_value' => $value,
            'created_at' => current_time('mysql'),
        ],
        ['%s', '%s', '%s']
    );
}

function wp2shell_lab_get_secret($name)
{
    global $wpdb;

    $table = wp2shell_lab_table_name();
    return (string) $wpdb->get_var($wpdb->prepare(
        "SELECT secret_value FROM {$table} WHERE secret_name = %s",
        $name
    ));
}

function wp2shell_lab_register_rest_routes()
{
    register_rest_route('wp2shell-lab/v1', '/public/ping', [
        'methods' => ['GET', 'POST'],
        'callback' => function (WP_REST_Request $request) {
            return wp2shell_lab_handle_posts_query(wp2shell_lab_request_body($request), false);
        },
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('wp2shell-lab/v1', '/admin/report', [
        'methods' => 'POST',
        'callback' => function (WP_REST_Request $request) {
            $body = wp2shell_lab_request_body($request);
            if (isset($body['author__not_in']) && !is_array($body['author__not_in'])) {
                return new WP_Error(
                    'rest_invalid_param',
                    'author__not_in must be an array of integers.',
                    ['status' => 400]
                );
            }
            return wp2shell_lab_handle_posts_query($body, false);
        },
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('wp2shell-lab/v1', '/admin/create-admin', [
        'methods' => 'POST',
        'callback' => function (WP_REST_Request $request) {
            return wp2shell_lab_handle_create_admin(wp2shell_lab_request_body($request), false);
        },
        'permission_callback' => function (WP_REST_Request $request) {
            if (current_user_can('manage_options')) {
                return true;
            }
            $token = $request->get_param('token') ?? '';
            $expected = wp2shell_lab_get_secret('stage2_token');
            return $expected !== '' && hash_equals($expected, $token);
        },
    ]);

    register_rest_route('wp2shell-lab/v1', '/admin/diagnostic', [
        'methods' => 'POST',
        'callback' => function (WP_REST_Request $request) {
            return wp2shell_lab_handle_diagnostic(wp2shell_lab_request_body($request), false);
        },
        'permission_callback' => function (WP_REST_Request $request) {
            if (current_user_can('manage_options')) {
                return true;
            }
            $token = $request->get_param('token') ?? '';
            $expected = wp2shell_lab_get_secret('stage2_token');
            return $expected !== '' && hash_equals($expected, $token);
        },
    ]);

    register_rest_route('wp2shell-lab/v1', '/batch', [
        'methods' => 'POST',
        'callback' => 'wp2shell_lab_handle_batch',
        'permission_callback' => '__return_true',
    ]);
}

function wp2shell_lab_request_body(WP_REST_Request $request)
{
    $json = $request->get_json_params();
    if (is_array($json)) {
        return $json;
    }

    return $request->get_params();
}

function wp2shell_lab_internal_routes()
{
    return [
        '/public/ping' => [
            'permission' => function () {
                return true;
            },
            'handler' => 'wp2shell_lab_handle_posts_query',
            'args' => [],
        ],
        '/admin/report' => [
            'permission' => function () {
                return true;
            },
            'handler' => 'wp2shell_lab_handle_posts_query',
            'args' => [
                'author__not_in' => [
                    'required' => true,
                    'type' => 'array',
                    'items' => ['type' => 'integer'],
                ],
            ],
        ],
        '/admin/create-admin' => [
            'permission' => function () {
                return current_user_can('manage_options');
            },
            'handler' => 'wp2shell_lab_handle_create_admin',
            'args' => [],
        ],
        '/admin/diagnostic' => [
            'permission' => function () {
                return current_user_can('manage_options');
            },
            'handler' => 'wp2shell_lab_handle_diagnostic',
            'args' => [],
        ],
    ];
}

function wp2shell_lab_normalize_path($path)
{
    $path = '/' . ltrim((string) $path, '/');
    $path = preg_replace('#/+#', '/', $path);
    $path = rtrim($path, '/');

    return $path === '' ? '/' : $path;
}

function wp2shell_lab_validate_args($body, $args)
{
    foreach ($args as $key => $rules) {
        if (!empty($rules['required']) && !isset($body[$key])) {
            return new WP_Error('missing_param', "Missing required parameter: {$key}");
        }
        if (isset($body[$key])) {
            $value = $body[$key];
            $type = $rules['type'] ?? 'string';
            if ($type === 'array' && !is_array($value)) {
                return new WP_Error('invalid_param', "{$key} must be an array.");
            }
        }
    }
    return true;
}

/**
 * Batch handler modelling CVE-2026-63030.
 *
 * The real vulnerability has two bugs working together:
 *
 * Bug 1 — Malformed URL triggers array desync:
 *   wp_parse_url() fails on "http://:" → WP_Error pushed to $validation[]
 *   but NO entry added to $matches[]. Because $matches is sequential (only
 *   successful matches) and $validation is keyed by original request index,
 *   the two arrays become desynchronised.
 *
 * Bug 2 — Dispatch reads $matches[$i] by original index:
 *   The dispatch loop iterates all requests by original index $i, and reads
 *   $matches[$i] to find the handler. But $matches is sequential and now
 *   shorter — so $matches[$i] resolves to the match for a DIFFERENT request.
 *   This shifts the handler AND the route's schema validation. The attacker's
 *   body is dispatched to a different route's handler, with that route's
 *   (permissive) schema — bypassing the original route's strict validation.
 *
 * In the real CVE, the target is /wp/v2/posts (a PUBLIC endpoint whose
 * schema validates author_exclude as an array of integers). The confusion
 * shifts to a route whose schema does NOT validate author_exclude, letting
 * a scalar value reach WP_Query::author__not_in → SQL injection.
 *
 * This lab replicates both bugs identically using WordPress's wp_parse_url().
 */
function wp2shell_lab_handle_batch(WP_REST_Request $request)
{
    $prev_error_reporting = error_reporting();
    error_reporting(E_ERROR | E_PARSE);

    $body = wp2shell_lab_request_body($request);
    $batch_requests = isset($body['requests']) && is_array($body['requests']) ? $body['requests'] : [];
    $routes = wp2shell_lab_internal_routes();

    if (count($batch_requests) === 0 || count($batch_requests) > 8) {
        error_reporting($prev_error_reporting);
        return new WP_Error(
            'wp2shell_lab_bad_batch',
            'Batch body must contain 1 to 8 requests.',
            ['status' => 400]
        );
    }

    // Pass 1: Parse, match, permission check.
    //
    // $matches is SEQUENTIAL — only entries for successfully parsed+matched
    // routes. $validation is KEYED BY ORIGINAL INDEX — entries for all requests,
    // including parse errors. This difference is the root cause of the desync.

    $matches    = array();
    $validation = array();

    foreach ($batch_requests as $i => $single_request) {
        $parsed_url = wp_parse_url($single_request['path'] ?? '');

        if ($parsed_url === false || is_wp_error($parsed_url)) {
            // Bug 1 trigger: $validation[$i] is set, but $matches[] is NOT.
            $validation[$i] = is_wp_error($parsed_url)
                ? $parsed_url
                : new WP_Error('wp2shell_lab_parse_failed', 'Failed to parse sub-request path.');
            continue;
        }

        $path = wp2shell_lab_normalize_path($parsed_url['path'] ?? '');

        if (!isset($routes[$path])) {
            $validation[$i] = new WP_Error(
                'wp2shell_lab_unknown_route',
                'Unknown lab route: ' . $path,
                ['status' => 404]
            );
            continue;
        }

        $route   = $routes[$path];
        $handler = $route['handler'];

        $allowed = (bool) call_user_func($route['permission']);

        $matches[] = [
            'path'    => $path,
            'handler' => $handler,
            'allowed' => $allowed,
            'args'    => $route['args'],
        ];
        $validation[$i] = true;
    }

    if (empty($matches)) {
        error_reporting($prev_error_reporting);
        return new WP_Error(
            'wp2shell_lab_no_matches',
            'No sub-requests could be matched to lab routes.',
            ['status' => 400]
        );
    }

    // Pass 2: Dispatch.
    //
    // Bug 2: $matches[$i] uses the ORIGINAL request index to access a
    // SEQUENTIAL array. When a malformed URL at an earlier index skipped
    // an $matches[] entry, $matches[$i] now points to a DIFFERENT route's
    // match — shifting the handler, permission result, AND schema validation.
    //
    // The attacker's body (never validated against the original route's schema)
    // is dispatched to the SHIFTED route's handler, which processes it with
    // the SHIFTED route's permissive schema → SQL injection.

    $responses     = array();
    $total_sub_req = count($batch_requests);

    for ($i = 0; $i < $total_sub_req; $i++) {
        $single_request = $batch_requests[$i];
        $parsed_url     = wp_parse_url($single_request['path'] ?? '');

        if ($parsed_url === false || is_wp_error($parsed_url)) {
            $responses[] = [
                'index'  => $i,
                'path'   => $single_request['path'] ?? '',
                'status' => 400,
                'body'   => ['message' => 'Sub-request path could not be parsed.'],
            ];
            continue;
        }

        $path = wp2shell_lab_normalize_path($parsed_url['path'] ?? '');

        if (!isset($routes[$path])) {
            $responses[] = [
                'index'  => $i,
                'path'   => $path,
                'status' => 404,
                'body'   => ['message' => 'Unknown lab route.'],
            ];
            continue;
        }

        // Bug 2: $matches[$i] — using original index on a sequential array.
        if (!isset($matches[$i])) {
            $responses[] = [
                'index'  => $i,
                'path'   => $path,
                'status' => 400,
                'body'   => ['message' => 'Dispatch error: no handler available.'],
            ];
            break;
        }

        $match = $matches[$i];

        // Check parse/route validation from the ORIGINAL index.
        if (isset($validation[$i]) && is_wp_error($validation[$i])) {
            $responses[] = [
                'index'  => $i,
                'path'   => $path,
                'status' => $validation[$i]->get_error_data()['status'] ?? 400,
                'body'   => [
                    'message' => $validation[$i]->get_error_message(),
                ],
            ];
            continue;
        }

        // Permission check from the SHIFTED match.
        if (!$match['allowed']) {
            $responses[] = [
                'index'  => $i,
                'path'   => $path,
                'status' => 403,
                'body'   => ['message' => 'Permission denied for matched route.'],
            ];
            continue;
        }

        // Schema validation from the SHIFTED route's args.
        // This is the security boundary the desync undermines: the attacker's
        // body is validated against the SHIFTED route's schema, not the
        // original route's schema. If the shifted route has permissive or no
        // schema for the parameter the attacker controls, it passes through.
        $sub_body = $single_request['body'] ?? [];
        if (!empty($match['args'])) {
            $schema_result = wp2shell_lab_validate_args($sub_body, $match['args']);
            if (is_wp_error($schema_result)) {
                $responses[] = [
                    'index'  => $i,
                    'path'   => $path,
                    'status' => 400,
                    'body'   => [
                        'message' => 'Validation error.',
                        'detail'  => $schema_result->get_error_message(),
                    ],
                ];
                continue;
            }
        }

        // Execute the SHIFTED handler with the ATTACKER'S body.
        $result = call_user_func($match['handler'], $sub_body, true);

        $responses[] = [
            'index'  => $i,
            'path'   => $path,
            'status' => 200,
            'body'   => $result,
        ];
    }

    error_reporting($prev_error_reporting);

    $output = [
        'lab'  => 'wp2shell-lab',
        'note' => 'CTF-only batch endpoint modelling CVE-2026-63030. The real WordPress core endpoint is not implemented here.',
        'responses' => $responses,
    ];

    $output['debug'] = [
        'total_sub_requests' => $total_sub_req,
        'matches_count'      => count($matches),
        'validation_count'   => count($validation),
        'desync'             => count($matches) !== $total_sub_req,
    ];

    return $output;
}

/**
 * Shared query handler used by both /public/ping and /admin/report.
 *
 * Both routes use the SAME handler to mirror the real WordPress behavior:
 * multiple REST routes (e.g. /wp/v2/posts, /wp/v2/pages) share
 * WP_REST_Posts_Controller, which internally calls WP_Query with
 * author__not_in. The routes differ in SCHEMA VALIDATION, not handler code.
 *
 * /admin/report's schema requires author__not_in to be an array of integers.
 * /public/ping's schema has no such requirement.
 *
 * Due to CVE-2026-63030's batch confusion, the admin/report body reaches
 * this handler via the ping route's permissive schema — scalar author__not_in
 * passes through unvalidated and hits the SQL injection sink.
 */
function wp2shell_lab_handle_posts_query($body, $via_batch)
{
    global $wpdb;

    $raw = $body['author__not_in'] ?? '0';

    if (is_array($raw)) {
        $author_not_in = implode(',', array_map('absint', $raw));
    } else {
        // Intentional CTF bug matching CVE-2026-60137: scalar input is placed
        // into SQL without the integer normalization used for array input.
        // In real WordPress, this path was reached when the batch route confusion
        // bypassed the REST layer's schema validation for author_exclude.
        $author_not_in = (string) $raw;
    }

    if ($author_not_in === '') {
        $author_not_in = '0';
    }

    $sql = "SELECT ID, post_title, post_author
        FROM {$wpdb->posts}
        WHERE post_status IN ('publish', 'private')
        AND post_author NOT IN ({$author_not_in})
        LIMIT 5";

    $rows = $wpdb->get_results($sql, ARRAY_A);

    if ($wpdb->last_error) {
        return [
            'error' => 'Database error in lab report query.',
            'detail' => $wpdb->last_error,
            'via_batch' => (bool) $via_batch,
        ];
    }

    return [
        'count' => count($rows),
        'rows' => $rows,
        'via_batch' => (bool) $via_batch,
    ];
}

function wp2shell_lab_handle_create_admin($body, $via_batch)
{
    $token = isset($body['token']) ? (string) $body['token'] : '';
    $expected = wp2shell_lab_get_secret('stage2_token');

    if ($expected === '' || !hash_equals($expected, $token)) {
        return [
            'error' => 'Invalid stage2 token.',
            'via_batch' => (bool) $via_batch,
        ];
    }

    $username = sanitize_user($body['username'] ?? 'wp2_ctf_admin', true);
    $password = (string) ($body['password'] ?? wp_generate_password(18, false));
    $email = sanitize_email($body['email'] ?? ($username . '@wp2shell.invalid'));

    if ($username === '') {
        return ['error' => 'Invalid username.'];
    }

    $existing_id = username_exists($username);
    if ($existing_id) {
        $user_id = (int) $existing_id;
        wp_set_password($password, $user_id);
    } else {
        $user_id = wp_create_user($username, $password, $email);
        if (is_wp_error($user_id)) {
            return [
                'error' => $user_id->get_error_message(),
                'via_batch' => (bool) $via_batch,
            ];
        }
    }

    $user = new WP_User($user_id);
    $user->set_role('administrator');
    update_user_meta($user_id, 'wp2shell_lab_created', '1');
    update_option('wp2shell_lab_compromised_user', $username);
    wp2shell_lab_record_artifacts($username);

    return [
        'created' => true,
        'username' => $username,
        'password' => $password,
        'login_url' => wp_login_url(),
        'via_batch' => (bool) $via_batch,
    ];
}

function wp2shell_lab_record_artifacts($username)
{
    for ($i = 1; $i <= 3; $i++) {
        wp_insert_post([
            'post_type' => 'oembed_cache',
            'post_status' => 'publish',
            'post_title' => 'wp2shell lab oembed ' . $i,
            'post_name' => 'wp2shell-lab-oembed-' . $i,
            'post_content' => home_url('/wp-json/batch/v1?lab_artifact=' . $i),
            'post_excerpt' => 'loopback artifact for ' . $username,
        ]);
    }

    wp_insert_post([
        'post_type' => 'customize_changeset',
        'post_status' => 'draft',
        'post_title' => 'wp2shell_lab_changeset',
        'post_content' => wp_json_encode([
            'created_by' => $username,
            'note' => 'CTF artifact that mirrors public compromise indicators.',
        ]),
    ]);

    $artifact_dir = trailingslashit(WP_PLUGIN_DIR) . 'wp2shell_ctf_artifact';
    if (!is_dir($artifact_dir)) {
        wp_mkdir_p($artifact_dir);
    }

    if (is_dir($artifact_dir) && is_writable($artifact_dir)) {
        file_put_contents(
            trailingslashit($artifact_dir) . 'indicator.php',
            "<?php\n// CTF artifact only. This file is not a web shell.\n"
        );
    }
}

function wp2shell_lab_handle_diagnostic($body, $via_batch)
{
    $token = isset($body['token']) ? (string) $body['token'] : '';
    $expected = wp2shell_lab_get_secret('stage2_token');

    if ($expected === '' || !hash_equals($expected, $token)) {
        return [
            'error' => 'Diagnostic console requires a valid stage2 token.',
            'via_batch' => (bool) $via_batch,
        ];
    }

    $cmd = (string) ($body['cmd'] ?? 'id');

    return [
        'cmd' => $cmd,
        'output' => wp2shell_lab_run_diagnostic($cmd),
        'via_batch' => (bool) $via_batch,
    ];
}

function wp2shell_lab_run_diagnostic($cmd)
{
    switch ($cmd) {
        case 'id':
            return "uid=33(www-data) gid=33(www-data) groups=33(www-data)\n";
        case 'whoami':
            return "www-data\n";
        case 'pwd':
            return ABSPATH . "\n";
        case 'ls /opt/wp2shell-lab':
            return file_exists(WP2SHELL_LAB_ROOT_FLAG) ? "root.txt\n" : "\n";
        case 'cat /opt/wp2shell-lab/root.txt':
            if (!is_readable(WP2SHELL_LAB_ROOT_FLAG)) {
                return "root flag is not readable\n";
            }
            return file_get_contents(WP2SHELL_LAB_ROOT_FLAG);
        default:
            return "command blocked by lab allowlist\n";
    }
}

function wp2shell_lab_register_admin_page()
{
    add_menu_page(
        'wp2shell Lab',
        'wp2shell Lab',
        'manage_options',
        'wp2shell-lab',
        'wp2shell_lab_render_admin_page',
        'dashicons-shield',
        3
    );
}

function wp2shell_lab_render_admin_page()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have permission to view this page.', 'wp2shell-lab'));
    }

    $diagnostic_output = '';
    $selected_cmd = 'id';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        check_admin_referer('wp2shell_lab_console');
        $selected_cmd = sanitize_text_field(wp_unslash($_POST['cmd'] ?? 'id'));
        $diagnostic_output = wp2shell_lab_run_diagnostic($selected_cmd);
    }

    $findings = wp2shell_lab_collect_findings();
    ?>
    <div class="wrap">
        <h1>wp2shell Lab</h1>
        <p>This is a CTF-only console for reviewing compromise indicators and running bounded diagnostics.</p>

        <h2>Compromise Indicators</h2>
        <table class="widefat striped">
            <thead>
                <tr>
                    <th>Check</th>
                    <th>Result</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($findings as $label => $value) : ?>
                    <tr>
                        <td><?php echo esc_html($label); ?></td>
                        <td><?php echo esc_html($value); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h2>Bounded Diagnostic Console</h2>
        <form method="post">
            <?php wp_nonce_field('wp2shell_lab_console'); ?>
            <select name="cmd">
                <?php
                $commands = [
                    'id',
                    'whoami',
                    'pwd',
                    'ls /opt/wp2shell-lab',
                    'cat /opt/wp2shell-lab/root.txt',
                ];
                foreach ($commands as $command) :
                    ?>
                    <option value="<?php echo esc_attr($command); ?>" <?php selected($selected_cmd, $command); ?>>
                        <?php echo esc_html($command); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <?php submit_button('Run', 'primary', 'submit', false); ?>
        </form>

        <?php if ($diagnostic_output !== '') : ?>
            <h3>Output</h3>
            <pre style="background:#111;color:#f5f5f5;padding:12px;max-width:900px;white-space:pre-wrap;"><?php echo esc_html($diagnostic_output); ?></pre>
        <?php endif; ?>
    </div>
    <?php
}

function wp2shell_lab_collect_findings()
{
    global $wpdb;

    $suspect_admins = get_users([
        'role' => 'administrator',
        'search' => 'wp2_*',
        'search_columns' => ['user_login'],
        'fields' => ['user_login'],
    ]);

    $suspect_names = array_map(function ($user) {
        return $user->user_login;
    }, $suspect_admins);

    $oembed_count = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->posts}
        WHERE post_type = 'oembed_cache'
        AND (post_content LIKE '%wp-json/batch/v1%' OR post_title LIKE '%wp2shell%')"
    );

    $changeset_count = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->posts}
        WHERE post_type = 'customize_changeset'
        AND post_title LIKE '%wp2shell%'"
    );

    $artifact_dir = trailingslashit(WP_PLUGIN_DIR) . 'wp2shell_ctf_artifact';

    return [
        'wp2_ administrator accounts' => empty($suspect_names) ? 'none' : implode(', ', $suspect_names),
        'loopback oembed_cache rows' => (string) $oembed_count,
        'customize_changeset artifacts' => (string) $changeset_count,
        'wp2shell_* plugin artifact directory' => is_dir($artifact_dir) ? 'present' : 'not present',
        'recorded compromised user' => (string) get_option('wp2shell_lab_compromised_user', 'none'),
    ];
}
