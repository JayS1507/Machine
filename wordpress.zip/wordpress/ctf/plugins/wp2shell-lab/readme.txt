=== wp2shell Lab ===
Contributors: ctf
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later

CTF-only training plugin that models route confusion, SQL injection, compromise artifacts, and bounded post-compromise diagnostics.
