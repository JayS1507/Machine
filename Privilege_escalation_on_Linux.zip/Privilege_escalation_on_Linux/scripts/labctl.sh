#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

cmd="${1:-help}"
shift || true

case "$cmd" in
  up)
    docker compose up -d --build
    ;;
  down)
    docker compose down -v
    ;;
  reset)
    docker compose down -v
    docker compose up -d --build
    ;;
  logs)
    docker compose logs -f --tail=100
    ;;
  shell)
    docker compose exec target bash
    ;;
  ssh)
    ssh -p 2222 student@localhost
    ;;
  *)
    cat <<'EOF'
Usage: scripts/labctl.sh {up|down|reset|logs|shell|ssh}
EOF
    ;;
esac
