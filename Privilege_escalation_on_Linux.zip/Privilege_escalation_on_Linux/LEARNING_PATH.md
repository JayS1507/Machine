# Privilege Escalation on Linux - Student Learning Path

This version is for players. It gives the route, questions, and module goals, but not the answers.

## Deploy the lab

```bash
make up
ssh student@localhost -p 2222
```

## Default accounts

| User | Password | Use |
| --- | --- | --- |
| student | student123 | Main learner account |
| devuser | dev123 | Sudo and env module |
| dockeruser | docker123 | Docker group module |
| logger | logger123 | Log access module |
| diskuser | disk123 | Raw disk module |

## Lab surfaces

- UID and SUID helpers
- Sudo rules for common GTFOBins binaries
- Capability-enabled helpers
- Cron jobs and hidden cron output
- PATH and shared library hijack demos
- Writable config samples in `/opt/lab/config`
- Docker group access through the socket proxy
- Raw disk device at `/dev/labdisk`
- NFS export on `nfs-server`
- AppArmor-confined `mac-reader`
- `ptrace-probe` for process inspection
- Final multi-vector challenge

## Module 00: Linux security model

**Goal**

Understand real UID, effective UID, saved UID, groups, and capabilities.

**Questions**

1. Which UID is used for permission checks?
2. Why can a SUID root program sometimes drop privileges and later regain them?
3. What is the difference between DAC and MAC?

**Task**

Run the UID helper and explain what changes when a SUID binary executes.

## Module 01: Enumeration

**Goal**

Learn the first checks to run on a Linux target.

**Questions**

1. Which commands quickly show sudo, SUID, capabilities, processes, and listening ports?
2. Why should you search for unusual groups?
3. What information can reveal a promising escalation path?

**Task**

Run a full manual enumeration pass and note five suspicious findings.

## Module 02: sudo

**Goal**

Identify dangerous sudo rules and environment handling.

**Questions**

1. Which sudoers options are dangerous?
2. Why are `find`, `vim`, `tar`, `less`, `awk`, `perl`, and `python3` interesting?
3. What is the risk of preserving `LD_PRELOAD` or `LD_LIBRARY_PATH`?

**Task**

Check the allowed sudo commands and test which ones can be abused.

## Module 03: SUID / SGID

**Goal**

Recognize how SUID and SGID change execution context.

**Questions**

1. What does the SUID bit do?
2. Why is `bashroot -p` useful?
3. Why do shell scripts not honor SUID in the usual way?

**Task**

Find SUID binaries and test which ones preserve privilege.

## Module 04: Capabilities

**Goal**

Use file capabilities as a weaker but still dangerous root replacement.

**Questions**

1. What does `+ep` mean in `getcap` output?
2. Which capability lets a binary change UID arbitrarily?
3. Which capability lets you bypass file permission checks?

**Task**

Inspect the capability-enabled helpers and test what they let you do.

## Module 05: Cron

**Goal**

Find writable cron jobs and hidden scheduled activity.

**Questions**

1. Which file runs the cron backup job?
2. What makes a cron job dangerous?
3. What tool can help spot hidden cron activity?

**Task**

Review cron files and observe what runs as root.

## Module 06: PATH hijacking

**Goal**

See how relative command execution can be abused.

**Questions**

1. Which lab binary demonstrates PATH hijacking?
2. Why is using absolute paths safer?
3. What happens if a privileged process calls a command without a full path?

**Task**

Trace the helper’s command lookup and identify the weak spot.

## Module 07: Writable files

**Goal**

Spot dangerous writable files and configs.

**Questions**

1. Which writable practice files exist in the lab?
2. Why are `/etc/passwd`, `/etc/sudoers`, and `/etc/shadow` sensitive?
3. What is the impact of a writable cron or logrotate config?

**Task**

Check for world-writable files and explain the risk of each useful hit.

## Module 08: Shared library hijacking

**Goal**

Understand RPATH, RUNPATH, and library search order.

**Questions**

1. Which binary uses the shared-library demo?
2. Which directory is writable for the shared object test?
3. Why are writable library paths dangerous?

**Task**

Inspect the binary metadata and identify how it resolves libraries.

## Module 09: Group-based escalation

**Goal**

Use group membership as a privilege-escalation path.

**Questions**

1. Which group gives raw disk access?
2. Which groups are especially dangerous here?
3. Why is log access useful for escalation?

**Task**

Check your group membership and search for high-risk group access.

## Module 10: Kernel

**Goal**

Practice kernel triage without rushing into exploitation.

**Questions**

1. What should you check before thinking about a kernel path?
2. Why are kernel exploits a last resort?
3. What helper is provided for triage?

**Task**

Collect kernel and architecture details and decide whether a kernel path is realistic.

## Module 11: NFS

**Goal**

Recognize how export options can become a root path.

**Questions**

1. Which export option matters most?
2. What command lists the export?
3. Why is root squash important?

**Task**

Inspect the NFS export and decide whether it is safe.

## Module 12: AppArmor / SELinux

**Goal**

See how MAC can restrict even root-like access.

**Questions**

1. How do you check whether MAC is active?
2. What does AppArmor restrict?
3. What does SELinux restrict?

**Task**

Test the confined helper and determine what blocks access.

## Module 13: ptrace / memfd

**Goal**

Understand process inspection and memory-oriented techniques.

**Questions**

1. What capability does `ptrace-probe` use?
2. What does it print?
3. Why is `ptrace_scope` important?

**Task**

Use the probe on a safe target process and note what it can reveal.

## Module 14: Final multi-vector challenge

**Goal**

Combine the clues from multiple modules into one stable root path.

**Questions**

1. What are the stable paths to check first?
2. Which path looks safest to execute in a live target?
3. What is the final goal?

**Task**

Choose one path, escalate, and capture the final flag.

## Module 15: Reporting

**Goal**

Write a short professional escalation report.

**Questions**

1. Where is the report template?
2. What should the report include?
3. Why does remediation matter?

**Task**

Document what you found, how you got root, and what should be fixed.

## Submission checklist

1. Deploy with `make up`.
2. SSH as `student`.
3. Enumerate the target.
4. Solve one or more modules.
5. Capture the flag(s).
6. Write the report.
