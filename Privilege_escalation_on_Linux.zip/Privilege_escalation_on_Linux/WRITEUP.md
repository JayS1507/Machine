# Privilege Escalation on Linux - Solution Writeup

This writeup matches the lab images and helper binaries in this repository.

## Module 00 - Linux security model

- Check process IDs with `uid-demo`.
- Observe SUID behavior with `/usr/local/bin/bashroot -p`.
- Verify the process keeps `euid=0` because the binary is root-owned and SUID.

## Module 01 - Enumeration

- Use `id`, `sudo -l`, `find / -perm -4000 -type f`, `getcap -r / 2>/dev/null`, `ps aux`, and `ss -tulpn`.
- The target also exposes `/opt/lab/docs/report-template.md` for note taking.

## Module 02 - sudo

- `student` and `devuser` can run `find`, `vim`, `tar`, `less`, `awk`, `perl`, and `python3` via sudo.
- `env_keep` preserves `LD_PRELOAD` and `LD_LIBRARY_PATH`.
- Example: `sudo LD_PRELOAD=/tmp/evil.so /usr/bin/find / -maxdepth 0 -quit`.

## Module 03 - SUID / SGID

- `uid-demo` shows UID transitions.
- `bashroot -p` keeps effective root.
- `path-demo` is the PATH hijack demo; place a fake `labls` earlier in `PATH`.

## Module 04 - Capabilities

- `labtool` has `cap_setuid`, `cap_setgid`, and `cap_dac_override`.
- `cap-shell` becomes root and drops into `bash -p`.
- `cap-read` reads protected files such as `/etc/shadow`.

## Module 05 - Cron

- `/etc/cron.d/lab-backup` runs `/usr/local/bin/cron-backup.sh`.
- The script is intentionally writable.
- `lab-hidden` writes `hidden-cron` into `/tmp/hidden-cron.log`.

## Module 06 - PATH hijacking

- `path-demo` calls `labls` without an absolute path.
- Exploit by creating `/tmp/labls` and prepending `/tmp` to `PATH`.

## Module 07 - Writable configs

- Writable samples live in `/opt/lab/config/passwd`, `sudoers`, and `shadow`.
- These are for practicing password hash and sudoers abuse in a safe location.

## Module 08 - Shared library hijacking

- `rpath-demo` loads `liblabdemo.so` from `/opt/lab/rpathlib`.
- The directory is writable, so students can replace the shared object.

## Module 09 - Groups and logs

- `dockeruser` is in the `docker` group.
- `diskuser` can access `/dev/labdisk` and read the raw-disk secret.
- `logger` is in `adm` and can read `/var/log/lab/auth.log` and `/var/log/lab/mysql.log`.

## Module 10 - Kernel

- This lab uses `kernel-check` and system enumeration instead of a real kernel exploit.
- Use `uname -a`, `/proc/version`, and the module notes to practice triage.

## Module 11 - NFS

- The NFS server exports `/exports` with `no_root_squash`.
- Mount it from the target and practice NFS-based escalation.

## Module 12 - AppArmor / SELinux

- `mac-reader` is confined by AppArmor.
- Direct execution fails; `aa-exec -p unconfined -- /usr/local/bin/mac-reader` reads `/root/mac-flag.txt`.

## Module 13 - ptrace / memfd

- `ptrace-probe` has `cap_sys_ptrace`.
- Point it at a root process such as `sshd` to read registers.

## Module 14 - Multi-vector challenge

- Available paths: Docker, SUID, cron, sudo, capabilities, and writable configs.
- The intended answer is to enumerate first, then choose the fastest stable path.

## Module 15 - Reporting

- Use `/opt/lab/docs/report-template.md` as the final assessment template.

## Quick validation checklist

1. `docker compose up -d`
2. SSH as `student` on port `2222`
3. Run `sudo -l`
4. Check `uid-demo`, `bashroot`, `path-demo`, `cap-read`, `rpath-demo`, `ptrace-probe`
5. Verify `/dev/labdisk`, `/var/log/lab/*`, `showmount -e nfs-server`, and `aa-exec`

