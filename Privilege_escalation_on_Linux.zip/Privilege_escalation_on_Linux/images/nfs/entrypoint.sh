#!/usr/bin/env bash
set -euo pipefail

mkdir -p /exports /proc/fs/nfsd /run/rpcbind
echo '/exports *(rw,sync,no_subtree_check,no_root_squash,insecure,fsid=0)' > /etc/exports

rpcbind -w
mountpoint -q /proc/fs/nfsd || mount -t nfsd nfsd /proc/fs/nfsd
exportfs -rav

rpc.nfsd 8
rpc.mountd -F

trap 'kill 0' TERM INT
while true; do
  sleep 3600
done

