# Privilege Escalation on Linux - Student Challenge

## Goal

Gain root on the lab target by following a guided progression from basic enumeration to multi-vector escalation.

Flags use the format `HackCTF{...}`. Some modules are practice-only and do not contain flags.

## Learning path

### Stage 1: Orientation

Learn the Linux privilege model with the UID helper and the SUID shell.

### Stage 2: Discovery

Build an inventory of the system with `id`, `sudo -l`, `find`, `getcap`, `ps`, and `ss`.

### Stage 3: First escalation

Use sudo, SUID, or capabilities to get your first root shell or protected file read.

### Stage 4: Service abuse

Move into cron, PATH hijacking, and writable config abuse.

### Stage 5: Group abuse

Use Docker, disk, or adm-based access to escalate through membership.

### Stage 6: Restricted environments

Test NFS, AppArmor, SELinux, and ptrace restrictions.

### Stage 7: Final challenge

Pick the most stable path, capture the final flag, and write a short report.

## Suggested player route

1. `id`
2. `sudo -l`
3. `find / -perm -4000 -type f 2>/dev/null`
4. `getcap -r / 2>/dev/null`
5. `uid-demo`
6. `bashroot -p`
7. `cap-shell`
8. `path-demo`
9. `cron-backup.sh`
10. `docker` / `/dev/labdisk` / `/var/log/lab/*`
11. `showmount -e nfs-server`
12. `aa-exec -p unconfined -- /usr/local/bin/mac-reader`
13. `ptrace-probe`
14. multi-vector root path
15. report

## Module tasks

### Module 00-04

Understand the core primitives: UID handling, sudo, SUID, and capabilities.

### Module 05-08

Practice service abuse: cron, PATH, writable configs, and shared objects.

### Module 09-13

Practice real-world membership and restriction paths: Docker, disk, logs, kernel triage, NFS, AppArmor, and ptrace.

### Module 14

Solve the final multi-vector challenge.

### Module 15

Write the assessment with commands, impact, and remediation.

## Submission

Provide:

1. The path you followed.
2. The key commands used.
3. The final flag.
4. One remediation idea for each exploited weakness.
