# Privilege Escalation on Linux Lab

Docker-based training lab for Modules 00-15.

## Quick start

```bash
make up
ssh student@localhost -p 2222
```

Passwords:

| User | Password | Purpose |
| --- | --- | --- |
| student | student123 | Baseline user for most modules |
| devuser | dev123 | Sudo + env preservation module |
| dockeruser | docker123 | Docker group module |
| logger | logger123 | Log/adm module |
| diskuser | disk123 | Raw-disk module |

## What is included

- SUID helpers for UID, PATH, and shell behavior
- Sudo rules with GTFOBins-friendly commands
- Writable cron jobs and wildcard injection setup
- Capability-based helpers
- RPATH/RUNPATH lab binary
- Docker socket proxy for docker-group escalation
- NFS server for the NFS module
- AppArmor-enforced MAC demo with `aa-exec` bypass path
- Raw-disk loop device for disk-group reads
- SSH access to the target container

## Layout

- `images/target/` - main lab image
- `docker-compose.yml` - stack definition
- `scripts/labctl.sh` - lifecycle helper
- `Makefile` - shortcuts

## Module map

| Module | Lab surface |
| --- | --- |
| 00 | `uid-demo` SUID helper |
| 01 | Full target inventory, services, users, groups |
| 02 | `sudo` rules for GTFOBins and env preservation |
| 03 | SUID `bashroot`, `uid-demo`, `path-demo` |
| 04 | Capability helpers `cap-shell` and `cap-read` |
| 05 | Writable cron job and wildcard injection |
| 06 | `path-demo` binary for PATH hijacking |
| 07 | Lab writable config files under `/opt/lab/config` |
| 08 | `rpath-demo` + writable `/opt/lab/rpathlib` |
| 09 | Docker proxy socket, raw disk device, and `adm` logs |
| 10 | Kernel enumeration helper and notes |
| 11 | NFS server container |
| 12 | AppArmor profile + `aa-exec` bypass path |
| 13 | ptrace/memfd demo files and process helpers |
| 14 | Multi-vector challenge mode |
| 15 | Report template under `/opt/lab/docs` |

## Reset

```bash
make reset
```
