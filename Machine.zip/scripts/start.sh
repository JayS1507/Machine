#!/usr/bin/env bash
set -euo pipefail

mkdir -p /run/sshd
/usr/sbin/sshd

runuser -u web -- bash -lc 'cd /opt/orbitdesk && python3 internal_admin.py' &
runuser -u web -- bash -lc 'cd /opt/orbitdesk && gunicorn --workers 2 --bind 0.0.0.0:8080 --access-logfile - public_app:app' &

wait -n
