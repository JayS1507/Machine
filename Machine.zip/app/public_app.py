import hashlib
import hmac
import html
import os
from datetime import datetime, timezone
from urllib.parse import urlparse

import requests
import yaml
from flask import Flask, Response, jsonify, render_template, request


app = Flask(__name__)

IMPORT_SIGNING_KEY = os.environ.get(
    "ORBIT_IMPORT_SIGNING_KEY",
    "d4c2b4d1b3e6402f9cfbbad4b45ce0d14bd6f40148fd8ac79a89a52a7c5d9f0a",
)

BLOCKED_HOST_TOKENS = (
    "localhost",
    "127.0.0.1",
    "0.0.0.0",
    "::1",
    "169.254.169.254",
)


def import_signature(body: bytes) -> str:
    return hmac.new(IMPORT_SIGNING_KEY.encode(), body, hashlib.sha256).hexdigest()


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/health")
def health():
    return jsonify(
        {
            "service": "orbitdesk-support",
            "status": "ok",
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }
    )


@app.get("/api/proxy/preview")
def proxy_preview():
    raw_url = request.args.get("url", "")
    parsed = urlparse(raw_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return jsonify({"error": "URL must include http or https scheme"}), 400

    lowered = raw_url.lower()
    if any(token in lowered for token in BLOCKED_HOST_TOKENS):
        return jsonify({"error": "Preview target is blocked by policy"}), 403

    try:
        upstream = requests.get(raw_url, timeout=4, allow_redirects=False)
    except requests.RequestException as exc:
        return jsonify({"error": f"Preview failed: {exc.__class__.__name__}"}), 502

    body = upstream.text[:10000]
    return Response(
        render_template(
            "preview.html",
            target=raw_url,
            status=upstream.status_code,
            content_type=upstream.headers.get("content-type", "unknown"),
            body=html.escape(body),
        ),
        mimetype="text/html",
    )


@app.post("/api/config/import")
def import_config():
    supplied = request.headers.get("X-Import-Signature", "")
    body = request.get_data()
    expected = import_signature(body)
    if not hmac.compare_digest(supplied, expected):
        return jsonify({"error": "invalid import signature"}), 403

    try:
        imported = yaml.load(body, Loader=yaml.Loader)
    except Exception as exc:
        return jsonify({"error": f"import parser rejected document: {exc}"}), 400

    return jsonify(
        {
            "status": "accepted",
            "type": type(imported).__name__,
            "message": "configuration import queued for sync",
        }
    )


@app.get("/robots.txt")
def robots():
    return Response(
        "User-agent: *\nDisallow: /api/config/import\nDisallow: /api/proxy/preview\n",
        mimetype="text/plain",
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
