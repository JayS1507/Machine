import os
from datetime import datetime, timezone

from flask import Flask, jsonify, request


app = Flask(__name__)

IMPORT_SIGNING_KEY = os.environ.get(
    "ORBIT_IMPORT_SIGNING_KEY",
    "d4c2b4d1b3e6402f9cfbbad4b45ce0d14bd6f40148fd8ac79a89a52a7c5d9f0a",
)


@app.get("/")
def index():
    return jsonify({"service": "orbitdesk-internal-control", "scope": "loopback-only"})


@app.get("/status")
def status():
    return jsonify(
        {
            "service": "orbitdesk-internal-control",
            "status": "green",
            "bind": "127.0.0.1:9090",
            "time": datetime.now(timezone.utc).isoformat(),
        }
    )


@app.get("/debug/config")
def debug_config():
    if request.args.get("scope") != "sync":
        return jsonify({"error": "missing scope"}), 400

    return jsonify(
        {
            "environment": "production",
            "sync_profile": "signed-yaml-import",
            "import_signing_key": IMPORT_SIGNING_KEY,
            "deploy_key_hint": "/var/backups/orbitdesk/deploy_sync_ed25519",
            "opened_by": "temporary incident-response exception",
        }
    )


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=9090)
