# Royal Mint // Operations

An insane-difficulty, multi-stage Money Heist-inspired CTF for an isolated Docker lab. Players receive one server IP and two ports; no local setup is required.

## Player brief

The Royal Mint's operations portal reports a compromise while its printing systems remain locked. Find the Professor's path through the network, enter the maintenance node, and take control of the mint.

Scope is limited to the supplied server IP on the announced HTTP and SSH ports. Do not attack the hosting provider, neighboring containers, or other players.

- Web: `http://SERVER_IP:8088`
- SSH: `SERVER_IP:2228`
- Flag format: `HackCTF{...}`
- Goal: capture all five flags, including `/root/root.txt`

## Operator quick start

Requirements: Docker Engine with Compose v2 and at least 1 GB free RAM.

```bash
cd moneyheist-ctf
./deploy.sh
docker compose ps
```

To use different public ports:

```bash
CTF_HTTP_PORT=80 CTF_SSH_PORT=2222 ./deploy.sh
```

Reset the complete challenge state with `./reset.sh`. Stop it with `docker compose down`.

## Safety boundaries

- The identity network is Docker-internal and has no published port.
- No service is privileged and there are no host filesystem or Docker socket mounts.
- Public services drop Linux capabilities and enable `no-new-privileges`.
- The SSH target loses `NET_RAW`, has resource limits, and cannot forward ports.
- Root access obtained by a player is root only inside the disposable `mint-node` container.

Keep this directory and the instructor guide private from players; only give them the server IP, ports, and player brief.
