#!/bin/sh
set -eu

docker compose -f docker-compose-single.yml build
docker compose -f docker-compose-single.yml up -d

printf '\n%s\n' "Money Heist CTF is running (single container mode)."
printf '%s\n' "Web: http://YOUR_SERVER_IP:${CTF_HTTP_PORT:-8088}"
printf '%s\n' "SSH: ssh -p ${CTF_SSH_PORT:-2228} berlin@YOUR_SERVER_IP"
printf '%s\n' "Status: docker compose -f docker-compose-single.yml ps"
printf '%s\n' "Stop: docker compose -f docker-compose-single.yml down"
