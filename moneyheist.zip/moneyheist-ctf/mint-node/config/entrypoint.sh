#!/bin/sh
set -eu

if [ -z "${USER_FLAG:-}" ]; then USER_FLAG='HackCTF{development_user_flag}'; fi
if [ -z "${ROOT_FLAG:-}" ]; then ROOT_FLAG='HackCTF{development_root_flag}'; fi
printf '%s\n' "$USER_FLAG" > /home/berlin/user.txt
printf '%s\n' "$ROOT_FLAG" > /root/root.txt
chown berlin:berlin /home/berlin/user.txt
chmod 0440 /home/berlin/user.txt
chmod 0400 /root/root.txt

cat > /etc/motd <<'EOF'

  ROYAL MINT // SECURE MAINTENANCE NODE
  Unauthorized presence will be traced.

EOF

unset USER_FLAG ROOT_FLAG
exec /usr/sbin/sshd -D -e
