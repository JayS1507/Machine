#!/bin/sh
set -eu

docker compose build
docker compose up -d

printf '\n%s\n' "Money Heist CTF is running."
printf '%s\n' "Web: http://YOUR_SERVER_IP:${CTF_HTTP_PORT:-8088}"
printf '%s\n' "SSH: ssh -p ${CTF_SSH_PORT:-2228} USER@YOUR_SERVER_IP"
printf '%s\n' "Status: docker compose ps"
printf '%s\n' "Stop: docker compose down"
