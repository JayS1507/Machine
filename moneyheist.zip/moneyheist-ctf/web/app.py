import hashlib
import os
import sqlite3
from pathlib import Path
from urllib.parse import urlparse

import jwt
import requests
from flask import Flask, jsonify, render_template, request, send_file

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024

JWT_SECRET = os.environ.get("MINT_JWT_SECRET", "development-secret")
SERVICE_TOKEN = os.environ.get("MINT_SERVICE_TOKEN", "development-token")
WEB_FLAG = os.environ.get("WEB_FLAG", "HackCTF{development_web_flag}")
DB_PATH = "/tmp/operations.db"


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        DROP TABLE IF EXISTS dossiers;
        DROP TABLE IF EXISTS classified;
        CREATE TABLE dossiers (
            codename TEXT NOT NULL,
            clearance TEXT NOT NULL,
            assignment TEXT NOT NULL,
            public INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE classified (
            codename TEXT NOT NULL,
            clearance TEXT NOT NULL,
            assignment TEXT NOT NULL
        );
        INSERT INTO dossiers VALUES
            ('tokyo', 'field', 'perimeter surveillance', 1),
            ('rio', 'signals', 'radio maintenance', 1),
            ('denver', 'logistics', 'bullion transport', 1),
            ('nairobi', 'quality', 'press calibration', 1),
            ('helsinki', 'infrastructure', 'loading bay controls', 1);
        """
    )
    db.executemany(
        "INSERT INTO classified VALUES (?, ?, ?)",
        [
            ("professor", "black", WEB_FLAG),
            ("palermo", "service", f"identity bootstrap bearer: {SERVICE_TOKEN}"),
            ("marseille", "route", "poster proxy accepts only the assets authority"),
        ],
    )
    db.commit()
    db.close()


init_db()


def token_claims():
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    try:
        return jwt.decode(
            header[7:],
            JWT_SECRET,
            algorithms=["HS256"],
            audience="royal-mint-ops",
            issuer="professor.identity",
        )
    except jwt.PyJWTError:
        return None


def require_admin():
    claims = token_claims()
    if not claims or claims.get("role") != "admin" or claims.get("sub") != "professor":
        return None
    return claims


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/healthz")
def healthz():
    return {"status": "operational"}


@app.get("/robots.txt")
def robots():
    return (
        "User-agent: *\nDisallow: /api/v1/admin/\n"
        "# legacy dossier search retained for field terminals\n"
        "# /api/v1/dossiers?codename=tokyo\n",
        200,
        {"Content-Type": "text/plain; charset=utf-8"},
    )


@app.post("/api/v1/session")
def create_session():
    payload = request.get_json(silent=True) or {}
    employee = str(payload.get("employee", ""))[:80]
    password = str(payload.get("password", ""))
    digest = hashlib.sha256(password.encode()).hexdigest()
    if employee == "guest-auditor" and digest == "f0b31f8f75c20f16f4e57f2c59ac2fe4c8b54dc2804cbd5bc7d7db0a7d6f6f8f":
        token = jwt.encode(
            {"sub": employee, "role": "auditor", "aud": "royal-mint-ops", "iss": "professor.identity"},
            JWT_SECRET,
            algorithm="HS256",
        )
        return {"token": token}
    return jsonify(error="Employee record is not present in the active manifest."), 401


@app.get("/api/v1/dossiers")
def dossiers():
    codename = request.args.get("codename", "")[:180]
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    try:
        # INTENTIONAL CTF VULNERABILITY: SQL injection in a legacy search endpoint.
        query = (
            "SELECT codename, clearance, assignment FROM dossiers "
            f"WHERE public = 1 AND codename LIKE '%{codename}%'"
        )
        rows = db.execute(query).fetchall()
        return jsonify(results=[dict(row) for row in rows], count=len(rows))
    except sqlite3.Error as exc:
        return jsonify(error="archive query rejected", detail=str(exc)), 400
    finally:
        db.close()


@app.get("/api/v1/poster-preview")
def poster_preview():
    raw_url = request.args.get("url", "")
    # INTENTIONAL CTF VULNERABILITY: validation checks the raw authority prefix,
    # while the HTTP client correctly interprets userinfo before the real host.
    if not raw_url.startswith("http://assets"):
        return jsonify(error="Only the assets authority is trusted."), 403
    try:
        parsed = urlparse(raw_url)
        if parsed.scheme != "http":
            return jsonify(error="Unsupported poster protocol."), 400
        upstream = requests.get(raw_url, timeout=2, allow_redirects=False)
        body = upstream.content[:262144]
        return (
            body,
            upstream.status_code,
            {"Content-Type": upstream.headers.get("Content-Type", "application/octet-stream")},
        )
    except requests.RequestException:
        return jsonify(error="Poster authority did not respond."), 502


@app.get("/api/v1/admin/exports")
def list_exports():
    if not require_admin():
        return jsonify(error="Black clearance required."), 403
    return {
        "exports": [
            {"name": "ledger-summary", "file": "daily/ledger-summary.txt"},
            {"name": "crew-transfer", "file": "daily/crew-transfer.log"},
        ]
    }


@app.get("/api/v1/admin/export")
def download_export():
    if not require_admin():
        return jsonify(error="Black clearance required."), 403
    filename = request.args.get("file", "")
    # INTENTIONAL CTF VULNERABILITY: a raw prefix is not a path containment check.
    if not filename.startswith("daily/") or "\x00" in filename:
        return jsonify(error="Only daily exports may leave the archive."), 400
    target = Path("/srv/exports") / filename
    try:
        return send_file(target, as_attachment=True, download_name=target.name)
    except (FileNotFoundError, IsADirectoryError):
        return jsonify(error="Export not found."), 404


@app.errorhandler(404)
def not_found(_error):
    return jsonify(error="Route absent from the operation manifest."), 404
