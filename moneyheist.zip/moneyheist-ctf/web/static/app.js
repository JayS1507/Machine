const form = document.querySelector("#access-form");
const message = document.querySelector("#access-message");
const consoleNode = document.querySelector("#intel-console");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  message.value = ">> validating employee manifest...";
  const data = Object.fromEntries(new FormData(form));
  try {
    const response = await fetch("/api/v1/session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const body = await response.json();
    message.value = response.ok ? ">> access channel established" : `>> ${body.error}`;
  } catch {
    message.value = ">> operations channel unavailable";
  }
});

document.querySelectorAll(".dossier").forEach((button) => {
  button.addEventListener("click", async () => {
    document.querySelectorAll(".dossier").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    consoleNode.textContent = ">> querying legacy dossier archive...";
    try {
      const response = await fetch(`/api/v1/dossiers?codename=${encodeURIComponent(button.dataset.codename)}`);
      const body = await response.json();
      consoleNode.textContent = response.ok
        ? `>> ${body.results.map((row) => `${row.codename.toUpperCase()} / ${row.clearance} / ${row.assignment}`).join(" | ")}`
        : `>> ${body.error}: ${body.detail || "request rejected"}`;
    } catch {
      consoleNode.textContent = ">> dossier archive unavailable";
    }
  });
});

const countdown = document.querySelector("#countdown");
let seconds = 72 * 3600 + 48 * 60 + 31;
setInterval(() => {
  seconds = Math.max(0, seconds - 1);
  const hours = String(Math.floor(seconds / 3600)).padStart(2, "0");
  const minutes = String(Math.floor((seconds % 3600) / 60)).padStart(2, "0");
  const secs = String(seconds % 60).padStart(2, "0");
  countdown.textContent = `${hours}:${minutes}:${secs}`;
}, 1000);
