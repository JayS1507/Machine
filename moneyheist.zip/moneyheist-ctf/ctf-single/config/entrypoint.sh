#!/bin/sh
set -eu

# ============================================================
# Set flags (from env vars, with dev defaults)
# ============================================================
WEB_FLAG="${WEB_FLAG:-}"
IDENTITY_FLAG="${IDENTITY_FLAG:-}"
USER_FLAG="${USER_FLAG:-}"
ROOT_FLAG="${ROOT_FLAG:-}"
[ -z "$WEB_FLAG" ]      && WEB_FLAG='HackCTF{development_web_flag}'
[ -z "$IDENTITY_FLAG" ] && IDENTITY_FLAG='HackCTF{development_identity_flag}'
[ -z "$USER_FLAG" ]     && USER_FLAG='HackCTF{development_user_flag}'
[ -z "$ROOT_FLAG" ]     && ROOT_FLAG='HackCTF{development_root_flag}'

printf '%s\n' "$WEB_FLAG"        > /srv/exports/daily/.web_flag
printf '%s\n' "$IDENTITY_FLAG"  > /srv/exports/daily/.identity_flag
printf '%s\n' "$USER_FLAG"      > /home/berlin/user.txt
printf '%s\n' "$ROOT_FLAG"      > /root/root.txt

chown berlin:berlin /home/berlin/user.txt
chmod 0440 /home/berlin/user.txt
chmod 0400 /root/root.txt

# ============================================================
# SSH key for berlin
# ============================================================
cat /opt/berlin_key.pub > /home/berlin/.ssh/authorized_keys 2>/dev/null || true

chown berlin:berlin /home/berlin/.ssh/authorized_keys
chmod 0600 /home/berlin/.ssh/authorized_keys

# ============================================================
# MOTD
# ============================================================
cat > /etc/motd <<'MOTD'

  ╔══════════════════════════════════════════════════════════╗
  ║           ROYAL MINT // SECURE MAINTENANCE NODE         ║
  ╚══════════════════════════════════════════════════════════╝

  WARNING: Unauthorized presence will be traced.

  You have reached the Royal Mint operations maintenance node.
  The printing systems are currently HALTED pending security review.

  The Professor's plan is already in motion.
  Five vaults remain. Only the worthy will print the final billion.

  > User flag is stored in your home directory.
  > Root flag requires privilege escalation.
  > Tip: Run 'sudo -l' to inspect your access rights.

  System: Debian Bookworm | SSH: Ed25519 | Status: COMPROMISED

MOTD

# ============================================================
# DNS: identity resolves to localhost for SSRF exploit
# ============================================================
echo '127.0.0.1 identity' >> /etc/hosts

# ============================================================
# Start all services via supervisord
# ============================================================
exec /usr/bin/supervisord -c /etc/supervisor/conf.d/ctf.conf
