# Visual specification

The accepted concept is `design/concept.png`. The implementation uses its near-black ground, oxblood red controls, warm off-white condensed type, angular clipped panels, blueprint line work, restrained scanlines, status rail, and horizontal dossier treatment.

The production hero artwork is `web/static/heist-operative.png`, generated separately without text or interface elements so all controls remain accessible, selectable HTML.

Primary tokens: `#080909` background, `#101111` surface, `#e5292d` action red, `#e5dace` primary text, `#9b887b` muted text. Desktop content uses 3.8vw gutters and collapses to 18px gutters below 700px.
