#!/bin/sh
set -eu

docker compose down --remove-orphans
docker compose up -d --build --force-recreate
printf '%s\n' "Money Heist CTF state reset."
