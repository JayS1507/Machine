#!/bin/sh
set -eu

docker compose -f docker-compose-single.yml down --remove-orphans
docker compose -f docker-compose-single.yml up -d --build --force-recreate
printf '%s\n' "Money Heist CTF state reset (single container mode)."
