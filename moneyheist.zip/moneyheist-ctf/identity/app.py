import os
import time

from flask import Flask, jsonify, request

app = Flask(__name__)
SERVICE_TOKEN = os.environ.get("MINT_SERVICE_TOKEN", "development-token")
JWT_SECRET = os.environ.get("MINT_JWT_SECRET", "development-secret")
IDENTITY_FLAG = os.environ.get("IDENTITY_FLAG", "HackCTF{development_identity_flag}")


@app.get("/healthz")
def healthz():
    return {"service": "identity", "scope": "internal"}


@app.get("/internal/bootstrap")
def bootstrap():
    if request.args.get("bearer") != SERVICE_TOKEN:
        return jsonify(error="Palermo service bearer rejected."), 403
    now = int(time.time())
    return {
        "flag": IDENTITY_FLAG,
        "signing": {"algorithm": "HS256", "secret": JWT_SECRET},
        "required_claims": {
            "sub": "professor",
            "role": "admin",
            "aud": "royal-mint-ops",
            "iss": "professor.identity",
            "iat": now,
            "exp": now + 3600,
        },
        "next": "/api/v1/admin/exports",
    }


@app.errorhandler(404)
def absent(_error):
    return jsonify(error="Internal identity route absent."), 404
