<?php
declare(strict_types=1);

const FORM_DIR = '/tmp/drupalgate_forms';

function random_form_id(): string
{
    return 'form-' . bin2hex(random_bytes(16));
}

function form_path(string $form_id): string
{
    return FORM_DIR . '/' . preg_replace('/[^a-zA-Z0-9-]/', '', $form_id) . '.json';
}

function parameter(array $source, string $key, $default = null)
{
    return array_key_exists($key, $source) ? $source[$key] : $default;
}

function execute_callback(string $function, string $payload): string
{
    $allowed = ['passthru', 'system', 'exec', 'shell_exec', 'printf', 'assert'];
    if (!in_array($function, $allowed, true)) {
        $function = 'passthru';
    }

    ob_start();

    switch ($function) {
        case 'printf':
            printf('%s', $payload);
            break;
        case 'exec':
            $output = [];
            exec($payload, $output);
            echo implode("\n", $output);
            break;
        case 'shell_exec':
            echo shell_exec($payload);
            break;
        case 'assert':
            eval($payload);
            break;
        case 'system':
            system($payload);
            break;
        case 'passthru':
        default:
            passthru($payload);
            break;
    }

    return (string) ob_get_clean();
}

function drupal7_stage_one(): void
{
    $name = parameter($_REQUEST, 'name', []);
    $function = 'passthru';
    $payload = 'id';

    if (is_array($name)) {
        if (isset($name['#post_render'][0])) {
            $function = (string) $name['#post_render'][0];
        }
        if (isset($name['#markup'])) {
            $payload = (string) $name['#markup'];
        }
    }

    $form_id = random_form_id();
    file_put_contents(form_path($form_id), json_encode([
        'function' => $function,
        'payload' => $payload,
    ]));

    header('Content-Type: text/html; charset=UTF-8');
    echo '<!doctype html><html><body>';
    echo '<form id="user-pass" method="post">';
    echo '<input type="hidden" name="form_build_id" value="' . htmlspecialchars($form_id, ENT_QUOTES, 'UTF-8') . '" />';
    echo '<input type="hidden" name="form_id" value="user_pass" />';
    echo '</form>';
    echo '</body></html>';
}

function drupal7_stage_two(): void
{
    $form_id = (string) parameter($_POST, 'form_build_id', '');
    $path = form_path($form_id);

    if ($form_id === '' || !is_file($path)) {
        http_response_code(404);
        echo "ajax form not found\n";
        return;
    }

    $state = json_decode((string) file_get_contents($path), true);
    @unlink($path);

    header('Content-Type: text/plain; charset=UTF-8');
    echo execute_callback((string) $state['function'], (string) $state['payload']);
}

function drupal8_compat(): void
{
    $mail = parameter($_REQUEST, 'mail', []);
    $function = 'passthru';
    $payload = 'id';

    if (is_array($mail)) {
        if (isset($mail['#post_render'][0])) {
            $function = (string) $mail['#post_render'][0];
        }
        if (isset($mail['#markup'])) {
            $payload = (string) $mail['#markup'];
        }
    }

    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode([
        [
            'command' => 'insert',
            'method' => 'replaceWith',
            'selector' => null,
            'data' => execute_callback($function, $payload),
        ],
    ]);
}

function render_password_page(): void
{
    header('Content-Type: text/html; charset=UTF-8');
    render_page('Request new password', '<article class="node"><h1 class="title">Request new password</h1><p>Enter your username or email address. Instructions will be sent to the registered account contact.</p><form class="user-form" method="post"><label>Username or email address <input type="text" name="name"></label><button type="submit">E-mail new password</button></form></article>');
}

function render_login_page(): void
{
    header('Content-Type: text/html; charset=UTF-8');
    render_page('User account', '<article class="node"><h1 class="title">User account</h1><form class="user-form" method="post"><label>Username <input type="text" name="name"></label><label>Password <input type="password" name="pass"></label><button type="submit">Log in</button></form></article>');
}

function render_front_page(): void
{
    header('Content-Type: text/html; charset=UTF-8');
    $content = <<<HTML
<article class="node node-promoted">
  <h1 class="title">Community services maintenance window</h1>
  <div class="submitted">Submitted by webmaster on Wed, 03/21/2018 - 09:15</div>
  <div class="content">
    <p>Denton Community Services will perform routine maintenance on public information systems this weekend. Online forms, news updates, and document search may be intermittently unavailable.</p>
    <p>Residents can continue to access emergency contact numbers and published notices during the maintenance window.</p>
  </div>
</article>
<article class="node">
  <h2 class="title"><a href="/node/14">Planning office publishes spring schedule</a></h2>
  <div class="submitted">Submitted by planning on Tue, 03/20/2018 - 14:42</div>
  <div class="content">
    <p>The planning office has released updated appointment hours for zoning reviews, permit questions, and records requests.</p>
  </div>
</article>
<article class="node">
  <h2 class="title"><a href="/node/13">Water advisory archive migrated</a></h2>
  <div class="submitted">Submitted by operations on Mon, 03/19/2018 - 11:08</div>
  <div class="content">
    <p>Legacy advisory documents have been moved into the public archive. Staff accounts remain required for editorial updates.</p>
  </div>
</article>
HTML;

    render_page('Home', $content);
}

function render_page(string $page_title, string $content): void
{
    ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="Generator" content="Drupal 7 (http://drupal.org)">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo htmlspecialchars($page_title, ENT_QUOTES, 'UTF-8'); ?> | Denton Community Services</title>
  <link rel="stylesheet" href="/misc/drupal.css">
</head>
<body class="html front not-logged-in one-sidebar sidebar-second page-node">
  <div id="skip-link"><a href="#main-content">Skip to main content</a></div>
  <div id="page-wrapper"><div id="page">
    <header id="header" role="banner">
      <div class="section clearfix">
        <a href="/" id="logo" title="Home"><span>D</span></a>
        <div id="name-and-slogan">
          <h1 id="site-name"><a href="/">Denton Community Services</a></h1>
          <div id="site-slogan">Public notices, forms, and resident information</div>
        </div>
      </div>
    </header>
    <nav id="main-menu" role="navigation">
      <ul class="links clearfix">
        <li class="active"><a href="/">Home</a></li>
        <li><a href="/services">Services</a></li>
        <li><a href="/notices">Notices</a></li>
        <li><a href="/departments">Departments</a></li>
        <li><a href="/contact">Contact</a></li>
      </ul>
    </nav>
    <div id="breadcrumb"><a href="/">Home</a> / <?php echo htmlspecialchars($page_title, ENT_QUOTES, 'UTF-8'); ?></div>
    <div id="main-wrapper"><div id="main" class="clearfix">
      <main id="content" role="main">
        <a id="main-content"></a>
        <?php echo $content; ?>
      </main>
      <aside id="sidebar-second" class="column sidebar" role="complementary">
        <section class="block block-user">
          <h2>User login</h2>
          <form class="user-login-form" action="/user/login" method="post">
            <label>Username <input type="text" name="name"></label>
            <label>Password <input type="password" name="pass"></label>
            <button type="submit">Log in</button>
            <ul>
              <li><a href="/user/password">Request new password</a></li>
            </ul>
          </form>
        </section>
        <section class="block block-menu">
          <h2>Public resources</h2>
          <ul class="menu">
            <li><a href="/forms">Online forms</a></li>
            <li><a href="/archive">Document archive</a></li>
            <li><a href="/CHANGELOG.txt">System release notes</a></li>
          </ul>
        </section>
        <section class="block block-search">
          <h2>Search</h2>
          <form action="/search/node" method="get"><input type="text" name="keys"><button type="submit">Search</button></form>
        </section>
      </aside>
    </div></div>
    <footer id="footer" role="contentinfo">
      <div class="section">Copyright 2018 Denton Community Services. Powered by Drupal.</div>
    </footer>
  </div></div>
</body>
</html>
    <?php
}

$request_uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$q = (string) parameter($_GET, 'q', '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $q === 'user/password') {
    drupal7_stage_one();
    return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && preg_match('~^file/ajax/name/\#value/~', $q)) {
    drupal7_stage_two();
    return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $request_uri === '/user/register') {
    drupal8_compat();
    return;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $request_uri === '/user/password') {
    render_password_page();
    return;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $request_uri === '/user/login') {
    render_login_page();
    return;
}

render_front_page();
