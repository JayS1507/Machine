#!/bin/sh
set -eu

mkdir -p /tmp/drupalgate_forms /root
chmod 1733 /tmp/drupalgate_forms

cat > /home/flaguser/flag1.txt <<'FLAG'
HackCTF{welcome_to_drupalgate}
FLAG
chown flaguser:flaguser /home/flaguser/flag1.txt
chmod 0644 /home/flaguser/flag1.txt

cat > /root/thefinalflag.txt <<'FLAG'
Well done.

HackCTF{drupalgate_rooted_with_suid_find}

You exploited the Drupalgeddon2-style foothold and used the SUID find
misconfiguration to reach root.
FLAG
chown root:root /root/thefinalflag.txt
chmod 0600 /root/thefinalflag.txt

chmod 4755 /usr/bin/find

/usr/sbin/rpcbind -w >/dev/null 2>&1 || true
/usr/sbin/sshd

exec "$@"
