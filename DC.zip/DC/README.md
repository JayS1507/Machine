# DrupalGate Docker CTF Machine

DrupalGate is an easy boot2root CTF machine inspired by the original DC-1 VulnHub Drupal flow:

- Realistic Drupal 7/Bartik-style public-sector web target on HTTP
- Drupalgeddon2-style unauthenticated command execution foothold
- Low-privilege shell as `www-data`
- Intentional SUID `find` misconfiguration for root privilege escalation
- Final flag at `/root/thefinalflag.txt` using the `HackCTF{...}` format

The vulnerable behavior is deliberate and should only be run in an isolated lab.

## Run

```bash
docker compose up --build -d
```

Targets exposed on the host:

```text
http://127.0.0.1:8080
ssh://127.0.0.1:2222
rpcbind://127.0.0.1:1111
```

## Player Path

Expected beginner methodology:

1. Discover exposed services with `nmap`.
2. Identify Drupal from the web page and `/CHANGELOG.txt`.
3. Exploit Drupalgeddon2-style RCE to get a shell as `www-data`.
4. Upgrade the shell with Python.
5. Enumerate SUID files.
6. Abuse `/usr/bin/find` to spawn a root shell.
7. Read `/root/thefinalflag.txt`.

## Reset

```bash
docker compose down -v
docker compose up --build -d
```

## Writeup

A detailed player and operator walkthrough is available in [`WRITEUP.md`](WRITEUP.md).
